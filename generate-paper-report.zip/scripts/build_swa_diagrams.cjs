const fs = require('fs');
const path = require('path');
const rough = require('../tmp/diagrams/rough.cjs');
const sharp = require('C:/Users/sheng/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'assets', 'swa-bounded-replay');
const C = {
  ink: '#34313d', muted: '#65616d', paper: '#fffefb', purple: '#7954a3',
  purpleFill: '#eee5f5', blue: '#396e9b', blueFill: '#e4f0fa',
  orange: '#a5682c', orangeFill: '#fff0d7', green: '#427a60', greenFill: '#e5f3e9',
  red: '#a65b61', redFill: '#f7e5e7', gray: '#8a8790', grayFill: '#f0eef1',
};
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
let id = 1;
class Scene {
  constructor(n, name, h, title, sub, source) {
    this.name = name; this.w = 1440; this.h = h; this.svg = []; this.elements = [];
    this.gen = rough.generator(); this.seed = n * 1000; this.n = n;
    this.text(62, 44, `${String(n).padStart(2,'0')}  ${title}`, 40, C.ink, 'left', 1300);
    this.text(66, 104, sub, 25, C.muted, 'left', 1300);
    this.line([[64,153],[1376,153]], C.purple, 2.2);
    this.line([[64,h-68],[1376,h-68]], '#d4ccd9', 1.2);
    this.text(66,h-49,source,21,C.muted,'left',1300);
  }
  base(type,x,y,w,h,color,fill='transparent') {
    return { id:`s${this.n}-${id++}`, type, x,y,width:w,height:h,angle:0,
      strokeColor:color, backgroundColor:fill, fillStyle:'solid',strokeWidth:2,
      strokeStyle:'solid',roughness:1.5,opacity:100,groupIds:[],frameId:null,
      roundness:null,seed:++this.seed,version:1,versionNonce:this.seed+999,
      isDeleted:false,boundElements:null,updated:1793689200000,link:null,locked:false };
  }
  draw(d, dashed=false) {
    for(const p of this.gen.toPaths(d)) this.svg.push(`<path d="${p.d}" fill="${p.fill||'none'}" stroke="${p.stroke||'none'}" stroke-width="${p.strokeWidth||0}" stroke-linecap="round" stroke-linejoin="round"${dashed?' stroke-dasharray="9 7"':''}/>`);
  }
  rect(x,y,w,h,fill=C.paper,stroke=C.ink,dashed=false) {
    this.draw(this.gen.rectangle(x,y,w,h,{fill,fillStyle:'solid',stroke,strokeWidth:2.1,roughness:1.25,bowing:0.65,seed:++this.seed}),dashed);
    const e=this.base('rectangle',x,y,w,h,stroke,fill);if(dashed)e.strokeStyle='dashed'; this.elements.push(e); return e;
  }
  text(x,y,str,size=28,color=C.ink,align='left',width=500) {
    const lines=String(str).split('\n');const lh=size*1.35;
    const anchor=align==='center'?'middle':align==='right'?'end':'start';
    this.svg.push(`<text x="${x}" y="${y+size*.86}" fill="${color}" font-family="Comic Sans MS, KaiTi, STKaiti, Microsoft YaHei, sans-serif" font-size="${size}" text-anchor="${anchor}">${lines.map((l,i)=>`<tspan x="${x}" dy="${i?lh:0}">${esc(l)}</tspan>`).join('')}</text>`);
    const e=this.base('text',align==='center'?x-width/2:align==='right'?x-width:x,y,width,lines.length*lh,color);
    Object.assign(e,{text:str,originalText:str,fontSize:size,fontFamily:1,textAlign:align,verticalAlign:'top',containerId:null,autoResize:false,lineHeight:1.35,baseline:size});this.elements.push(e);
  }
  box(x,y,w,h,str,{fill=C.paper,stroke=C.ink,size=28,color=C.ink,dashed=false}={}) {
    this.rect(x,y,w,h,fill,stroke,dashed);
    this.text(x+w/2,y+(h-String(str).split('\n').length*size*1.35)/2,str,size,color,'center',w-26);
  }
  line(points,color=C.ink,sw=2,dashed=false,arrow=false) {
    const d=this.gen.linearPath(points,{stroke:color,strokeWidth:sw,roughness:1.15,bowing:.55,seed:++this.seed}); this.draw(d,dashed);
    const x=points[0][0],y=points[0][1];const xx=points.map(p=>p[0]),yy=points.map(p=>p[1]);
    const e=this.base(arrow?'arrow':'line',x,y,Math.max(...xx)-Math.min(...xx),Math.max(...yy)-Math.min(...yy),color);
    e.points=points.map(p=>[p[0]-x,p[1]-y]);e.strokeWidth=sw;e.strokeStyle=dashed?'dashed':'solid';
    if(arrow)Object.assign(e,{startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:'arrow',elbowed:false});
    this.elements.push(e);
    if(arrow){const b=points.at(-1),a=points.at(-2),t=Math.atan2(b[1]-a[1],b[0]-a[0]);
      this.draw(this.gen.linearPath([[b[0]-17*Math.cos(t-.45),b[1]-17*Math.sin(t-.45)],b,[b[0]-17*Math.cos(t+.45),b[1]-17*Math.sin(t+.45)]],{stroke:color,strokeWidth:sw,roughness:.9,seed:++this.seed}));}
  }
  arrow(points,color=C.ink,dashed=false) {this.line(points,color,2.5,dashed,true);}
  note(x,y,w,h,str,color=C.purple,fill=C.purpleFill,size=27) {this.box(x,y,w,h,str,{stroke:color,fill,size,color});}
  async save() {
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${this.w}" height="${this.h}" viewBox="0 0 ${this.w} ${this.h}"><title>${esc(this.name)}</title><defs><pattern id="dots" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r=".8" fill="#dbd5e1" opacity=".6"/></pattern></defs><rect width="100%" height="100%" fill="${C.paper}"/><rect width="100%" height="100%" fill="url(#dots)"/>${this.svg.join('\n')}</svg>`;
    fs.writeFileSync(path.join(OUT,this.name+'.svg'),svg);
    await sharp(Buffer.from(svg)).resize({width:2160}).png().toFile(path.join(OUT,this.name+'.png'));
    await sharp(Buffer.from(svg)).resize({width:1440}).png().toFile(path.join(ROOT,'tmp','diagrams',this.name+'-preview.png'));
    const scene={type:'excalidraw',version:2,source:'https://excalidraw.com',elements:this.elements,appState:{viewBackgroundColor:C.paper,gridSize:null},files:{}};
    fs.writeFileSync(path.join(OUT,this.name+'.excalidraw'),JSON.stringify(scene,null,2));
    const textElements=this.elements.filter(e=>e.type==='text').map(e=>`${e.text} ^${e.id}`).join('\n\n');
    const obsidian=`---\nexcalidraw-plugin: parsed\ntags:\n  - excalidraw\n---\n\n# Excalidraw Data\n\n## Text Elements\n\n${textElements}\n\n%%\n## Drawing\n\n\`\`\`json\n${JSON.stringify(scene,null,2)}\n\`\`\`\n%%\n`;
    fs.writeFileSync(path.join(OUT,this.name+'.excalidraw.md'),obsidian);
    return {name:this.name,width:this.w,height:this.h,elements:this.elements.length};
  }
}

function architecture(){
  const s=new Scene(1,'01-ced-architecture',1060,'CED 架构：全局 KV 与 SWA KV 来自哪里','40 层主干 = 20 层因果编码器 + 20 层解码器','依据论文第 7、9、10 页整理；示意主要数据依赖，省略多模态输入与 CSA2 共享细节。');
  s.box(55,405,240,130,'提示词\ntoken 表示',{fill:C.grayFill,size:30});
  s.arrow([[300,470],[360,470]]);
  s.rect(370,230,350,510,C.purpleFill,C.purple);
  s.text(545,260,'因果编码器',34,C.purple,'center',320);
  s.text(545,310,'第 1–20 层',27,C.purple,'center',310);
  s.box(398,380,294,115,'前 2 层\n仅 SWA',{fill:C.orangeFill,stroke:C.orange,size:29});
  s.box(398,555,294,125,'其余 18 层\nCSA2 + SWA',{fill:C.paper,stroke:C.purple,size:28});
  s.arrow([[545,498],[545,548]],C.purple);
  s.arrow([[699,620],[740,620],[740,500],[753,500]],C.purple);
  s.box(760,408,160,145,'H₂₀\n编码器\n末层输出',{fill:C.purpleFill,stroke:C.purple,size:25});
  s.arrow([[925,475],[965,475]],C.purple);
  s.rect(975,230,395,510,C.paper,C.purple);
  s.text(1172,260,'解码器',34,C.purple,'center',360);
  s.text(1172,310,'第 21–40 层',27,C.purple,'center',360);
  s.box(1005,365,335,110,'全局注意力\nKV 由 H₂₀ 投影得到',{fill:C.blueFill,stroke:C.blue,size:27});
  s.box(1005,540,335,125,'SWA 局部注意力\nKV 由本层隐藏状态生成',{fill:C.orangeFill,stroke:C.orange,size:25});
  s.arrow([[840,402],[840,192],[1172,192],[1172,226]],C.blue);
  s.text(1000,160,'层相关投影',23,C.blue,'center',300);
  s.arrow([[1172,745],[1172,805]],C.purple);
  s.box(975,815,395,112,'decode\n逐步生成输出',{fill:C.greenFill,stroke:C.green,size:28});
  s.note(60,820,820,108,'Decoder 的全局 KV 可从编码器输出获得；\n开始生成前，仍需准备各解码器层的 SWA KV。',C.purple,C.purpleFill,28);
  return s;
}

function cache(){
  const s=new Scene(2,'02-cache-management',1080,'缓存管理：长期保留与短期保留分开','SWA KV 缺失时，用一个窗口的重计算恢复近似状态','依据论文第 19–20 页；图中保留时间和主机内存比例来自论文部署描述。');
  s.text(305,190,'V4：持久化保存两类 KV',31,C.ink,'center',520);
  s.text(1050,190,'V4.1：按复用时间分开保存',31,C.ink,'center',640);
  s.rect(65,255,480,475,C.grayFill,C.gray);
  s.text(305,282,'持久化 KV 缓存 / SSD',28,C.ink,'center',450);
  s.box(100,350,410,135,'全局 KV\n完整保存命中的前缀',{fill:C.blueFill,stroke:C.blue,size:28});
  s.box(100,525,410,145,'SWA KV\n提示词末尾 + 输出末尾',{fill:C.orangeFill,stroke:C.orange,size:28});
  s.text(305,687,'典型负载下，两类均保留 >72 小时',22,C.muted,'center',460);
  s.arrow([[570,465],[735,465]],C.purple);
  s.text(650,412,'管理方式调整',24,C.purple,'center',190);
  s.box(775,255,600,175,'全局 KV → 持久化缓存\n保证至少 72 小时\n继续复用已缓存前缀',{fill:C.blueFill,stroke:C.blue,size:29});
  s.box(775,505,600,185,'编码器 SWA KV → 分布式内存池\n各机器提供 10% 主机 DRAM\nTTL 为分钟级，过期后及时回收',{fill:C.orangeFill,stroke:C.orange,size:28});
  s.arrow([[1075,695],[1075,740]],C.orange);
  s.note(775,750,600,150,'全局 KV 命中，SWA KV 未命中\n↓\nEncoder 回放最近 128 个 token',C.orange,C.orangeFill,27);
  s.note(65,790,630,110,'短期内存池仍保存编码器 SWA KV。\n运行时仍需要局部注意力状态。',C.purple,C.purpleFill,27);
  s.text(65,945,'Decoder SWA KV：每次 prefill 生成，仅供 decode，不用于前缀缓存。',27,C.ink,'left',1300);
  return s;
}

function truncation(){
  const s=new Scene(3,'03-bounded-replay-mask',1100,'有界回放：把局部注意力截断在回放片段内','只重算最近 n_win 个 token；高层状态接受近似恢复','依据论文第 9、20 页；上方长度不按比例，下方 W=4 为说明性算例；实际窗口为 128。');
  s.text(65,210,'精确恢复 L 层',29,C.ink,'left',330);
  s.box(415,198,950,70,'最近 L × n_win 个 token',{fill:C.purpleFill,stroke:C.purple,size:29});
  s.text(65,322,'有界回放',29,C.ink,'left',330);
  s.box(415,310,640,70,'更早的局部状态不参与本次回放',{fill:C.grayFill,stroke:C.gray,size:25});
  s.box(1070,310,295,70,'最近 n_win 个 token',{fill:C.orangeFill,stroke:C.orange,size:25});
  s.text(1080,392,'s：回放起点',24,C.orange,'left',280);
  s.text(65,475,'一个缩小的窗口示例：W = 4',31,C.ink,'left',600);
  s.text(65,540,'查询 i 只能关注 SWA keys：',28,C.ink,'left',580);
  s.note(65,590,570,85,'[ max(s, i − W + 1), i ]',C.purple,C.purpleFill,30);
  s.text(65,720,'① 起点前的局部 keys 被截断\n② 起点后的 SWA 仍保持因果性\n③ Encoder 仍复用已缓存的全局 KV',26,C.ink,'left',570);
  const x0=820,y0=570,cell=67;
  const cols=['s−3','s−2','s−1','s','s+1','s+2','s+3'];
  cols.forEach((t,j)=>s.text(x0+j*cell+29,y0-45,t,22,C.muted,'center',65));
  s.text(1020,465,'列：SWA key 的位置',25,C.muted,'center',510);
  ['s','s+1','s+2','s+3'].forEach((t,i)=>{
    s.text(x0-65,y0+i*cell+17,t,23,C.ink,'center',85);
    for(let j=0;j<7;j++){
      const allowed=j>=3&&j<=3+i; const cut=j<3&&j>=i;
      s.rect(x0+j*cell,y0+i*cell,58,58,allowed?C.orangeFill:cut?C.redFill:C.paper,allowed?C.orange:cut?C.red:'#d8d4dc');
      if(cut){s.line([[x0+j*cell+18,y0+i*cell+18],[x0+j*cell+40,y0+i*cell+40]],C.red,1.7);s.line([[x0+j*cell+40,y0+i*cell+18],[x0+j*cell+18,y0+i*cell+40]],C.red,1.7);}
      if(allowed)s.text(x0+j*cell+29,y0+i*cell+13,'✓',27,C.orange,'center',45);
    }
  });
  s.line([[x0+3*cell-7,y0-18],[x0+3*cell-7,y0+4*cell]],C.purple,2.3,true);
  s.text(763,864,'行：当前查询 i',23,C.muted,'left',260);
  s.rect(1035,880,25,25,C.orangeFill,C.orange);s.text(1072,876,'本次可见',23,C.ink,'left',260);
  s.rect(1035,923,25,25,C.redFill,C.red);s.text(1072,919,'被截断的历史',23,C.ink,'left',260);
  s.note(65,895,630,80,'回放末尾虽已覆盖完整窗口，高层状态仍可能近似。',C.purple,C.purpleFill,25);
  return s;
}

function encoder(){
  const s=new Scene(4,'04-encoder-replay',1080,'Encoder 回放：复用全局 KV，恢复局部状态','触发条件：全局 KV 已命中，但编码器 SWA KV 缺失','依据论文第 19–20 页；箭头表示处理关系，未缓存后缀与回放片段一起处理。');
  s.text(66,192,'当前请求',29,C.ink,'left',250);
  s.box(65,250,515,112,'已缓存前缀的更早部分',{fill:C.grayFill,stroke:C.gray,size:28});
  s.box(605,250,370,112,'前缀末尾 128 个 token\n需要回放',{fill:C.orangeFill,stroke:C.orange,size:26});
  s.box(1000,250,375,112,'未缓存后缀\n需要新计算',{fill:C.greenFill,stroke:C.green,size:28});
  s.text(790,383,'回放片段',24,C.orange,'center',340);
  s.text(1185,383,'新输入',24,C.green,'center',340);
  s.box(65,490,450,170,'命中的前缀全局 KV\n读取并复用\n不重算，也不覆盖',{fill:C.blueFill,stroke:C.blue,size:29});
  s.rect(605,465,770,235,C.purpleFill,C.purple);
  s.text(990,485,'编码器：一起处理两个片段',30,C.purple,'center',710);
  s.box(630,555,315,112,'回放前缀末尾\nSWA 限制在片段内',{fill:C.orangeFill,stroke:C.orange,size:26});
  s.box(1030,555,320,112,'处理未缓存后缀\n接续局部状态',{fill:C.greenFill,stroke:C.green,size:26});
  s.arrow([[790,415],[790,547]],C.orange);
  s.arrow([[1187,415],[1187,547]],C.green);
  s.arrow([[520,585],[599,585]],C.blue);
  s.text(565,539,'复用',23,C.blue,'center',95);
  s.arrow([[950,615],[1020,615]],C.purple);
  s.arrow([[788,707],[788,765]],C.orange);
  s.arrow([[1187,707],[1187,765]],C.green);
  s.box(605,775,370,130,'回放片段：\n只重新生成 SWA KV',{fill:C.orangeFill,stroke:C.orange,size:27});
  s.box(1000,775,375,130,'未缓存后缀：\n生成全局 KV + SWA KV',{fill:C.greenFill,stroke:C.green,size:25});
  s.text(65,790,'前缀全局 KV 保持原值。\n近似的是回放得到的\n局部 SWA 状态。',27,C.blue,'left',470);
  s.text(65,958,'后缀新生成的两类 KV 都受近似前缀状态影响，因此依赖缓存命中位置。',27,C.purple,'left',1320);
  return s;
}

function decoder(){
  const s=new Scene(5,'05-decoder-replay',1180,'Decoder 回放：每次 prefill 只处理末尾窗口','目标：为开始 decode 准备解码器 SWA KV','依据论文第 9、19–22 页；2560 与 128 为回放长度对比，不代表实测延迟加速倍数。');
  s.text(65,190,'完整提示词：已缓存前缀 + 未缓存后缀',30,C.ink,'left',1000);
  s.rect(65,255,1310,100,C.purpleFill,C.purple);
  s.text(515,290,'全局 KV 覆盖完整提示词',29,C.purple,'center',850);
  s.box(990,255,385,100,'取末尾 128 个 token\n对应的编码器输出',{fill:C.orangeFill,stroke:C.orange,size:26});
  s.arrow([[320,362],[320,450]],C.blue);
  s.arrow([[1182,362],[1182,450]],C.orange);
  s.box(65,460,510,155,'Decoder 全局 KV 的来源\n新位置：由编码器输出投影\n已缓存位置：直接复用',{fill:C.blueFill,stroke:C.blue,size:27});
  s.box(840,460,535,155,'末尾窗口经过 20 层 Decoder\nSWA 截断到回放片段内',{fill:C.orangeFill,stroke:C.orange,size:28});
  s.arrow([[320,620],[320,680]],C.blue);
  s.arrow([[1107,620],[1107,680]],C.orange);
  s.box(65,690,510,110,'解码器全局 KV',{fill:C.blueFill,stroke:C.blue,size:31});
  s.box(840,690,535,110,'解码器 SWA KV（近似）',{fill:C.orangeFill,stroke:C.orange,size:29});
  s.arrow([[320,805],[320,870],[560,870]],C.blue);
  s.arrow([[1107,805],[1107,870],[905,870]],C.orange);
  s.box(570,825,325,100,'开始 decode',{fill:C.greenFill,stroke:C.green,size:32});
  s.text(1037,925,'SWA KV 仅供解码\n不用于前缀缓存',26,C.orange,'center',540);
  s.note(65,995,1310,78,'精确恢复：20 × 128 = 2560 token     →     有界回放：128 token',C.purple,C.purpleFill,29);
  return s;
}

function storage(){
  const s=new Scene(6,'06-storage-reduction',1080,'持久化缓存约为 1/8：两项收益相乘','用 V4 持久化 KV 总量 = 100 个示意单位，解释论文中的近似比例','依据论文第 19 页；50、12.5 为按论文近似比例换算的说明值，不是额外实测数据。');
  s.text(65,203,'V4 持久化缓存',31,C.ink,'left',370);
  s.box(420,190,460,100,'全局 KV ≈ 50',{fill:C.blueFill,stroke:C.blue,size:30});
  s.box(880,190,460,100,'SWA KV ≈ 50',{fill:C.orangeFill,stroke:C.orange,size:30});
  s.text(65,244,'合计 100',27,C.muted,'left',320);
  s.arrow([[900,310],[900,385]],C.purple);
  s.text(930,327,'移除持久化 SWA KV',27,C.orange,'left',430);
  s.text(65,423,'仅保留全局 KV',31,C.ink,'left',370);
  s.box(420,410,460,100,'全局 KV ≈ 50',{fill:C.blueFill,stroke:C.blue,size:30});
  s.rect(900,410,440,100,C.paper,C.gray,true);
  s.text(1120,432,'编码器 SWA 改存短期内存池\n不计入这组持久化容量',24,C.muted,'center',415);
  s.arrow([[650,530],[650,605]],C.purple);
  s.text(680,548,'全局 KV 再压缩到对应部分的约 1/4',27,C.blue,'left',660);
  s.text(65,643,'V4.1 持久化缓存',31,C.ink,'left',370);
  s.rect(420,630,115,100,C.blueFill,C.blue);
  s.text(565,659,'≈ 12.5 = 原总量的 1/8',31,C.blue,'left',710);
  s.note(65,795,1275,100,'约 1/2（移除持久化 SWA KV） × 约 1/4（全局 KV 压缩） = 约 1/8',C.purple,C.purpleFill,29);
  s.text(65,945,'比较范围：相同工作负载下的持久化 KV 缓存；短期内存池与运行时 SWA 状态仍存在。',26,C.muted,'left',1320);
  return s;
}

async function main(){
 fs.mkdirSync(OUT,{recursive:true});fs.mkdirSync(path.join(ROOT,'tmp','diagrams'),{recursive:true});
 const manifest=[];
 for(const fn of [architecture,cache,truncation,encoder,decoder,storage])manifest.push(await fn().save());
 fs.writeFileSync(path.join(OUT,'manifest.json'),JSON.stringify(manifest,null,2));
 console.log(JSON.stringify(manifest,null,2));
}
main().catch(e=>{console.error(e);process.exit(1)});
