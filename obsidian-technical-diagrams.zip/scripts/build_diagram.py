"""Build a styled SVG and an editable scene from a diagram JSON specification.

Usage: python build_diagram.py spec.json --out OUTPUT_DIR [--overwrite]
Finish with finalize_diagram.cjs to measure native fonts and export PNG/Obsidian.
"""
from pathlib import Path
import argparse
import hashlib
import html
import json
import math
import random
import re
import unicodedata

SKILL = Path(__file__).resolve().parents[1]
PALETTE = json.loads((SKILL / "assets/palette.json").read_text(encoding="utf-8"))
GENERATOR = "obsidian-technical-diagrams/v1"
FONT = "Comic Sans MS, KaiTi, STKaiti, Microsoft YaHei, sans-serif"


def color(value):
    value = PALETTE.get(value, value)
    if value == "none":
        return "transparent"
    if value != "transparent" and not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
        raise ValueError(f"Unsupported color: {value!r}; use palette name, #RRGGBB or transparent")
    return value


def esc(value):
    return html.escape(str(value), quote=True)


class Diagram:
    def __init__(self, spec):
        self.spec = spec
        self.name = spec["name"]
        self.w, self.h = spec.get("width", 1600), spec.get("height", 1000)
        self.items, self.svg = [], []
        self.random = random.Random(spec.get("seed", 710))

    def base(self, kind, x, y, w, h, stroke="ink", fill="transparent", sw=2):
        if min(w, h) < 0:
            raise ValueError("Shape dimensions cannot be negative")
        n = len(self.items)
        return dict(id=hashlib.sha256(f"{self.name}:{n}".encode()).hexdigest()[:8],
                    type=kind, x=x, y=y, width=w, height=h, angle=0,
                    strokeColor=color(stroke), backgroundColor=color(fill), fillStyle="solid",
                    strokeWidth=sw, strokeStyle="solid", roughness=1.2, opacity=100,
                    groupIds=[], frameId=None, roundness=None, seed=10000+n, version=1,
                    versionNonce=20000+n, isDeleted=False, boundElements=None, updated=1,
                    link=None, locked=False)

    def poly(self, pts, stroke, sw=2, dashed=False):
        xy = " ".join(f"{x+self.random.uniform(-.7,.7):.2f},{y+self.random.uniform(-.7,.7):.2f}" for x, y in pts)
        dash = ' stroke-dasharray="8 7"' if dashed else ""
        self.svg.append(f'<polyline points="{xy}" fill="none" stroke="{color(stroke)}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"{dash}/>')

    def rect(self, x, y, w, h, fill="paper", stroke="ink", dashed=False, sw=2.2):
        e = self.base("rectangle", x, y, w, h, stroke, fill, sw)
        if dashed:
            e["strokeStyle"] = "dashed"
        self.items.append(e)
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color(fill)}"/>')
        self.poly([(x,y),(x+w/2,y-.6),(x+w,y),(x+w+.5,y+h/2),(x+w,y+h),(x+w/2,y+h+.6),(x,y+h),(x-.5,y+h/2),(x,y)], stroke, sw, dashed)

    def text(self, x, y, text, size=28, stroke="ink", align="left", max_width=None):
        lines = text.split("\n")
        line_height = 1.35
        width = max(sum(1 if unicodedata.east_asian_width(c) in ("W", "F") else .6 for c in line) for line in lines)*size
        offset = width/2 if align == "center" else width if align == "right" else 0
        e = self.base("text", x-offset, y, width, len(lines)*size*line_height, stroke)
        e.update(text=text, originalText=text, fontSize=size, fontFamily=1, textAlign=align,
                 verticalAlign="top", containerId=None, autoResize=True, lineHeight=line_height,
                 customData={"layout": {"anchorX": x, "top": y, "align": align,
                                        "maxWidth": max_width}})
        self.items.append(e)
        anchor = {"left": "start", "center": "middle", "right": "end"}[align]
        spans = "".join(f'<tspan x="{x}" dy="{size*line_height if i else 0}">{esc(line)}</tspan>' for i, line in enumerate(lines))
        self.svg.append(f'<text data-element-id="{e["id"]}" x="{x}" y="{y+size*.86}" fill="{color(stroke)}" font-family="{FONT}" font-size="{size}" text-anchor="{anchor}">{spans}</text>')

    def line(self, pts, stroke="ink", sw=2.5, dashed=False, arrow=False):
        if len(pts) < 2:
            raise ValueError("A line needs two or more points")
        x, y = pts[0]
        e = self.base("arrow" if arrow else "line", x, y,
                      max(p[0] for p in pts)-min(p[0] for p in pts),
                      max(p[1] for p in pts)-min(p[1] for p in pts), stroke, "transparent", sw)
        e.update(points=[[a-x,b-y] for a,b in pts], lastCommittedPoint=None,
                 startBinding=None,endBinding=None,startArrowhead=None,
                 endArrowhead="arrow" if arrow else None)
        if arrow:
            e["elbowed"] = False
        if dashed:
            e["strokeStyle"] = "dashed"
        self.items.append(e)
        self.poly(pts, stroke, sw, dashed)
        if arrow:
            a,b = pts[-2],pts[-1]
            t = math.atan2(b[1]-a[1],b[0]-a[0])
            self.poly([(b[0]-16*math.cos(t-.45),b[1]-16*math.sin(t-.45)),b,
                       (b[0]-16*math.cos(t+.45),b[1]-16*math.sin(t+.45))],stroke,sw)

    def ellipse(self,x,y,w,h,fill="paper",stroke="ink"):
        self.items.append(self.base("ellipse",x,y,w,h,stroke,fill))
        self.svg.append(f'<ellipse cx="{x+w/2}" cy="{y+h/2}" rx="{w/2}" ry="{h/2}" fill="{color(fill)}" stroke="{color(stroke)}" stroke-width="2.2"/>')

    def compose(self):
        s=self.spec
        self.text(64,42,s["title"],s.get("titleSize",44),max_width=self.w-128)
        if s.get("subtitle"):
            self.text(66,108,s["subtitle"],26,"muted",max_width=self.w-132)
        self.line([[64,165],[self.w-64,165]],"purple",2)
        for obj in s["objects"]:
            kind=obj["type"]
            if kind=="box":
                x,y,w,h=(obj[k] for k in ("x","y","width","height"))
                self.rect(x,y,w,h,obj.get("fill","paper"),obj.get("stroke","ink"),obj.get("dashed",False))
                size=obj.get("fontSize",28);content=obj["text"]
                self.text(x+w/2,y+(h-len(content.split('\n'))*size*1.35)/2,content,size,
                          obj.get("textColor","ink"),"center",w-2*obj.get("padding",20))
            elif kind=="text":
                self.text(obj["x"],obj["y"],obj["text"],obj.get("fontSize",28),
                          obj.get("color","ink"),obj.get("align","left"),obj.get("maxWidth"))
            elif kind=="rect":
                self.rect(obj["x"],obj["y"],obj["width"],obj["height"],obj.get("fill","paper"),obj.get("stroke","ink"),obj.get("dashed",False))
            elif kind in ("line","arrow"):
                self.line(obj["points"],obj.get("color","ink"),obj.get("strokeWidth",2.5),obj.get("dashed",False),kind=="arrow")
            elif kind=="ellipse":
                self.ellipse(obj["x"],obj["y"],obj["width"],obj["height"],obj.get("fill","paper"),obj.get("stroke","ink"))
            else:
                raise ValueError(f"Unknown object type: {kind}")
        if s.get("takeaway"):
            self.text(66,self.h-140,s["takeaway"],27,"purple",max_width=self.w-132)
        self.line([[64,self.h-76],[self.w-64,self.h-76]],"divider",1.2)
        self.text(66,self.h-53,s["source"],21,"muted",max_width=self.w-132)

    def save(self,out,overwrite=False):
        targets=[out/(self.name+ext) for ext in (".svg",".excalidraw")]
        if not overwrite and any(p.exists() for p in targets):
            raise FileExistsError("Existing drawing: choose a new name or back up and use --overwrite")
        out.mkdir(parents=True,exist_ok=True)
        dots='<defs><pattern id="dots" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r=".8" fill="#dbd5e1" opacity=".6"/></pattern></defs>'
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}"><title>{esc(self.spec["title"])}</title>{dots}<rect width="100%" height="100%" fill="{PALETTE["paper"]}"/><rect width="100%" height="100%" fill="url(#dots)"/>'+"\n".join(self.svg)+"</svg>"
        scene=dict(type="excalidraw",version=2,source="https://excalidraw.com",elements=self.items,
                   appState=dict(viewBackgroundColor=PALETTE["paper"],gridSize=None,theme="light",exportBackground=True),files={},
                   customData=dict(generator=GENERATOR,canvasWidth=self.w,canvasHeight=self.h,needsNativeMeasurement=True))
        targets[0].write_text(svg,encoding="utf-8")
        targets[1].write_text(json.dumps(scene,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        print(f"Built {self.name}: {len(self.items)} editable elements. Native measurement / PNG / Obsidian export still required.")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec",type=Path);parser.add_argument("--out",required=True,type=Path)
    parser.add_argument("--overwrite",action="store_true")
    args=parser.parse_args()
    spec=json.loads(args.spec.read_text(encoding="utf-8-sig"))
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]*",spec["name"]):
        raise ValueError("name must be a filename stem using ASCII letters, digits, hyphens or underscores")
    if not spec.get("source"):
        raise ValueError("Provide a real source label or explicitly label a conceptual example")
    diagram=Diagram(spec);diagram.compose();diagram.save(args.out,args.overwrite)


if __name__=="__main__":
    main()
