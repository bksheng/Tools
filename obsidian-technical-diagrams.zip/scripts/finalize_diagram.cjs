// Native font measurement, reopen validation, PNG export and Obsidian companion.
// node finalize_diagram.cjs FILE.excalidraw --modules DIR/node_modules
//   [--modules OTHER/node_modules] [--browser /path/to/chromium] [--overwrite]
const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert/strict');
const args=process.argv.slice(2),file=args.shift();
if(!file||file==='--help'){
  console.log('Usage: node finalize_diagram.cjs FILE.excalidraw --modules DIR/node_modules [--modules DIR] [--browser PATH] [--overwrite]');
  process.exit(file?0:1);
}
const roots=[];let executablePath,overwrite=false;
while(args.length){const flag=args.shift();if(flag==='--modules')roots.push(path.resolve(args.shift()));else if(flag==='--browser')executablePath=path.resolve(args.shift());else if(flag==='--overwrite')overwrite=true;else throw new Error('Unknown argument: '+flag);}
function dependency(name){
  for(const root of roots){const candidate=path.join(root,name);if(fs.existsSync(candidate))return require(candidate);}
  try{return require(name);}catch{throw new Error(`Missing ${name}; supply a node_modules directory with --modules. See references/generation.md.`);}
}
function packageDir(name){
  for(const root of roots){const p=path.join(root,name);if(fs.existsSync(p))return p;}
  throw new Error('Missing package directory: '+name);
}
const source=path.resolve(file),dir=path.dirname(source),stem=path.basename(source,'.excalidraw');
const svgPath=path.join(dir,stem+'.svg'),pngPath=path.join(dir,stem+'.png'),mdPath=path.join(dir,stem+'.excalidraw.md');
const qa=path.join(dir,'_qa',stem);
if(!overwrite&&(fs.existsSync(pngPath)||fs.existsSync(mdPath)))throw new Error('Existing exports: back up first, then use --overwrite.');
const scene=JSON.parse(fs.readFileSync(source,'utf8'));
assert.equal(scene.customData?.generator,'obsidian-technical-diagrams/v1','Use this finalizer only for build_diagram.py output; repair existing user drawings separately.');
assert.ok(scene.elements.every(e=>e.backgroundColor!=='none'&&e.strokeColor!=='none'),'Invalid SVG color sentinel in scene');
assert.ok(scene.elements.every(e=>e.type!=='image'),'The diagram must contain editable objects');
assert.equal(new Set(scene.elements.map(e=>e.id)).size,scene.elements.length,'Duplicate IDs');

async function main(){
  const {chromium}=dependency('playwright'),esbuild=dependency('esbuild');
  const prod=path.join(packageDir('@excalidraw/excalidraw'),'dist/prod');
  fs.mkdirSync(qa,{recursive:true});
  await esbuild.build({stdin:{contents:`import {restoreElements,exportToCanvas} from ${JSON.stringify(path.join(prod,'index.js').replace(/\\/g,'/'))};window.sceneTools={restoreElements,exportToCanvas};`,resolveDir:dir},
    outfile:path.join(qa,'bundle.js'),bundle:true,format:'iife',platform:'browser',define:{'process.env.NODE_ENV':'"production"'}});
  const server=http.createServer((req,res)=>{
    const url=decodeURIComponent(req.url.split('?')[0]);
    if(url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');return res.end('<script>window.EXCALIDRAW_ASSET_PATH="/assets/";</script><script src="/bundle.js"></script>');}
    let p;
    if(url==='/bundle.js')p=path.join(qa,'bundle.js');
    else if(url.startsWith('/assets/')){
      p=path.resolve(prod,url.slice(8));
      if(!p.startsWith(path.resolve(prod)+path.sep)){res.statusCode=403;return res.end();}
    }else{res.statusCode=404;return res.end();}
    if(!fs.existsSync(p)){res.statusCode=404;return res.end();}
    res.setHeader('Content-Type',p.endsWith('.js')?'text/javascript':p.endsWith('.woff2')?'font/woff2':'application/octet-stream');
    fs.createReadStream(p).pipe(res);
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  let browser;
  try{
    browser=await chromium.launch({headless:true,...(executablePath?{executablePath}:{})});
    const context=await browser.newContext();
    await context.route('**/*',route=>route.request().url().startsWith('http://127.0.0.1:')?route.continue():route.abort());
    const page=await context.newPage();
    await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>!!window.sceneTools);
    const originalTexts=scene.elements.filter(e=>e.type==='text').map(e=>e.text);
    const result=await page.evaluate(async scene=>{
      const api=window.sceneTools;
      await api.exportToCanvas({elements:api.restoreElements(scene.elements,null),appState:scene.appState,files:scene.files,maxWidthOrHeight:100});
      await document.fonts.ready;
      const measured=api.restoreElements(scene.elements,null,{repairBindings:true,refreshDimensions:true});
      if(measured.length!==scene.elements.length)throw new Error('Native import dropped elements');
      const issues=[];
      for(const e of scene.elements){
        if(e.type!=='text')continue;
        const m=measured.find(x=>x.id===e.id),layout=e.customData.layout;
        if(m.text!==e.originalText)throw new Error('Native reflow changed explicit text lines: '+e.id);
        e.width=m.width;e.height=m.height;
        e.x=layout.anchorX-(layout.align==='center'?e.width/2:layout.align==='right'?e.width:0);
        e.y=layout.top;
        if(layout.maxWidth&&e.width>layout.maxWidth+1)issues.push({id:e.id,text:e.text,reason:'native text exceeds layout maxWidth',actual:e.width,limit:layout.maxWidth});
        if(e.x<0||e.y<0||e.x+e.width>scene.customData.canvasWidth||e.y+e.height>scene.customData.canvasHeight)issues.push({id:e.id,text:e.text,reason:'outside native canvas'});
      }
      const texts=scene.elements.filter(e=>e.type==='text');
      for(let i=0;i<texts.length;i++)for(let j=i+1;j<texts.length;j++){
        const a=texts[i],b=texts[j],dx=Math.min(a.x+a.width,b.x+b.width)-Math.max(a.x,b.x),dy=Math.min(a.y+a.height,b.y+b.height)-Math.max(a.y,b.y);
        if(dx>2&&dy>2)issues.push({ids:[a.id,b.id],reason:'native text boxes overlap',dx,dy});
      }
      const reopened=api.restoreElements(JSON.parse(JSON.stringify(scene.elements)),null,{repairBindings:true,refreshDimensions:true});
      if(JSON.stringify(reopened.filter(e=>e.type==='text').map(e=>e.text))!==JSON.stringify(texts.map(e=>e.text)))throw new Error('Reopen introduced wrapping');
      const canvas=await api.exportToCanvas({elements:reopened,appState:{...scene.appState,exportBackground:true,exportWithDarkMode:false},files:scene.files,maxWidthOrHeight:1800});
      return {scene,issues,preview:canvas.toDataURL(),fontFamilies:[...new Set(texts.map(e=>e.fontFamily))]};
    },scene);
    fs.writeFileSync(path.join(qa,'native-preview.png'),Buffer.from(result.preview.split(',')[1],'base64'));
    assert.deepEqual(result.scene.elements.filter(e=>e.type==='text').map(e=>e.text),originalTexts);
    const svg=fs.readFileSync(svgPath,'utf8');
    const {canvasWidth:w,canvasHeight:h}=scene.customData;
    // Separate SVG rendering context: it must not replace the native JS harness.
    const raster=await browser.newContext({viewport:{width:w,height:h},deviceScaleFactor:Math.max(1.5,2160/w)});
    await raster.route('**/*',route=>route.abort());
    const rasterPage=await raster.newPage();
    await rasterPage.setContent('<html><head><style>html,body{margin:0;padding:0}svg{display:block}</style></head><body>'+svg+'</body></html>');
    await rasterPage.evaluate(()=>document.fonts.ready);
    const svgIssues=await rasterPage.evaluate(layouts=>{
      const issues=[];
      for(const t of document.querySelectorAll('text[data-element-id]')){
        const layout=layouts[t.getAttribute('data-element-id')],box=t.getBBox();
        if(layout.maxWidth&&box.width>layout.maxWidth+1)issues.push({id:t.getAttribute('data-element-id'),reason:'SVG text exceeds layout maxWidth',actual:box.width,limit:layout.maxWidth});
      }
      return issues;
    },Object.fromEntries(scene.elements.filter(e=>e.type==='text').map(e=>[e.id,e.customData.layout])));
    const check={nativeImport:true,fontReload:true,explicitLineBreaksPreserved:true,nativeReopen:true,
      nativeIssues:result.issues,svgIssues,editableElements:scene.elements.length,
      sourceFonts:'Comic Sans MS, KaiTi, STKaiti, Microsoft YaHei, sans-serif',nativeFontFamilies:result.fontFamilies,
      requiresVisualReview:true};
    fs.writeFileSync(path.join(qa,'checks.json'),JSON.stringify(check,null,2));
    await rasterPage.locator('svg').screenshot({path:path.join(qa,'export-preview.png')});
    if(result.issues.length||svgIssues.length)throw new Error('Layout issues found. Inspect _qa previews/checks.json, revise the specification, and rebuild.');
    result.scene.customData.needsNativeMeasurement=false;
    const json=JSON.stringify(result.scene,null,2)+'\n';
    fs.writeFileSync(source,json);
    const textSection=result.scene.elements.filter(e=>e.type==='text').map(e=>`${e.text} ^${e.id}`).join('\n\n');
    const note='---\nexcalidraw-plugin: parsed\ntags:\n  - excalidraw\n---\n\n# Excalidraw Data\n\n## Text Elements\n\n'+textSection+'\n\n%%\n## Drawing\n\n```json\n'+json+'```\n%%\n';
    assert.deepEqual(JSON.parse(note.match(/```json\n([\s\S]*?)\n```/)[1]),result.scene);
    fs.writeFileSync(mdPath,note);
    fs.copyFileSync(path.join(qa,'export-preview.png'),pngPath);
    await raster.close();
    console.log(JSON.stringify({scene:source,obsidian:mdPath,svg:svgPath,png:pngPath,nativePreview:path.join(qa,'native-preview.png'),checks:path.join(qa,'checks.json'),status:'Structural and native reflow checks passed; inspect both previews visually.'},null,2));
  }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
