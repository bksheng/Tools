# 可运行生成流程

`build_diagram.py` 用一个 JSON 对象模型构建 SVG 与标准 Excalidraw，`finalize_diagram.cjs` 使用实际 Excalidraw 0.18 字体测量与重新导入，并生成 PNG/Obsidian。它是适合架构、流程、对比图的最小工具；复杂矩阵可展开成 rect/text 数组，复杂科学曲线可另用合适工具，但仍需满足主 skill 的可编辑与验证要求。

## 依赖与调用

Python 生成器仅用标准库。Node 完成器需要 `@excalidraw/excalidraw@0.18.0`、`react@18`、`react-dom@18`、`esbuild` 和 `playwright`。优先复用可用的工作区运行时；可调用环境的 workspace dependency discovery，或检查任务已有依赖。不要把本案例的绝对路径写进新任务。

如确实缺依赖，在任务临时目录安装；不要在 skill 目录或用户笔记库安装：

```powershell
npm install --prefix ./tmp/diagram-runtime --no-audit --no-fund @excalidraw/excalidraw@0.18.0 react@18 react-dom@18 esbuild playwright
```

使用已有可用 Chromium 时通过 `--browser` 指定真实路径。否则用对应 Playwright CLI 安装 Chromium。浏览器仅用于本地导入与渲染，不上传报告内容；完成器阻止外部网络访问。缺少依赖或浏览器时应完成可独立完成的图形规格，明确缺失验证，不跳过检查后宣称完成。

命令中的 `<skill>` 指本 skill 实际目录：

```powershell
python <skill>/scripts/build_diagram.py ./diagram-spec.json --out ./diagrams
node <skill>/scripts/finalize_diagram.cjs ./diagrams/01-cache-decision.excalidraw --modules ./tmp/diagram-runtime/node_modules --browser <实际Chromium路径>
```

可重复传入 `--modules` 以复用多个 node_modules 目录。修改已生成图形规格后，先按需要备份，再分别传 `--overwrite` 重建并完成；脚本不会默认覆盖已存在的交付物。完成器仅接受此生成器创建的场景；修改既有用户绘图使用 repair.md 流程。

## JSON 规格

参见 `assets/example-spec.json`。顶层字段：

- `name`：ASCII 文件名，字母/数字/连字符/下划线；不同图用不同 name。
- `width` / `height`：默认 1600/1000；`title` 必填，`subtitle` 可选。
- `source`：真实材料依据，或清楚标注“说明性示例”；`takeaway` 可选。
- `objects`：按画图顺序排列，底层框先于覆盖其上的文字。边距与标题/页脚空间由作者负责。

正文建议在 y=210 至 height−190 范围内。六类对象：

| type | 必需字段 | 可选字段 |
| --- | --- | --- |
| `box` | x,y,width,height,text | fill,stroke,textColor,fontSize,padding,dashed |
| `rect` | x,y,width,height | fill,stroke,dashed |
| `text` | x,y,text | color,fontSize,align,maxWidth |
| `line` / `arrow` | points（至少两组 [x,y]） | color,strokeWidth,dashed |
| `ellipse` | x,y,width,height | fill,stroke |

颜色接受 palette.json 的名称（如 `blueFill`）或六位色值；透明值使用 `transparent`。`text` 的 x 是 align 指定的左/中/右锚点，y 是文本顶端；`maxWidth` 是布局约束，不会用它强制折行。`box` 为独立矩形和自由文本，文字默认居中；多行用明确 `\n`。这使各元素易于摘取，也避免隐式容器换行。需要原生绑定文本时自行实现并额外测试。

## 检查与迭代

完成器测量实际 native 字体后再确定 width/height 和 x；检查文本区间碰撞、越界、maxWidth、字符串与明确换行；然后走原生重开/刷新路径检查不重新折行。SVG 由另一页面按导出字体测量并截图为高清 PNG。

检查 `_qa/<图名>/checks.json`、`native-preview.png`、`export-preview.png`。发现布局问题时应调整图形规格的间距、框尺寸或明确分行，不要只在最后 PNG 上涂改。自动检查不能识别所有箭头穿字、中文缺字或语义错误，因此仍要查看实际图像。

通过检查的交付物为 `<name>.png/.svg/.excalidraw/.excalidraw.md`，全部共享语义与配色。保留规格和检查结果便于维护；`_qa` 预览与打包依赖不应作为最终图混入报告。多图生成相对链接的索引，并按需要制作总览。若用户要可搬移资料包，排除运行时 node_modules，仅打包图、索引、规格及必要报告。
