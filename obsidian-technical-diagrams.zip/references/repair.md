# 现有绘图修复

1. 确认实际路径；用户粘贴的 `.excalidraw\.md` 可能实际为 `.excalidraw.md`。列出授权目录内的绘图，比较异常/正常版本及同名 PNG/SVG。不要扫描无关笔记。
2. 在项目备份目录保存原始字节与相对路径，记录哈希。不要把备份绘图放在待扫描目录内造成递归重复修复。写入前重查哈希；文件已被用户/Obsidian 改动时重新读取后做最小修复。
3. `.excalidraw` 是标准 JSON；笔记中 `## Drawing` 后可能是 fenced `json`，也可能是 `compressed-json`。后者为 LZ-String Base64，解压前去掉块内空白。重新压缩后解析回读，确认 scene 等价。不要把压缩内容当普通 Base64 JSON。
4. 保留笔记绘图区之外的文本、YAML、块引用和评论。仅修改目标属性；不重建 ID，不改变图形位置、箭头绑定、配色、主题或用户内容，除非所修问题需要。图中文字的语义变更应同步文本区，但纯布局修复不应重写文本区。

## 黑色底框

检查所有元素的 `backgroundColor` / `strokeColor`，包括闭合的 `line` 元素。有些 SVG 转换器先画浅色 `rect`，再画闭合 `polyline` 边框；若后者的原生 `backgroundColor` 是 `none`，Canvas 会呈黑色并盖住下面的浅色。

`none` → `transparent`，保留现有合法浅色。不要统一把所有框改成白色；也不要把深色主题当成原因而强行改主题。SVG 自身的 `fill="none"` 是合法的，不要错误地全局替换每种格式。

## 自动换行压字

诊断信号：`text` 为 `普通\nSWA`，`originalText` 为 `普通 SWA`，`autoResize: false`，以及短数字 `9\n8`。原因通常是按楷体测宽却由 Virgil/中文回退渲染，固定框不足。

- 先比较 `text`、`originalText`、SVG 文本、笔记文本区与用户编辑。只有差异纯属自动折行时恢复 `originalText`；不能用它覆盖改过的词句。若存在真实文案差异，以当前用户内容为准。
- 自由文本可改 `autoResize: true`。保留 `originalText` 中明确的 `\n`，这些通常是有意的多行排版。
- 加载真实字体后测量宽高，按原有左/中/右锚点重新定位。不要把所有居中文本当左对齐，或机械加倍宽度；过大的包围框也会影响摘取和布局。
- `containerId` 非空的绑定文本仍受容器宽度约束；单独评估加宽框、明确分行或调整布局，不盲目解绑。
- 本地 Excalidraw 0.18 中 `restoreElements(...,{repairBindings:true,refreshDimensions:true})` 才会进入文本尺寸刷新；只给 `refreshDimensions:true` 不够。预加载字体后再调用。
- 修复后再次按编辑器的字体刷新路径导入，确认字符串及行数保持预期，并看原生渲染；静态 PNG 与旧 JSON 成功解析不能证明修复成功。

同步处理授权范围内的同名 `.excalidraw` 与 `.excalidraw.md`，两者可能有各自编辑，逐个修改，不能直接相互覆盖。检查生成代码，修正 `none` 和固定宽度设置以防再生；不要借机运行生成脚本覆盖全部用户成果。
