---
name: obsidian-technical-diagrams
description: "Create and repair editable Obsidian / Excalidraw hand-drawn technical diagrams from papers, reports, or complex mechanisms, using this user's warm-paper pastel style. Use for requests for Obsidian手绘图、Excalidraw图解、论文原理图、技术手绘说明 or the established hand-drawn report style. Includes PNG, SVG, .excalidraw and .excalidraw.md, with native font/layout checks. Not for generic illustration or unrelated Obsidian note management."
---

# Obsidian 技术手绘图解

把论文或技术说明转成可读、可编辑、可摘取的原理图。默认沿用用户已确认的 SWA 图解视觉：暖白纸、轻手绘线条、浅色填充、楷体中文、手写英文、低饱和蓝橙紫绿。主题可以是任何技术，不把 SWA 的内容或图数量套到其他任务上。用户本次指定的风格、格式与范围优先。

## 内容与图形

1. 先读用户提供的材料，提取要解释的机制、前提、依赖方向、边界与证据位置。不要仅凭标题补全论文结论。没有可访问的材料时，可先组织图解问题，依赖材料的结论需等待内容或明确标为假设。
2. 每图回答一个具体问题。按需要选架构图、时序/生命周期图、依赖展开、可见性矩阵、流程对照或收益拆分。不要为了凑图而重复同一解释。图注写清：什么来自材料、什么是作者推导、什么只是缩小后的教学例子。
3. 使用 [references/style.md](references/style.md) 的色板、字体、布局和语义约定。跨图保持同一概念同色；对其他主题重新定义色彩角色，不能把“蓝色=Global KV”当作普遍含义。
4. 新建图优先从共享对象模型同时生成 SVG 与原生 Excalidraw。现成 SVG 可转换，但必须真正保留可编辑的文本、矩形、连线/箭头；不要把整张图片嵌入后称为可编辑源文件。

## 生成与交付

阅读 [references/generation.md](references/generation.md)，按需求编写图形规格或使用其他合适的原生绘图实现。可复用：

- [scripts/build_diagram.py](scripts/build_diagram.py)：从 JSON 图形规格生成暖白手绘 SVG 和原生场景；仅依赖 Python 标准库。
- [scripts/finalize_diagram.cjs](scripts/finalize_diagram.cjs)：加载 Excalidraw 实际字体、校正文本宽高与锚点、模拟重新打开、导出高清 PNG 与 Obsidian 绘图笔记。依赖安装在任务临时目录，不放进 skill。
- [assets/example-spec.json](assets/example-spec.json)：完整可运行的通用“缓存命中/缺失”示例，是布局起点，不是论文事实。
- [assets/palette.json](assets/palette.json)：机器可读色板。

默认每图同名交付 `.png`、`.svg`、`.excalidraw`、`.excalidraw.md`，PNG 宽度至少 2160，普通 1600 宽画布导出 2400 宽。用户只要求特定格式时按请求缩减。多图附相对路径索引；需要摘取时提供总览。仅在请求包含报告时编排或修改报告。既有文件先备份，报告和图片之间用可搬移的相对链接。

## 两个必须避免的兼容性问题

- **透明色**：SVG 中 `fill="none"` / `stroke="none"` 转入原生场景后必须为 `"transparent"`。原生色彩字段不允许 `"none"`；闭合折线的无效填充会盖住浅色方框并呈黑色。
- **字体与换行**：PNG/SVG 使用的楷体宽度不能作为 Excalidraw 固定宽度。原生自由文本默认 `autoResize: true`；在字体加载完毕后按原生字体测量并恢复左右/中心锚点。需要换行时写明确的 `\n`，保留这些换行。绑定到容器的文本仍可能自动折行，需单独校验；不要对所有文本盲目取消换行或缩小字号。

## 验证与修复

JSON 能解析和 SVG 好看不足以证明 Obsidian 显示正常。交付前应完成原生字体加载、文本重新测量、重新导入并渲染，检查内容不变、短标签不换行、标题和坐标不互压、框内文字不越界、箭头方向和颜色语义正确。看实际 PNG 与原生编辑预览；有布局问题就调整图形规格后重做相关图。

编辑已有目录时，先读 [references/repair.md](references/repair.md)。兼容 Obsidian `json` 与 `compressed-json`，保留文本区、元素 ID、用户编辑和画布状态。优先修复最小字段集合，同步同图的标准场景与笔记，并检查同目录的同类问题。不要用旧备份整图覆盖用户当前绘图。

如果无法进行原生渲染，保留已有结果并明确报告尚未验证的格式；不要称“已通过 Obsidian 检查”。工具可用时直接完成生成、检查与修复，不增加无依据的审批步骤。
