# SWA Bounded Replay 技术报告（手绘图解版）

**基于论文：** *DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression*  
**作者与版本：** DeepSeek-AI，arXiv:2609.19969v1，2026 年 9 月 17 日  
**用途：** 会议技术分享  
**原文：** [本地 PDF](2609.19969v1.pdf) · [arXiv 页面](https://arxiv.org/abs/2609.19969v1)

> 本报告按技术逻辑整理全文中与 SWA Bounded Replay 直接相关的内容，重点对应第 2.2、3.2.1、3.2.2 和 6 节，并补充理解这些内容所需的架构与配置。正文以原文的中文转述为主，英文引文保留原句；用于说明的算例明确标注。页码均指论文 PDF 页码。

> **配图说明：** 新增 6 张 Excalidraw 风格的解释性示意图，均依据论文内容重绘。蓝色表示全局 KV，橙色表示 SWA 或回放片段，紫色表示架构与处理过程，绿色表示新计算或后续生成。配图与可编辑源文件位于同级 `assets/swa-bounded-replay/` 目录。

## 1. 会议开场摘要

SWA Bounded Replay 是 DeepSeek-V4.1-Flash 的一项部署优化：**只重新计算最近一个滑动窗口内的 token，近似重建所需的 SWA KV 状态。** 论文中滑动窗口大小为 128，因此一次有界回放处理最近的 128 个 token。这里的“回放”指重新执行这些已有 token 的前向计算。〔第 5、20、22 页〕

它解决两个问题。**Encoder SWA Bounded Replay** 用于全局 KV 缓存命中、编码器 SWA KV 缺失的情况，使前缀缓存的复用只依赖持久保存的全局 KV。编码器 SWA KV 可以保存在分钟级的短期内存池中，缺失时以少量重计算恢复。**Decoder SWA Bounded Replay** 在每次 prefill 时只让提示词末尾一个窗口的编码器输出经过解码器，为开始生成准备 SWA KV，配合因果编码器—解码器架构，将总体 prefill 计算量减少近一半。〔第 9、19–20 页〕

存储收益来自两项相乘的改进：移除持久化缓存中的 SWA KV，使容量需求减少近一半；架构与精度优化再将其中的全局 KV 压缩到 V4 对应部分的约 1/4。两者共同使 V4.1 在相同工作负载下的持久化 KV 缓存占用降至 V4 的约 **1/8**。〔第 19 页；摘要和结论以 DeepSeek-V4-Flash 为比较对象〕

论文明确指出，回放得到的是**近似状态**，在数学上不等同于完整前向计算的结果。作者报告回答质量所受影响可以忽略，并在后训练中模拟 Decoder 的同样回放过程以进行适配；同时保留了对未测试边界情况的限制说明，尤其关注缓存恢复边界处的 SWA 状态重建。〔第 20、37 页〕

## 2. 理解这一方法所需的背景

### 2.1. 全局 KV 与 SWA KV

论文的背景是：长时间执行任务的智能体越来越依赖超长上下文，部署系统既要处理长序列，也要保存、复用和传输大量 KV 缓存。除了 HBM、SSD 和主机内存容量，I/O 与互连带宽也限制缓存迁移和加载，进而影响服务吞吐与部署成本。〔第 4 页〕

DeepSeek-V4.1-Flash 的语言主干有 40 层，前 20 层组成因果编码器，后 20 层组成解码器。前两层只使用 SWA，其余层同时包含全局注意力和 SWA。〔第 7 页，第 2.1 节、图 3〕

![CED 架构与两类 KV 的来源](assets/swa-bounded-replay/01-ced-architecture.png)

*图 1. CED 的主要数据依赖。解码器全局 KV 来自编码器末层输出，SWA KV 仍由各解码器层自身隐藏状态生成。* [编辑此图](assets/swa-bounded-replay/01-ced-architecture.excalidraw.md)

| 名称 | 论文中的含义及与本报告的关系 |
| --- | --- |
| KV cache | 注意力计算中保存的键、值及相关缓存状态，用于复用已有计算。 |
| 全局 KV（global KV） | 全局注意力分支的缓存，包括 main KV 和 indexer K；用于访问全局上下文。 |
| SWA（Sliding-Window Attention） | 滑动窗口注意力，只在局部窗口内进行注意力计算。 |
| SWA KV | SWA 分支的局部 KV 状态。各层由自身隐藏状态生成，不随全局 KV 一起跨层共享。 |
| 运行时 KV 缓存 | 推理过程中使用的缓存，主要受 GPU 高带宽显存 HBM 容量约束。 |
| 持久化 KV 缓存 | 为后续请求复用前缀而长期保留的缓存，受 SSD 或主机内存容量约束。本文沿用论文对此类缓存的命名。 |
| prefill / decode | prefill 是处理提示词、建立相关状态的预填充阶段；decode 是之后逐步生成输出的阶段。 |
| 缓存前缀 / 未缓存后缀 | 请求中已有缓存可复用的开头部分，以及仍需计算的后续部分。 |

上述区分来自第 4 页、第 7 页和第 10 页。对固定窗口大小而言，单个运行中序列的 SWA KV 存储量有界，不随序列长度增长；序列足够长时，全局 KV 主导运行时 KV 占用。但大量会话长期保存的 SWA KV，仍可能占用大量持久化存储。〔第 4、19 页〕

### 2.2. SWA Bounded Replay 与其他压缩手段的关系

CSA2 通过跨层复用减少全局 KV 的重复存储，FP4 降低全局缓存的存储精度。SWA Bounded Replay 则改变 SWA 状态的保存与恢复方式。这几项优化共同构成论文中的 KV 缓存压缩方案。〔第 4–5 页〕

各个 CSA2 模式仍计算当前层自己的 SWA KV。论文还明确说明，由于 SWA KV 对量化敏感，其精度保留为 **FP8**。因此，SWA Bounded Replay 的直接作用是减少 SWA 状态的长期保存和恢复计算。〔第 10 页，第 2.3.1 节；第 14 页，第 2.4.4 节〕

## 3. 为什么要改变 SWA KV 的保存方式

### 3.1. V4 的持久化缓存管理

论文第 3.2.1 节对 V4 部署方式作了以下说明：〔第 19 页〕

1. **全局 KV 和 SWA KV 分开管理**，采用最近最少使用（LRU）淘汰策略。
2. **全局 KV 完整保存**；缓存命中时，可以复用整个命中的前缀。
3. **SWA KV 保存在两个位置：提示词末尾和输出末尾**，分别支持重新生成和多轮会话。命中时，从相应缓存位置恢复计算。
4. 为保持较高命中率，SSD 上配置足够大的持久化缓存，使两类 KV 在典型工作负载下都能保留超过 **72 小时**。

即使只在指定位置保留一个窗口的 KV 条目，未经序列压缩的 SWA KV 仍产生明显存储开销，尤其在每轮内容较短的多轮对话中。论文报告，**SWA KV 占 V4 持久化 KV 缓存容量的近一半**。

### 3.2. 访问规律与长期保存策略不匹配

全局 KV 具有长尾复用特征，即较长时间之后仍可能被再次使用。SWA KV 的复用主要发生在活跃会话内部、分钟级的短时间窗口中；论文指出，会话结束或下一轮开始后，对应的旧 SWA KV 就不再有用。〔第 19 页〕

原文概括为：

> “its access pattern does not match the persistent KV cache’s long retention policy.”

也就是：SWA KV 的访问规律，与持久化缓存的长期保留策略不匹配。

V4 技术报告曾提出 **Zero SWA Caching**，通过重新计算缺失的 SWA KV 避免存储开销。但精确恢复需要对最近的 `L × n_win` 个 token 执行完整前向计算。论文指出，这一成本在生产部署中高得难以接受。〔第 19 页；此处为本论文对 V4 工作的回顾〕

### 3.3. V4.1 的管理方式

V4.1 将长期保留的全局 KV 与短期保留的编码器 SWA KV 分开：〔第 6、19 页〕

| 缓存对象 | 保存位置与期限 | 复用或恢复方式 |
| --- | --- | --- |
| 全局 KV | 保留在持久化 KV 缓存中，保证至少 72 小时的存活时间 | 命中时复用已缓存前缀的全局 KV |
| 编码器 SWA KV | 各机器拿出 **10% 的主机 DRAM** 组成分布式内存池，存活时间 TTL 仅为分钟级 | 命中时复用；缺失时使用 Encoder SWA Bounded Replay |
| 解码器 SWA KV | 不用于前缀缓存 | 每次 prefill 通过 Decoder SWA Bounded Replay 生成，仅供随后解码使用 |

短期内存池的总容量远小于原持久化缓存，但过期条目可立即回收给新会话。论文称，在真实工作负载下，这样的快速回收足以服务绝大多数并发活跃会话。

淘汰 SWA KV 仍会产生未命中。对于“全局 KV 命中、SWA KV 未命中”的少量请求，Encoder SWA Bounded Replay 只重算一个窗口，即可近似恢复缺失状态。论文将这一低成本恢复方式视为移除持久化 SWA KV 的关键条件。

![V4 与 V4.1 的缓存管理对比](assets/swa-bounded-replay/02-cache-management.png)

*图 2. 全局 KV 长期保存，编码器 SWA KV 短期保存；缺失时通过 Encoder Bounded Replay 恢复近似状态。* [编辑此图](assets/swa-bounded-replay/02-cache-management.excalidraw.md)

## 4. 有界回放的共同原理

### 4.1. 为什么精确恢复需要更长的序列

虽然单层 SWA 只关注局部窗口，但各层的依赖会累积。恢复高层某个位置的 SWA KV，需要它的隐藏状态；这些隐藏状态又依赖下层更早位置的计算。因此，只保存一个窗口的最终状态，并不意味着只重算一个窗口就能**精确**得到这些状态。〔第 9、20 页〕

论文第 3.2.2 节的一般性表述是：精确重建 `L` 层的 SWA KV，需要回放最近的 `L × n_win` 个 token；有界回放只处理最近的 `n_win` 个 token，并接受近似状态。

> “SWA Bounded Replay instead replays only the most recent n_win tokens and truncates SWA to the replay segment, accepting approximate states.”

原文中的 `n_win` 为数学下标形式。其含义是：只回放最近一个窗口，并将 SWA 的可见范围截断到回放片段内。

### 4.2. 注意力范围如何截断

设回放起点为 `s`，当前查询位置为 `i`，窗口宽度为 `W`，则查询只能关注以下范围内的 SWA key：〔第 20 页〕

$$
\left[\max(s,\ i-W+1),\ i\right].
$$

纯文本形式为：`[max(s, i - W + 1), i]`。这里 `W` 对应滑动窗口宽度 `n_win`。

这同时保留了因果性、窗口长度限制，并排除了回放起点之前的局部 SWA 状态。**截断针对 SWA 分支；Encoder 回放仍复用已经缓存的全局 KV。**

以下是依据原文公式给出的说明性算例，不是论文实验：

```text
窗口宽度：128
已缓存前缀：位置 1 至 10000
未缓存后缀：从位置 10001 开始

位置 1 ........ 9872 | 9873 ................ 10000 | 10001 ........
                       回放前缀末尾的 128 个 token    计算未缓存后缀

回放起点 s = 9873
查询 i = 9873  时，SWA 可见范围为 [9873, 9873]
查询 i = 10000 时，SWA 可见范围为 [9873, 10000]
```

回放开头的查询缺少窗口中更早的局部状态，因而结果是近似的。即使回放末尾的查询已经能看到完整的 128 个位置，这些位置的高层状态也可能受到前面截断的影响。

![回放范围与 SWA 注意力截断](assets/swa-bounded-replay/03-bounded-replay-mask.png)

*图 3. 回放长度与局部注意力范围。注意力格子使用 W=4 的说明性算例，实际模型窗口为 128；上方长度未按比例绘制。* [编辑此图](assets/swa-bounded-replay/03-bounded-replay-mask.excalidraw.md)

### 4.3. 采用近似恢复的依据

论文第 2.2 节引用 Chen et al.（2025）的观察：SWA 的实际有效感受野，远小于理论上的 `n_win × L/2`。这一观察促使作者只对提示词末尾一个窗口执行 Decoder SWA 计算。这里的“有效感受野”指实际对结果产生有效影响的上下文范围。〔第 9 页〕

该引用对应论文参考文献中的 *PowerAttention: Exponentially Scaling of Receptive Fields for Effective Sparse Attention*。本报告沿用本论文对其结论的引用；本论文没有据此给出近似恢复与精确恢复等价的证明。〔第 38 页〕

## 5. Encoder SWA Bounded Replay：恢复缺失的编码器状态

### 5.1. 目标与触发条件

Encoder SWA Bounded Replay 使前缀缓存的复用只依赖全局 KV，从而允许把 SWA KV 从持久化缓存中移除。适用情况是：**全局 KV 已命中，但所需的编码器 SWA KV 缺失。**〔第 19–20 页〕

原文：

> “Encoder SWA Bounded Replay makes prefix caching depend only on global KV, allowing SWA KV to be removed from the persistent KV cache.”

### 5.2. 处理过程

第 3.2.2 节描述的过程如下：〔第 20 页〕

1. 取已缓存前缀末尾的 `n_win` 个 token 进行回放。
2. 将这些 token 与未缓存后缀一起处理，对回放部分采用前述 SWA 截断。
3. 对回放的前缀 token，**只重新生成 SWA KV**；直接复用已缓存的全局 KV，不重新计算，也不覆盖它们。
4. 对未缓存后缀，生成全局 KV 和 SWA KV。

| 处理部分 | 全局 KV | SWA KV |
| --- | --- | --- |
| 已缓存前缀末尾的回放片段 | 复用现有缓存，不重算、不覆盖 | 通过有界回放重新生成 |
| 未缓存后缀 | 新计算 | 新计算，并受回放得到的前缀状态影响 |

![Encoder SWA Bounded Replay 流程](assets/swa-bounded-replay/04-encoder-replay.png)

*图 4. 回放片段与未缓存后缀一起处理。已缓存前缀的全局 KV 保持不变，新后缀的两类 KV 会受近似前缀状态影响。* [编辑此图](assets/swa-bounded-replay/04-encoder-replay.excalidraw.md)

### 5.3. 近似性会影响后续新计算

论文特别指出：由于回放的前缀状态是近似的，**未缓存后缀新生成的全局 KV 和 SWA KV 都依赖缓存命中位置**。在不同位置命中缓存时，计算结果在数学上并不完全相同。〔第 20 页〕

这一区别需要保留：已经缓存的全局 KV 在回放中保持不变；后缀新生成的全局 KV 会受到近似前缀状态的影响。

作者对效果的表述是：

> “our experimental evidence confirms that this bounded replay strategy barely compromises response quality.”

即实验结果表明，该有界回放策略几乎不损害回答质量。其直接系统收益是：SWA KV 未命中时，恢复成本从较长序列的完整重计算降为一个窗口的重计算，使短期保存 SWA KV 成为可行选择。

## 6. Decoder SWA Bounded Replay：减少预填充计算

### 6.1. CED 为什么仍需要解码器 SWA 状态

在因果编码器—解码器（Causal Encoder-Decoder，CED）架构中，前 `L/2` 层是编码器，后 `L/2` 层是解码器。解码器的全局 KV 由**编码器最后一层的隐藏状态**投影得到，不需要先对整个提示词执行完整的解码器层计算。〔第 9 页，第 2.2 节〕

论文公式（1）为：

$$
C_l = H_{L/2}W_l^{KV},\qquad
Z_l = H_{L/2}W_l^{Z},\qquad l > L/2.
$$

其中，`C` 表示 KV 条目，`Z` 表示对应的压缩权重，投影权重与层有关。该设计允许主要在前半部分层完成 prefill，并以较小计算成本获得上层的全局 KV 缓存。

SWA 仍逐层计算：每个解码器层的 SWA KV 都由该层自身隐藏状态生成，而且开始 decode 时就需要这些状态。论文称，这是让 prefill 在编码器处结束所剩下的唯一障碍。〔第 9、20 页〕

### 6.2. 精确恢复的成本

论文说明，解码器 SWA KV 不用于缓存复用，因此精确重建时，需要让提示词最后的 `(L/2) × n_win` 个 token 经过 `L/2` 个解码器层。长缓存前缀之后只有很短的未缓存后缀时，这部分成本尤其明显。〔第 20 页〕

这里的 `L` 指 CED 主干的总层数。论文实际配置为 `L = 40`、`L/2 = 20`、`n_win = 128`。〔第 21–22 页，第 4.2.1 节〕

代入论文公式，Decoder 的精确恢复回放长度为：

$$
20\times128=2560\ \text{tokens}.
$$

有界回放将这一长度限制为 128 个 token。**这是依据论文配置计算出的回放长度对比；实际延迟和吞吐收益仍取决于系统执行开销，论文没有给出“20 倍加速”的实测结论。**

### 6.3. 每次 prefill 的处理过程

Decoder SWA Bounded Replay 在**每次 prefill** 时执行：〔第 20 页〕

1. 回放提示词末尾的 `n_win` 个 token。
2. 将这些 token 的编码器输出送入解码器各层。
3. 对 SWA 使用与前述相同的回放片段截断。
4. 得到解码器 SWA KV，**只用于随后 decode，不用于前缀缓存**。

原文：

> “use the resulting decoder SWA KV only for decoding, not for prefix caching.”

因此，两类回放的触发条件不同：Encoder 回放用于恢复缺失的编码器 SWA KV；Decoder 回放在每次 prefill 时为开始生成准备局部状态。

![Decoder SWA Bounded Replay 流程](assets/swa-bounded-replay/05-decoder-replay.png)

*图 5. 每次 prefill 只将提示词末尾 128 个 token 的编码器输出送入解码器，准备随后 decode 所需的局部状态。* [编辑此图](assets/swa-bounded-replay/05-decoder-replay.excalidraw.md)

### 6.4. 为什么总体 prefill 计算可减少近一半

对于序列长度 `N` 远大于窗口大小 `n_win` 的情况，论文给出如下复杂度变化：〔第 9 页〕

$$
O(NL)
\quad\longrightarrow\quad
O\left(NL/2+n_{\mathrm{win}}L/2\right)
\approx O(NL/2).
$$

其含义是：编码器处理序列，解码器只处理末尾一个窗口；当序列足够长时，后者的额外工作相对较小。第 3.2.2 节据此将 Decoder SWA Bounded Replay 的效果概括为将解码器前向计算限制在一个窗口内，使总体 prefill 计算量减少近一半。

这一结论对应 **CED 与有界回放结合后的计算量**，并带有 `N ≫ n_win` 的条件。它不能直接替代对某个线上工作负载的端到端耗时测量。

### 6.5. 质量与后训练适配

论文明确说明，重建的解码器 SWA KV 在数学上不等同于完整解码器前向计算得到的结果。作者观察到，这一策略对回答质量的影响可以忽略。为进一步提高可靠性，后训练中还模拟同样的回放过程，使模型适应这种计算方式。〔第 20 页〕

原文：

> “For added safety, we additionally simulate the same replay during post-training for train-aware adaptation.”

该表述位于 Decoder SWA Bounded Replay 段落。论文未在此给出这一适配的采样比例、具体损失函数或单独实验结果。

## 7. 两类回放及其收益对照

### 7.1. Encoder 与 Decoder

| 对比项 | Encoder SWA Bounded Replay | Decoder SWA Bounded Replay |
| --- | --- | --- |
| 主要目的 | 恢复缺失的编码器 SWA KV，支持移除持久化 SWA KV | 准备解码器 SWA KV，减少 prefill 计算 |
| 触发条件 | 全局 KV 命中，但编码器 SWA KV 缺失 | 每次 prefill |
| 回放片段 | 已缓存前缀末尾的一个窗口 | 整个提示词末尾的一个窗口 |
| 回放长度 | `n_win`，本模型为 128 | `n_win`，本模型为 128 |
| 关键处理 | 与未缓存后缀一起处理；复用且不覆盖已缓存全局 KV | 将末尾窗口的编码器输出送入解码器各层 |
| 生成状态的用途 | 恢复编码器计算，并继续处理后缀 | 仅供 decode，不用于前缀缓存 |
| 近似性 | 新后缀的全局 KV 与 SWA KV 依赖缓存命中位置 | 重建的 SWA KV 不等同于完整解码器前向计算结果 |
| 原文中的适配说明 | 此段未单列后训练适配方法 | 在后训练中模拟同样回放 |

来源：第 19–20 页。

### 7.2. 持久化缓存为什么降至约 1/8

第 3.2.1 节明确把收益分解为两个相乘的因素：〔第 19 页〕

$$
\frac{\text{V4.1 持久化 KV 占用}}{\text{V4 持久化 KV 占用}}
\approx
\underbrace{\frac12}_{\text{移除持久化 SWA KV}}
\times
\underbrace{\frac14}_{\text{全局 KV 的架构与精度优化}}
=\frac18.
$$

这是基于论文报告的典型占比与相同工作负载的近似结果。分布式短期内存池仍保存编码器 SWA KV，运行中也仍需要 SWA 状态；“持久化缓存占用降至 1/8”并未表示所有存储层的全部内存需求都按这一比例下降。

![持久化 KV 缓存降至约 1/8 的来源](assets/swa-bounded-replay/06-storage-reduction.png)

*图 6. 两项存储收益相乘。图中 100、50、12.5 为按论文近似比例换算的示意单位，不是额外实测数据。* [编辑此图](assets/swa-bounded-replay/06-storage-reduction.excalidraw.md)

### 7.3. 汇报时各项数字对应的范围

| 论文结论 | 对应范围与条件 | 原文位置 |
| --- | --- | --- |
| 全局 KV 为 890 字节/token，约为 V4-Flash 的 1/4 | CSA2 跨层复用与 FP4 缓存等优化后的全局 KV 占用 | 第 1、37 页 |
| 持久化 KV 约为 V4 的 1/8 | 相同工作负载；移除持久化 SWA KV 与全局 KV 压缩共同贡献 | 第 19 页 |
| 总体 prefill 计算量减少近一半 | CED 配合 Decoder Bounded Replay；复杂度近似要求序列长度远大于窗口大小 | 第 9、20 页 |
| 回答质量影响可以忽略 | 作者对近似状态恢复的实验性结论 | 第 5、20 页 |

论文没有提供单独针对 SWA Bounded Replay 的逐项质量消融表、误差上界、缓存未命中恢复时延或吞吐对比数据。因此，关于质量影响和成本的汇报应保留原文的定性表述。

## 8. 论文明确保留的限制与后续方向

第 6 节指出，新架构变化带来的稳健性边界尚未被完全刻画。内部评估覆盖了多种测试用例和边界条件，在已经评估的设置中没有观察到系统性的能力下降；但有限测试无法覆盖所有极端输入与部署条件。〔第 37 页〕

与本报告直接相关的原文是：

> “approximate state reconstruction in SWA Bounded Replay may still cause capability degradation in untested boundary cases.”

即：SWA Bounded Replay 的近似状态重建，在尚未测试的边界情况下仍可能造成能力下降。

论文提出的后续工作包括继续扩充压力测试与评估，特别关注长上下文稀疏检索，以及**缓存恢复边界处的 SWA 状态重建**；同时观察真实工作负载，系统研究潜在失败情况与稳健性边界，并改进极端条件下的表现。

因此，本方法的质量结论应表述为：**在作者已经评估的设置中，近似恢复对回答质量的影响很小；其适用边界仍需持续测试。**

## 附录：原文位置索引

下表列出全文中与 SWA Bounded Replay 直接相关的位置，并标出所补充的架构背景，便于会议查证。

| 原文位置 | 与本报告相关的内容 | 本报告对应部分 |
| --- | --- | --- |
| 第 1 页，Abstract | SWA Bounded Replay 将持久化 KV 占用进一步降至 V4-Flash 的约 1/8 | 第 1、7 节 |
| 第 4–5 页，第 1 节 Introduction | 区分运行时和持久化 KV；`L × n_win` 精确恢复与一个窗口近似恢复；存储与计算之间的权衡 | 第 1–4、7 节 |
| 第 5–6 页，第 1 节 Introduction | 推理系统实现 Encoder、Decoder 两类回放；长期全局 KV 与短期编码器 SWA KV 分开保存 | 第 3、5–6 节 |
| 第 7 页，第 2.1 节及图 3【背景】 | 40 层主干、20 层编码器和 20 层解码器；各层的 SWA 配置 | 第 2、6 节 |
| 第 9 页，第 2.2 节 CED | 解码器全局 KV 的来源；SWA 有效感受野的动机；Decoder 回放；prefill 复杂度 | 第 4、6 节 |
| 第 10 页，第 2.3.1 节及图 4【背景】 | CSA2 各模式都计算当前层自己的 SWA KV | 第 2 节 |
| 第 14 页，第 2.4.4 节【背景】 | SWA KV 因量化敏感而保留 FP8 | 第 2 节 |
| 第 19 页，第 3.2.1 节 | V4 缓存方式；SWA 复用时间；Zero SWA Caching 成本；10% DRAM 内存池、分钟级 TTL、全局 KV 至少 72 小时；1/8 收益分解 | 第 3、7 节 |
| 第 20 页，第 3.2.2 节 | 截断公式；Encoder 与 Decoder 的完整过程；近似性；质量影响；Decoder 后训练适配 | 第 4–7 节 |
| 第 21–22 页，第 4.2.1 节【配置】 | 主干 40 层、编码器和解码器各 20 层、窗口大小 128 | 第 1、6–7 节 |
| 第 37 页，第 6 节 | 收益总结；未测试边界情况的潜在能力下降；缓存恢复边界的后续评估 | 第 7–8 节 |
| 第 38 页，References【引用背景】 | 第 2.2 节所引 Chen et al.（2025）PowerAttention 文献条目 | 第 4 节 |

第 2 页目录也列出了第 3.2.2 节。论文其余正文及附录未发现另行展开 SWA Bounded Replay 的内容；文中其他训练流程里的 replay 不属于本方法。
