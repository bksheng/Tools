# 图解报告使用说明

打开 [手绘图解版报告](SWA_Bounded_Replay_技术报告_图解版.md) 阅读。原报告保留不变，并在 `backups/` 中另存了带时间戳的备份。

## 在 Obsidian 中阅读与编辑

将图解报告与整个 `assets/` 文件夹放入同一个笔记库，保留它们的相对位置。报告使用普通 Markdown 图片链接，配图为 2160 像素宽的 PNG，可直接阅读和缩放查看。

每张图提供四种文件：

- `.png`：报告中使用的图片，中文字形和手绘效果已固定。
- `.svg`：矢量图片，适合放大或导入其他文档。
- `.excalidraw.md`：供 Obsidian Excalidraw 插件打开和编辑的绘图笔记。
- `.excalidraw`：标准 Excalidraw 场景文件，可导入 Excalidraw 编辑器。

报告各图下方的“编辑此图”指向对应的 `.excalidraw.md`。源文件中的形状、箭头和文字均可分别编辑；编辑器使用的字体可能与导出 PNG 中的字体略有差异。修改源图后，重新导出同名 PNG 即可更新报告配图。

## 配图位置

| 图 | 内容 | 报告位置 | 文件名 |
| --- | --- | --- | --- |
| 1 | CED 架构与两类 KV 的来源 | 第 2.1 节 | `01-ced-architecture` |
| 2 | V4 与 V4.1 的缓存管理 | 第 3.3 节 | `02-cache-management` |
| 3 | 回放范围与 SWA 注意力截断 | 第 4.2 节 | `03-bounded-replay-mask` |
| 4 | Encoder SWA Bounded Replay | 第 5.2 节 | `04-encoder-replay` |
| 5 | Decoder SWA Bounded Replay | 第 6.3 节 | `05-decoder-replay` |
| 6 | 持久化缓存约 1/8 的来源 | 第 7.2 节 | `06-storage-reduction` |

蓝色表示全局 KV，橙色表示 SWA 或回放片段，紫色表示架构与处理过程，绿色表示新计算或后续生成。配图均为根据论文重绘的解释性示意，并非论文原图。图中另行标明说明性算例与收益的比较范围。

## 分享

使用 `SWA_Bounded_Replay_图解报告包.zip` 可一起分享图解报告、配图、可编辑源文件、原报告备份和论文 PDF。解压后保留目录结构，即可查看图片。打包版报告中的本地 PDF 引用也已改为包内的相对路径。
