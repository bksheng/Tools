# SWA Bounded Replay：技术原理、实现与收益

基于《DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression》，arXiv:2609.19969v1，2026-09-17。核对日期：2026-11-02。

用途：约20分钟内部汇报的备讲稿。文中的【论文】为原文披露；【推导】为解释或计算；【工程建议】不代表作者公开实现。没有运行模型或复现实验；伪代码为机制说明。页码均为PDF印刷页码。

**Mermaid可编辑版说明：**9张配图均已改为内嵌Mermaid源码，不再依赖PNG/SVG图片文件。蓝色=Global，紫色=SWA，橙色=Replay，绿色=新增状态，红色=截断或风险。可在Obsidian阅读视图查看，在源码模式修改节点、文字与连线。本版使用常规流程图语法和手写感字体回退，不要求Excalidraw插件；具体字形与布局由本地渲染器决定。原图版另行保留，教学示例与论文结论的区分不变。

## 1. 核心结论

SWA Bounded Replay（滑动窗口注意力有界重放）用一个短窗口的近似重计算，替代跨层局部状态的精确恢复，降低恢复成本，并改变哪些状态值得长期保存。

【论文】有两个用途：

- Encoder：Global KV命中、Encoder SWA KV缺失时，重放缓存前缀末尾一个窗口，恢复局部状态，使SWA不必长期持久化。
- Decoder：每次Prefill仅将完整提示词末尾一个窗口的Encoder输出送入Decoder，建立生成所需局部状态，使CED的Prefill接近只跑前半网络。

模型40层，Encoder和Decoder各20层，SWA窗口128 token。重建状态不与完整前向数学等价；作者称评估中质量影响可忽略，但承认未覆盖边界可能退化。

来源：§2.1，第7页；§3.2.2，第20页；§4.2.1，第21–22页；§6，第37页。

## 2. 两类KV与两种存储口径

**图01｜两套记忆，各自负责什么？**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart LR
    Q["当前 Query<br/>位置 i"]:::neutral
    G["Global KV<br/>main KV + indexer K<br/>因果可见的全局历史"]:::global
    S["本层 SWA KV<br/>最近 W=128 个位置<br/>各层独立生成，保留 FP8"]:::local
    O["联合注意力输出<br/>全局信息 + 局部细节"]:::neutral
    Q --> G
    Q --> S
    G --> O
    S --> O
    C["Global 可跨层复用、压缩、量化<br/>不等于共享 SWA"]:::global
    G -.-> C
    N["只重放 128 token<br/>不等于上下文只有 128 token"]:::replay
    S -.-> N
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§2.1、§2.3.1、§2.4.4，第7、10–11、14页重绘。

**图01读图提示：**先看两条分支：蓝色保留全局历史，紫色维护每层局部状态。重放只改变局部状态恢复方式，不把整个模型上下文缩到128。


| 状态 | 用途 | 关键特点 |
|---|---|---|
| Global KV | 保存全局历史信息 | 包括main KV和indexer K，可压缩、跨层复用、量化 |
| SWA KV | 保存近期局部细节 | 每层生成自己的状态，运行时仅需最近一个窗口 |

【论文】CSA2的Full、Reindex、Reuse模式都保留每层自己的SWA KV；共享Global不等于共享SWA。前两层只有SWA，其余层结合全局与局部注意力。SWA因量化敏感仍用FP8，FP4 main KV是另一项优化。

单个请求在HBM中的SWA占用受窗口约束；长上下文下Global是主要增长项。持久化缓存则为未来前缀复用保留大量请求、恢复边界的状态，受到SSD、主机内存容量与I/O、互连带宽约束。

【推导】每份快照只有128个位置，不代表很多会话、很多边界、数天留存的快照总量很小。

Replay是对已知token重做前向，恢复状态，不是重新采样旧回答。重放128 token也不等于上下文缩成128：Global KV仍保留历史信息。

来源：§1，第4–5页；§2.1，第7页；§2.3.1与图4，第10–11页；§2.4.4，第14页；§3.2.1，第19页。

## 3. 为什么精确恢复很贵

### 3.1 局部依赖跨层扩展

**图02｜一个小窗口，为什么会依赖很远？**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    T["第 3 层：目标位置 i<br/>从一个输出位置向下追溯依赖"]:::local
    subgraph L2["第 2 层：共 4 个位置"]
      direction LR
      A["i-3"]:::local
      B["i-2"]:::local
      C["i-1"]:::local
      D["i"]:::local
    end
    T --> A & B & C & D
    A --> RA["第 1 层：i-6 到 i-3"]:::neutral
    B --> RB["第 1 层：i-5 到 i-2"]:::neutral
    C --> RC["第 1 层：i-4 到 i-1"]:::neutral
    D --> RD["第 1 层：i-3 到 i"]:::neutral
    RA & RB & RC & RD --> U["第 1 层依赖取并集<br/>i-6 到 i，共 7 个位置"]:::local
    U --> X["再追溯一个局部注意力层<br/>输入 i-9 到 i，共 10 个位置"]:::local
    X --> N["纯局部路径教学示例：W=4，d=3<br/>R(d) = 1 + d × (W-1) = 10<br/>理论可达范围随深度增长"]:::replay
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§2.2、§3.2.2，第9、20页；W=4为教学示例重绘。

**图02读图提示：**从目标位置向下追溯：第2层需4个位置，每个位置再看一个局部窗口，合并成第1层的7个位置，再向下扩成10个输入位置。这里W=4、d=3仅用于教学。


每层的位置i看最近W个位置，这些位置在上一层又依赖更早的窗口。逐层展开，依赖跨度随深度增长。

【推导】最简单的纯局部因果注意力中，d层后单个输出位置的理论感受野跨度：

    R(d) = 1 + d × (W − 1)

这是教学推导，不是论文新增公式；恢复最后整窗的各层KV还涉及层索引与端点约定，不能直接用单位置感受野作为精确恢复API长度。

【论文】一般L层SWA的精确恢复需要重放最近L×n_win个token；L/2层Decoder则需处理提示词最后(L/2)×n_win个token。

### 3.2 有界重放的核心公式

**图03｜有界重放：在起点切断局部依赖**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart LR
    subgraph NORMAL["普通 SWA：W=4"]
      direction TB
      A["Query 100<br/>可见键 97、98、99、100"]:::local
      B["Query 101<br/>可见键 98、99、100、101"]:::local
      C["Query 102<br/>可见键 99、100、101、102"]:::local
      D["Query 103<br/>可见键 100、101、102、103"]:::local
    end
    subgraph REPLAY["Bounded Replay：起点 s=100"]
      direction TB
      E["Query 100<br/>只见 100"]:::replay
      F["Query 101<br/>只见 100、101"]:::replay
      G["Query 102<br/>只见 100、101、102"]:::replay
      H["Query 103<br/>可见 100、101、102、103<br/>满窗仍不保证状态精确"]:::replay
    end
    A -->|"截去 97、98、99"| E
    B -->|"截去 98、99"| F
    C -->|"截去 99"| G
    D -->|"窗口位置相同"| H
    RULE["局部可见范围<br/>max(s, i-W+1) 到 i"]:::replay
    GLOBAL["Global KV 的历史访问仍保留<br/>继续遵守因果性和稀疏选择"]:::global
    RULE -.->|"不裁掉全局历史"| GLOBAL
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§3.2.2，第20页；W=4为教学示例重绘。

**图03读图提示：**左右逐行比较同一Query，箭头文字标出被截掉的局部键。Query 103虽看满窗口，其高层状态仍可能近似；Global历史不使用同样的截断。


【论文】只重放最后n_win个token，SWA可见范围截断到重放段内，接受近似状态。统一W=n_win，重放起点s，位置i的局部可见键为：

    [max(s, i − W + 1), i]

相比普通SWA的[max(0,i−W+1),i]，多了“不能看s之前局部状态”的限制。这里0是本文的序列起点约定。

局部mask可写成：

    allow_local(i,j) = (j >= s) and (j <= i) and (j >= i-W+1)

截断作用于SWA分支，Global仍按因果和稀疏选择规则访问，不应将所有历史注意力截断到s。

### 3.3 W=4教学示例

实际模型W=128。用4说明重放100～103时的变化：

| Query | 正常局部可见位置 | 重放可见位置 |
|---|---|---|
| 100 | 97～100 | 100 |
| 101 | 98～101 | 100～101 |
| 102 | 99～102 | 100～102 |
| 103 | 100～103 | 100～103 |

最后一个Query虽看到了完整窗口，但窗口内较早位置的高层表示是在截断条件下生成的，所以不能断言末尾已精确恢复。

### 3.4 近似为什么可能可用

【论文】§2.2引用Chen等人的PowerAttention工作，指出实际有效感受野小于理论跨层感受野，作为Decoder重放的动机；本文实验称质量影响很小。

【解释】理论感受野指“存在影响路径”，有效感受野指“实际影响是否显著”。存在远程路径不代表必须完整重建每条路径。全局分支保留历史也是理解该架构的关键，但不保证完全补偿所有局部截断误差。

来源：§2.2，第9页；§3.2.2，第20页。

## 4. Encoder路径：Global命中、SWA缺失

### 4.1 触发位置与流程

**图04｜Encoder：前缀命中，局部状态缺失**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    HIT["Global KV 已命中前缀 [0,P)"]:::global
    CHECK{"Encoder SWA 快照<br/>存在？"}:::neutral
    HIT --> CHECK
    CHECK -->|"存在"| NORMAL["复用局部快照<br/>直接处理新后缀 [P,N)"]:::local
    CHECK -->|"缺失"| TAIL["取缓存前缀尾窗 [s,P)<br/>s = max(0,P-W)，W=128"]:::replay
    TAIL --> BATCH["尾窗 [s,P) + 新后缀 [P,N)<br/>一起做 Encoder 前向<br/>SWA 左边界截断到 s"]:::replay
    OLD["历史 Global KV<br/>不重算，不覆盖"]:::global
    OLD -.->|"只读复用"| BATCH
    BATCH --> PREFIX["旧前缀重放位置 [s,P)<br/>仅重建近似 SWA KV"]:::local
    BATCH --> SUFFIX["未缓存后缀 [P,N)<br/>正常生成 Global KV + SWA KV"]:::fresh
    NORMAL --> SUFFIX
    PREFIX -.->|"局部状态影响后续计算"| SUFFIX
    SUFFIX --> NOTE["近似路径下，新后缀的两类 KV<br/>可能随缓存命中边界 P 改变"]:::risk
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§3.2.2 Encoder段，第20页重绘。

**图04读图提示：**先判断SWA是否命中；缺失才重放缓存前缀尾窗。注意旧Global以虚线表示只读复用，重放前缀只重建SWA，新后缀生成两类KV。


请求tokens[0:N]，命中前缀tokens[0:P]，未缓存后缀tokens[P:N]。使用半开区间：

    s = max(0, P-W)
    replay_prefix = tokens[s:P]
    uncached_suffix = tokens[P:N]

【论文】重放缓存前缀最后一窗，并与未缓存后缀一起处理：

1. 检查Global命中与短期Encoder SWA快照；SWA命中则正常续算。
2. SWA缺失时，重放缓存前缀尾窗。
3. 对旧前缀位置，只重建SWA KV；旧Global KV直接复用，不重算、不覆盖。
4. 对新后缀，正常生成Global KV和SWA KV。

第2～4项为论文核心机制，第1项用于说明完整执行顺序。

流程与区间边界见上方图04，所有节点和连线均可在Mermaid代码块中编辑。

这是“缓存前缀尾窗”，不能拿“整个新提示词尾窗”替代，否则新后缀开头可能缺少局部状态。

### 4.2 关键实现边界

不能在重放时用近似隐状态产生的新Global覆盖旧Global，论文明确要求旧Global不重算、不覆盖。

【论文】近似前缀状态会影响新后缀，因此后缀生成的Global KV和SWA KV都依赖命中位置，在不同命中边界下并非数学相同。

【推导】同一输入换不同缓存切分点，隐状态乃至输出可能变化；不能以跨边界逐位一致作为算法必然保证。

来源：§3.2.1，第19页；§3.2.2 Encoder段，第20页。

## 5. 配套缓存生命周期设计

**图05｜缓存分层：按寿命保存，缺失时恢复**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    subgraph V4["V4：两类状态长期保留"]
      direction LR
      VG["Global KV<br/>完整前缀"]:::global
      VS["SWA 快照<br/>提示词末尾 / 输出末尾"]:::local
      POLICY["独立管理、LRU<br/>典型留存超过 72 小时<br/>SWA 占持久化容量近一半"]:::neutral
      VG --> POLICY
      VS --> POLICY
    end
    subgraph V41["V4.1：按生命周期分开"]
      direction TB
      NG["Global KV 长期持久化<br/>生命周期至少 72 小时"]:::global
      NS["Encoder SWA 短期池<br/>每机约 10% 主机 DRAM<br/>分钟级 TTL"]:::local
      MISS{"SWA 缺失<br/>且 Global 仍命中？"}:::neutral
      REBUILD["Encoder Bounded Replay<br/>重放缓存前缀尾窗"]:::replay
      LIVE["恢复当前局部状态<br/>继续处理请求"]:::local
      NS --> MISS
      NG -.->|"历史全局状态可复用"| MISS
      MISS -->|"是"| REBUILD
      REBUILD --> LIVE
    end
    VG -->|"继续长期保存"| NG
    VS -->|"移出长期缓存"| NS
    D["Decoder SWA<br/>每次 Prefill 重建供 Decode<br/>不用于前缀缓存"]:::local
    N["取消长期 SWA 持久化<br/>不等于运行时完全不保存 SWA"]:::risk
    LIVE -.-> N
    D -.-> N
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§3.2.1–3.2.2，第19–20页重绘。

**图05读图提示：**上部是V4长期保存两类状态，下部将Global长寿命与Encoder SWA短寿命分开。图中的恢复路径明确以Global仍命中为条件。


### 5.1 V4原方案

【论文】Global和SWA独立管理，LRU淘汰。Global完整保存，命中复用整个匹配前缀；SWA在提示词末尾和输出末尾保存快照，服务重新生成、多轮交互。典型负载下两类状态均在SSD中留存超过72小时。SWA占持久化容量近一半，短轮次多轮会话尤其明显。

Global有长尾复用；特定边界的SWA快照主要在活跃会话的分钟级时间窗口复用，会话结束或进入下一轮后，旧快照通常失去价值。“旧快照过时”不等于后续不用SWA，活跃计算仍需更新当前局部状态。

### 5.2 V4.1的安排

| 状态 | 位置/管理方式 | 生命周期 |
|---|---|---|
| Global KV | 长期持久化缓存；运行时加载到相应计算位置 | 至少72小时 |
| Encoder SWA | 每台机器约10%主机DRAM构成分布式池 | 分钟级TTL；缺失则重放 |
| Decoder SWA | 当前请求的解码状态 | Prefill重建供Decode，不用于前缀缓存 |

【论文】小而高周转的短期池已可覆盖实际负载下绝大多数并发活跃会话。Global命中但SWA缺失并不常见，却不可避免；Bounded Replay提供便宜的兜底。

系统不是不再保存任何SWA；运行时HBM和短期DRAM仍有对应状态。

### 5.3 相比Zero SWA Caching的进步

【论文】V4已提出靠重算免除SWA存储的Zero SWA Caching，但精确恢复L×W token的代价在生产中过高。V4.1接受近似，将恢复跨度限制为W，使免除长期SWA存储更实用。

来源：§3.2.1，第19页。

## 6. Decoder路径：让CED Prefill接近减半

**图06｜Decoder：只让提示词尾窗穿过后半网络**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    P["提示词<br/>长度 N"]:::neutral
    E["Encoder 20 层<br/>计算或复用前缀<br/>得到最终隐状态 H_enc"]:::neutral
    P --> E
    E --> G["投影 / CSA2 生成与复用<br/>准备 Decoder Global KV"]:::global
    E --> T["只取完整提示词尾窗的 Encoder 输出<br/>至多 W=128 个位置"]:::replay
    T --> D["Decoder 20 层前向<br/>SWA 在重放起点截断"]:::replay
    D --> S["近似 Decoder SWA KV<br/>仅供本次 Decode<br/>不写入前缀缓存"]:::local
    G --> READY["具备解码需要的全局与局部状态"]:::neutral
    S --> READY
    READY --> DECODE["正常自回归 Decode<br/>新生成 token 仍经过 Encoder + Decoder"]:::fresh
    WHY["Global 可由 Encoder 输出生成<br/>SWA 来自各 Decoder 层自己的隐状态<br/>因此尾窗仍须穿过 Decoder"]:::local
    WHY -.-> D
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§2.2、§3.2.2，第9、20页重绘。

**图06读图提示：**从Encoder出口分成两路：一路投影和复用Global，另一路只取提示词尾窗送入Decoder，准备局部KV。图中省略了具体缓存命中调度。


### 6.1 CED的结构前提

【论文】40层分为20层Encoder和20层Decoder。Decoder的Global KV可由Encoder最终隐状态投影，而不是逐层依赖每个Decoder层自己的隐状态：

    C_l = H_(L/2) W_l^KV
    Z_l = H_(L/2) W_l^Z,  l > L/2

C为KV条目，Z为压缩权重。结合CSA2实际配置，Full层生成Global，后续Reindex/Reuse层复用；不能理解成每层最终都单独存一套Global。

### 6.2 剩下的障碍是Decoder SWA

Decoder SWA仍来自各层自身隐状态，第一批Decode步骤需要它们。仅投影Global不足以准备好生成。

【论文】Decoder SWA不做前缀缓存，精确恢复要在20个Decoder层上处理提示词最后20×128=2,560个token。“长命中前缀＋短新后缀”时该成本明显。

### 6.3 每次Prefill只跑提示词尾窗

【论文】取完整提示词最后一窗的Encoder输出，在同样局部截断下通过Decoder各层，得到Decoder SWA KV，仅供接下来的Decode，不用于前缀缓存。

完整数据流见上方图06，其中Global投影分支与Decoder尾窗分支分别展示。

【工程建议】短新后缀时，Decoder尾窗可能部分落在命中前缀里，调度器仍须取得这些位置的Encoder最终输出。只拿到投影后的Global，不能假设可反演隐状态。如何保存或补算是工程细节，论文没有完整公开所有命中组合的调度代码。

### 6.4 两条路径对比

| 维度 | Encoder | Decoder |
|---|---|---|
| 触发 | Global命中、Encoder SWA缺失 | 每次Prefill |
| 位置 | 缓存前缀最后一窗 | 完整提示词最后一窗 |
| 输入 | 已知token/输入表示 | 对应Encoder输出 |
| 产物 | 缺失的Encoder SWA；新后缀正常产生两类KV | 解码用Decoder SWA |
| 作用 | 解除长期SWA存储依赖 | 限制后半网络Prefill计算 |
| 是否近似 | 是，后缀两类KV也随命中点变化 | 是，不等价于完整Decoder前向 |

### 6.5 后训练模拟

【论文】Decoder路径说明中，作者表示后训练期间模拟相同replay，做train-aware adaptation。未给出模拟比例、具体调度、专门损失项或独立消融。

来源：§2.2，第9页；§2.3.1，第11页；§3.2.2，第20页。

## 7. 收益应如何归因

### 7.1 持久化约降至1/8

**图07｜持久化占用1/8：两项收益相乘**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    OLD["V4 持久化占用 = 100<br/>Global 约 50<br/>SWA 约 50"]:::neutral
    GLOBAL["移出长期 SWA 后 = 50<br/>剩下 Global KV"]:::global
    NEW["Global 再压缩后 = 12.5<br/>相对原总量约 1/8"]:::global
    OLD -->|"不再长期保存 SWA<br/>乘约 1/2"| GLOBAL
    GLOBAL -->|"CSA2 + FP4 等<br/>乘约 1/4"| NEW
    REPLAY["Bounded Replay 提供便宜恢复<br/>使移出长期 SWA 变得可行"]:::replay
    REPLAY -.-> GLOBAL
    NEW --> EQ["(1-0.5) × 0.25 = 0.125<br/>归一化教学示例，实际比例依负载而变"]:::neutral
    EQ --> RISK["不是 Replay 单独压缩 8 倍<br/>也不是整个服务总成本减少 87.5%<br/>短期池、HBM、权重等仍有占用"]:::risk
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§3.2.1，第19页；归一化示例，不是新增实测重绘。

**图07读图提示：**以原占用100为示例，先移出约50的长期SWA，再把剩余Global从50压到12.5。两段箭头对应不同优化，不是Replay独自贡献八倍。


【论文】同负载下，V4.1持久化KV约为V4的1/8，由两个因素相乘：移除长期SWA，约去掉原占用的一半；留下的Global经架构和精度优化，再缩到原对应占用的约1/4。

【推导】原SWA比例f、Global压缩后比例r：

    C_new/C_old = (1-f) × r
    f≈0.5, r≈0.25 → 0.125

教学算例：原100单位，Global50、SWA50；移出SWA剩50，再压成12.5，即持久化占用减少约87.5%。

不能说Replay单独压缩8倍，也不能说整个服务总内存或成本减少87.5%。短期池、HBM、权重和元数据仍占资源。1/8也与负载中SWA快照比例有关，不是普适常数。

来源：§3.2.1，第19页。

### 7.2 Global的890 bytes/token属于另一项收益

【论文】Global KV为890 bytes/token，约为V4-Flash的1/4，来自CSA2跨层复用、FP4等优化。它不是整个请求所有状态的总每token占用，也不是Replay单独结果。

来源：摘要，第1页；§1，第4–5页；§6，第37页。

### 7.3 序列跨度减少不是端到端加速倍数

**图08｜计算收益：跨度与Prefill工作量分开看**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    ROOT["分开看两种计算口径"]:::neutral
    subgraph SPAN["一：Decoder 重放序列跨度"]
      direction LR
      EXACT["精确恢复<br/>20 × 128 = 2,560 token"]:::local
      BOUND["有界重放<br/>128 token"]:::replay
      EXACT -->|"跨度缩短 20 倍"| BOUND
      NOTSPEED["不是端到端快 20 倍<br/>每个重放 token 仍需通过 20 层<br/>还受 I/O、索引、通信等影响"]:::risk
      BOUND --> NOTSPEED
    end
    subgraph PREFILL["二：长输入 Prefill 的简化工作量"]
      direction LR
      BEFORE["原路径<br/>约 N × L"]:::neutral
      AFTER["CED + Decoder Replay<br/>约 N × L/2 + W × L/2"]:::replay
      BEFORE --> AFTER
      CONDITION["仅当 N 远大于 W<br/>主导工作量接近原来一半<br/>不保证任意请求时延减半"]:::risk
      AFTER --> CONDITION
    end
    ROOT --> EXACT
    ROOT --> BEFORE
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§2.2、§3.2.2，第9、20页重绘。

**图08读图提示：**上部分比较2560与128的重放跨度，下部分比较长输入的简化计算工作量。节点大小不编码数值比例，两种比较都不是实测端到端提速。


| 口径 | 精确恢复长度表述 | 有界重放 |
|---|---:|---:|
| 一般L层局部依赖链 | L×128 | 128 |
| 实际20层Decoder | 2,560 | 128 |

Decoder跨度缩短20倍。一般公式代入总深度40可得5,120→128的40倍跨度，但模型实际分成两个20层层组，不能将5,120冒充论文独立实测的Encoder恢复长度。

重放token仍需通过相应层组的Attention、MoE等。Global加载、索引、通信、访存、批处理影响实际时间；有界的是token跨度，不是保证整个请求时间与历史长度无关。论文没有独立端到端20倍/40倍提速结果。

### 7.4 长输入Prefill接近减半的条件

【论文】N远大于W时，按简化工作量模型：

    原：O(NL)
    新：O(NL/2 + W×L/2) ≈ O(NL/2)

【推导】工作量比例约1/2+W/(2N)。W=128、N=32,768时约0.501953，即减少49.8%。这是假设层计算近似同权的教学计算，不是实测时延。它描述主导项常数近半，不代表大O渐进类别改变。

短提示词、短新后缀中，固定窗口重放等开销比例更大，不能直接套完整N的公式声称任意请求提速两倍。Prefill收益依赖CED与Decoder Replay配合，不适用于任意架构单开Replay。

来源：§2.2，第9页；§3.2.2，第20页。

### 7.5 质量证据的边界

**图09｜近似误差、后训练适配与质量边界**

```mermaid
%%{init: {"theme":"base","themeVariables":{"fontFamily":"KaiTi, STKaiti, Microsoft YaHei, sans-serif","fontSize":"16px","primaryTextColor":"#293040","lineColor":"#747b89","clusterBkg":"#faf9f5","clusterBorder":"#d9d7cf","edgeLabelBackground":"#fcfbf7"},"flowchart":{"curve":"basis","htmlLabels":true,"nodeSpacing":30,"rankSpacing":45}}}%%
flowchart TB
    INPUT["相同输入<br/>改变缓存命中边界"]:::neutral
    INPUT --> P["边界 P 的前缀尾窗重放<br/>近似前缀状态 A"]:::replay
    INPUT --> PP["边界 P' 的前缀尾窗重放<br/>近似前缀状态 B"]:::replay
    P --> A["新后缀状态 A<br/>Global KV + SWA KV"]:::fresh
    PP --> B["新后缀状态 B<br/>Global KV + SWA KV"]:::fresh
    A --> CMP["不保证数学相同<br/>这里只画误差影响路径，不表示误差大小"]:::risk
    B --> CMP
    CMP --> TRAIN["训练侧适配<br/>后训练模拟相同 Decoder Replay"]:::local
    CMP --> TEST["继续评估边界<br/>短后缀 / 多次恢复 / 极端输入"]:::risk
    TRAIN --> CLAIM["论文报告质量影响很小<br/>不承诺逐位一致<br/>未给出专项详细消融分数"]:::neutral
    TEST --> CLAIM
classDef global fill:#eaf1fa,stroke:#326d9f,color:#214c73,stroke-width:2px;
classDef local fill:#f0ebf9,stroke:#8057ab,color:#633d8a,stroke-width:2px;
classDef replay fill:#fbefdb,stroke:#b6762c,color:#89551a,stroke-width:2px;
classDef fresh fill:#eaf4ec,stroke:#4b805a,color:#315d3d,stroke-width:2px;
classDef risk fill:#faebeb,stroke:#b85555,color:#8e3737,stroke-width:2px;
classDef neutral fill:#f5f4f0,stroke:#737988,color:#293040,stroke-width:1.5px;
linkStyle default stroke:#747b89,stroke-width:1.5px;
```

图源：依据论文§3.2.2、§6，第20、37页重绘。

**图09读图提示：**相同输入从两个命中边界恢复，会产生不同的近似前缀状态，并影响新后缀的两类KV。该图表达误差路径，不表达实测误差大小。


【论文】两条路径质量影响被描述为很小；重建不等价；后训练模拟Decoder replay；结论承认未测试边界风险。

全文核对未找到这些SWA Replay专项披露：开关前后的逐项benchmark分数、重放长度消融曲线、重复恢复误差统计、独立P50/P99时延或吞吐倍数、精确生产miss比例、128为普适最优长度的证明。

不能把模型整体榜单提升归因于Replay，也不能把“影响可忽略”写成完全无损、逐位一致或未经披露的精确百分比。

来源：§3.2.2，第20页；§6，第37页；全文相关词检索与相关页核对。

## 8. 实现伪代码与关键约束

以下是论文机制的教学伪代码，不是官方源码，也不是可直接运行的服务。省略压缩块、输入表示、并行通信、分配器及稀疏路由。

~~~python
W = 128

def local_visible(i, j, replay_start):
    return max(replay_start, i - W + 1) <= j <= i

def encoder_resume(tokens, prefix_len, global_cache, swa_snapshot):
    P, N = prefix_len, len(tokens)
    if swa_snapshot is not None:
        return encoder_forward(
            tokens[P:N], start_pos=P,
            global_cache=global_cache, swa_state=swa_snapshot,
            mode="normal_append")
    s = max(0, P - W)
    return encoder_forward(
        tokens[s:N], start_pos=s,
        local_attention_lower_bound=s,
        global_cache=global_cache, replay_prefix_end=P,
        # [s,P)：重建SWA，历史Global只读，不生成或覆盖。
        # [P,N)：正常生成Global与SWA。
        mode="bounded_prefix_replay_then_append")

def decoder_prepare(prompt_length, encoder_outputs, global_cache):
    t = max(0, prompt_length - W)
    H_tail = ensure_encoder_outputs(t, prompt_length, encoder_outputs)
    swa_state = decoder_forward(
        H_tail, start_pos=t, local_attention_lower_bound=t,
        global_cache=global_cache, build_local_state=True)
    return swa_state  # 供Decode，不用于前缀缓存。
~~~

实现一致性要求：

1. 保留原始位置编号，使RoPE、压缩和因果索引对齐；重放起点不应被误认为整个历史的新起点。
2. SWA在s截断，Global不套用同样截断。
3. 重放旧前缀不改写旧Global；新后缀才正常新增Global。
4. 已缓存Global即使含有某Query之后的条目，Query仍只能读取因果可见位置。
5. Decoder尾窗的Encoder输出必须可取得；Global命中不自动意味着对应隐状态可用。
6. Global未命中时，128-token replay不能凭空重建整个历史，仍须正常处理缺失上下文。

第2、3项直接来自论文，其余为根据机制提出的一致性要求，不能声称论文已公开具体代码。特别是多模态输入、压缩块边界、全命中但需取尾窗隐状态等场景，生产实现仍需补全。

## 9. 落地评估建议

本节均为工程建议。

### 9.1 对照组

A：保留完整所需状态；B：丢失SWA后精确恢复；C：128-token有界恢复；D：可选2W、4W，检查成本—质量曲线。固定权重、量化、输入及解码参数，分别测试Encoder-only、Decoder-only、二者同时启用。

### 9.2 必测边界

- 新后缀长度1、W−1、W、W+1，以及总提示词短于W。
- 两类状态都命中、Global命中而SWA缺失、两者都缺失。
- 同一输入变化命中点，多次间断恢复、TTL到期、淘汰。
- 恢复边界附近的变量定义、实体指代、结构化输出和工具参数。
- 长距离检索与局部细节依赖同时出现。
- 多模态输入位于重放边界附近时的表示和位置处理。

### 9.3 指标

| 层面 | 指标 | 目的 |
|---|---|---|
| 质量 | 成功率、精确匹配、工具成功率、检索表现 | 平均质量与关键任务是否退化 |
| 恢复偏差 | logits/KV差异、首批token差异 | 定位截断影响，不以逐位一致为预期 |
| 时延 | TTFT、恢复时间、P50/P95/P99 | 区分整体延迟与miss尾延迟 |
| 计算 | replay token数、GPU时间、吞吐 | 区分序列跨度与实际速度 |
| 存储 | 持久化容量、短期池占用、TTL周转 | 不遗漏转移到短期池的成本 |
| 负载 | 两类缓存命中率、轮次长度、恢复频率 | 判断论文收益是否适合自身业务 |

【推导】SWA miss概率p时，每请求平均额外Encoder replay token数约pW。它不是完整计算成本，但说明短期池命中率为何影响总收益。

## 10. 常见追问与答法

**Q1：模型上下文是不是只有128？**

不是。128是局部重建跨度，全局历史仍由Global提供。

**Q2：缓存都命中了，为何还要算？**

可能只命中Global；继续逐层计算还需当前边界的局部SWA状态。

**Q3：能否从Global直接还原SWA？**

两者生成方式不同。每层SWA来自该层隐状态，论文没有给出从Global精确反演所有局部状态的方法。

**Q4：SWA是否彻底不缓存？**

没有。Encoder有短期DRAM池，当前Decode也需局部状态；移除的是长期持久化责任。Decoder SWA不用于前缀缓存。

**Q5：八倍压缩全靠Replay吗？**

不是。移出长期SWA的约1/2因素，与Global降至约1/4的因素相乘。

**Q6：2,560→128等于快20倍吗？**

不是。这是重放序列跨度，实际时间还取决于层计算、访存、通信和完整请求路径。

**Q7：这是无损优化吗？**

不是数学无损。两类重建都近似；Encoder后缀两类KV还随命中边界变化。质量影响可忽略是有限评估下的经验结论。

**Q8：后训练模拟有什么作用？**

适应部署时的近似恢复。没有公开专门损失或模拟比例，不应自行补造。

**Q9：普通Decoder-only模型可直接Prefill减半吗？**

不能直接照搬。这里依赖CED让Decoder Global由Encoder最终表示生成；其他架构需要重新分析依赖。

**Q10：论文强调什么风险？**

未覆盖的极端输入和部署条件仍可能退化。作者未来重点之一是缓存恢复边界上的SWA状态重建。

**Q11：15个Prefill kernel、11个Decode kernel属于Replay收益吗？**

不是。这是§3.2对CSA2 Reuse层整体内核融合的描述。EPD解耦、通信计算重叠等也是周边部署背景，不能当作Replay的独立实验结果。

## 11. 可直接口述的开场与收尾

### 约1分钟开场

今天汇报的SWA Bounded Replay，解决的是长上下文模型里一个容易忽略的问题：历史内容虽然已有全局KV，但从某个边界继续计算，还需要每一层的局部窗口状态。长期保存这些状态会消耗大量存储；完全精确地重建，又要沿跨层依赖回算很长一段。DeepSeek的做法是接受近似，只重放最近128个token。Encoder侧用它恢复缺失的短期状态，Decoder侧用它减少Prefill的后半网络计算。今天重点讲这两条路径，以及为什么论文中的八倍持久化压缩是组合收益。

### 约45秒收尾

这项工作的启发，是按状态的复用寿命与恢复成本决定如何保存它。长期有价值的Global继续保留，局部SWA放在短期内存中，缺失后用一个窗口恢复。它同时服务于存储优化和CED的Prefill计算优化。论文给出了有吸引力的系统结果，但接受近似、缺少专项详细消融，是落地评估时需要保留的判断边界。

## 12. 建议的12页汇报顺序

| 页 | 标题 | 重点 | 时间 |
|---|---|---|---|
| 1 | 一个窗口，两条收益 | Encoder省长期存储，Decoder省Prefill | 1分钟 |
| 2 | 两类KV、两种生命周期 | Global/SWA、HBM/持久化 | 1.5分钟 |
| 3 | 小窗口为何恢复很贵 | 跨层依赖、理论与有效感受野 | 2分钟 |
| 4 | 截断并重放 | mask公式与W=4示例 | 2分钟 |
| 5 | Encoder：命中与缺失并存 | 前缀尾窗＋后缀；旧Global不覆盖 | 2分钟 |
| 6 | 长期与短期存储分工 | 10% DRAM、分钟TTL、Global至少72小时 | 1.5分钟 |
| 7 | CED剩余障碍 | Global可投影，SWA须逐层生成 | 2分钟 |
| 8 | Decoder尾窗重放 | 20层、128 token、不用于前缀缓存 | 1.5分钟 |
| 9 | 收益归因 | 1/8分解与Prefill接近减半的条件 | 2分钟 |
| 10 | 质量证据与边界 | 近似、后训练适配、无专项精确分数 | 1.5分钟 |
| 11 | 如何验证可用性 | 边界、短后缀、重复恢复、TTFT | 1.5分钟 |
| 12 | 结论与答疑 | 按寿命和恢复成本设计缓存 | 1分钟 |

合计约19.5分钟，不含答疑。压缩到10分钟可合并2/6、3/4、7/8，伪代码及详细验证作为附录。

## 13. 原文覆盖清单

| 原文位置 | 相关内容 | 本稿章节 |
|---|---|---|
| 摘要，第1页 | 持久化约1/8、Global 890 bytes/token | 1、7 |
| §1，第4–5页 | 两类状态与缓存、精确LW、有界W、组合优化 | 2、3、7 |
| §1，第5–6页 | 两条Replay路径与长短期状态分离 | 4、5、6 |
| §2.1与图3，第7页 | 40层、20+20、前两层纯SWA | 1、2、6 |
| §2.2，第9页 | CED公式、逐层依赖、有效感受野、Prefill工作量 | 3、6、7 |
| §2.3.1与图4，第10–11页 | 每层保留SWA，CED Full层生成Global | 2、6 |
| §2.4.4，第14页 | SWA保留FP8，与FP4 main KV区别 | 2、7 |
| §3.2，第18–19页 | 内核融合与EPD是周边背景 | 10的Q11 |
| §3.2.1，第19页 | 旧LRU、双端点、超过72小时、近半容量、Zero SWA Caching | 5 |
| §3.2.1，第19页 | 10% DRAM、分钟TTL、Global至少72小时、miss兜底 | 4、5 |
| §3.2.2，第20页 | mask、Encoder、旧Global不覆盖、后缀随命中点变化 | 3、4、8 |
| §3.2.2，第20页 | Decoder每次Prefill、只供Decode、后训练模拟 | 6、8 |
| §4.2.1，第21–22页 | 窗口128、20+20层配置 | 1、6、7 |
| §6，第37页 | 整体收益、未测边界、恢复边界压力测试 | 7、9、10 |

§5.1.1的失败轨迹replay与§5.2的专家路由replay不是SWA Bounded Replay。整体benchmark不能当成本技术的单项消融。

## 14. 原始资料与核对说明

主依据：[DeepSeek-V4.1-Flash原始论文](https://arxiv.org/pdf/2609.19969)。核心证据第9、19、20、22、37页，其中第19、20页同时核对PDF视觉页面和提取文字。

动机参考：[PowerAttention](https://arxiv.org/abs/2503.03588)，Chen et al. (2025)。这里只说明原文引用关系，不把它自身的速度或质量数字转嫁给Bounded Replay。

官方仓库页面可见inference文件，但未完成相应代码级验证，所以伪代码明确定位为机制说明。完整性范围是指定v1报告中直接相关、或解释机制必需的内容；推导与工程建议均单独标注。
