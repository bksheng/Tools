# 配图使用说明

1. 在 Obsidian 中：把本资料包解压到同一文件夹，再将该文件夹放进仓库；打开技术汇报.md即可看到插图。
2. Markdown 与 swa_diagrams 文件夹必须保持同级，避免图片链接断开。
3. PNG为2400×1500像素，可直接用于PowerPoint、Word或Obsidian。
4. SVG是可缩放矢量图；文字使用楷体等本机字体回退，跨设备展示优先用PNG以保持样式一致。
5. HTML图册可在浏览器逐图查看，依赖同目录的swa_diagrams文件夹，不需联网。
6. 原理图属于论文机制重绘；图内有章节页码，教学参数与真实模型参数有明确区分。

此套图为Obsidian/Excalidraw视觉风格，不gs是Excalidraw原生编辑文件。