# SWA Bounded Replay：按论文顺序的逐段导读

依据：DeepSeek-AI，《DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression》，arXiv:2609.19969v1。核对日期：2026-11-03。

原“整合版”按问题、机制、实现、收益组织；本稿按论文正文出现顺序组织。从摘要开始，依次经过引言、架构、缓存管理、算法、配置和结论，保留重复出现的观点，并说明每次出现承担的作用。跨页段落作为一个单元；图注单列；浮动图片按其所在页、相关正文附近解释。段内只提取与本技术直接相关或解释机制必需的内容，不逐句翻译整篇论文。

**引用说明：** 论文当前使用[arXiv非独占分发许可](https://arxiv.org/licenses/nonexclusive-distrib/1.0/)，不提供大段转载授权。本稿不整段复制英文，也不以截图代替转载。每个 `>` 块都明确标为**段落释义（非原文引用）** ，用于概括相关论点；英文原文通过紧邻的PDF页码链接查阅。不要把这些中文块当作作者原话或逐句译文。此前报告中已核对的少量英文短引可在[技术汇报第15节](SWA_Bounded_Replay_技术汇报.md#15-原文证据与逐条溯源)查看。

**图与公式：** 本文配图是自主绘制的Obsidian/Excalidraw手绘风理解图，不是论文截图。对同一机制重复使用同图，并给出不同读图重点；公式用Markdown数学格式重排，可直接在Obsidian中渲染。图中的教学参数和推导数值均标明，不冒充实测。

**阅读标记：** “段落释义”只概括论文主张；“技术理解”包含解释和明确指出的推导；“工程建议”不是作者公开实现。没有运行模型或复现实验。

[在线论文（固定v1）](https://arxiv.org/pdf/2609.19969v1) · [本地论文（51页）](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf)

## 阅读索引

- [一、摘要与结果总览](#chapter-1)：讲解单元 01—02。
- [二、§1 Introduction：问题如何提出](#chapter-2)：讲解单元 03—07。
- [三、§2.1 Overview：架构位置](#chapter-3)：讲解单元 08—10。
- [四、§2.2 CED：为何需要 Decoder Replay](#chapter-4)：讲解单元 11—14。
- [五、§2.3 / §2.3.1：Global 复用为何不能替代 SWA](#chapter-5)：讲解单元 15—23。
- [六、§2.4.4：局部状态的精度](#chapter-6)：讲解单元 24—24。
- [七、§3.2：部署背景与缓存策略](#chapter-7)：讲解单元 25—31。
- [八、§3.2.2：算法逐段精读](#chapter-8)：讲解单元 32—38。
- [九、§4.2.1：参数落到实际模型](#chapter-9)：讲解单元 39—39。
- [十、§6：总结、局限与未来验证](#chapter-10)：讲解单元 40—41。
- [十一、参考文献：动机来源](#chapter-11)：讲解单元 42—42。

**核心精读：** 第19页缓存策略与第20页算法，见第七、八章。完整串讲建议先顺读一次，再按每段的读图重点准备口述。

<a id="chapter-1"></a>

## 一、摘要与结果总览

<a id="unit-01"></a>

### 01｜摘要：先给出两种缓存口径的结果

**论文位置：** Abstract 段落中，CED、Global KV 与 SWA Bounded Replay 的结果概述，PDF第1页。[在线p.1](https://arxiv.org/pdf/2609.19969v1#page=1) / [本地p.1](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=1)

**内容性质：** 直接相关概述。

> **段落释义（非原文引用）**
>
> 论文将 Prefill 计算、运行时 Global KV、长期持久化 KV 作为不同优化目标；其中持久化缓存缩减与 SWA Bounded Replay 相联系。

**技术理解：** 先把三个数字分开：8B/16B 是 Prefill/Decode 的激活参数口径；890 bytes/token、约 1/4 是 Global KV 的口径；约 1/8 是持久化 KV 的组合收益。它们不是同一个分母，也不是三项都由 Replay 单独实现。后文第19页才展开 1/8 的两个乘法因素。

![单元01原理图：运行时、持久化和搬运三种资源口径](swa_ordered_diagrams/12-memory-scopes.png)

**读图：** 上排区分资源口径，下排解释很多局部快照为何能形成较大存储开销。

<a id="unit-02"></a>

### 02｜图1(b)：全局缓存数字不能当成 Replay 单项实验

**论文位置：** Figure 1(b) 与图注后半部分，PDF第1页。[在线p.1](https://arxiv.org/pdf/2609.19969v1#page=1) / [本地p.1](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=1)

**内容性质：** 收益归因背景。

> **段落释义（非原文引用）**
>
> 图1(b)比较不同代模型的每 token Global KV 大小，展示全局缓存压缩的代际变化。

**技术理解：** 这是 Global KV 图，不是 SWA Replay 开关消融。4倍、437倍等图中比较服务于模型代际讨论；汇报 Replay 时应使用第19页的存储分解，不把整幅图解释为 Replay 的独立收益。以下手绘图只重绘该分解关系，原图通过页码链接查看。

![单元02原理图：持久化约 1/8 的两个因素](swa_diagrams/07-storage-savings.png)

**读图：** 从原占用100到12.5的例子是归一化教学算例；两个箭头分别有不同优化来源。

<a id="chapter-2"></a>

## 二、§1 Introduction：问题如何提出

<a id="unit-03"></a>

### 03｜引言第1段：瓶颈从计算扩展到存储与传输

**论文位置：** §1 第1段，PDF第4页。[在线p.4](https://arxiv.org/pdf/2609.19969v1#page=4) / [本地p.4](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4)

**内容性质：** 问题背景。

> **段落释义（非原文引用）**
>
> 长期 Agent 任务既需要处理长输入，也要保存、复用和迁移大量 KV；注意力计算变便宜以后，持久化和数据搬运更突出。

**技术理解：** 理解这段之后才容易接受“多做一点计算，少保存一些状态”的设计。Bounded Replay 的目标不只是减少一次 attention 的 FLOPs，而是改变持续服务时的存储—恢复成本。容量、带宽、恢复延迟都应进入收益评估。

![单元03原理图：运行时、持久化和搬运三种资源口径](swa_ordered_diagrams/12-memory-scopes.png)

**读图：** 沿上排看 HBM、SSD/DRAM、I/O 的三种约束。

<a id="unit-04"></a>

### 04｜引言第2段：Global 与 SWA，以及两种缓存生命周期

**论文位置：** §1 第2段，说明两类注意力状态与运行/持久化约束，PDF第4页。[在线p.4](https://arxiv.org/pdf/2609.19969v1#page=4) / [本地p.4](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4)

**内容性质：** 机制前提。

> **段落释义（非原文引用）**
>
> Global KV保存全局分支所需信息，SWA维护局部窗口状态；前者随长上下文增大，后者单份大小受窗口约束。用于未来前缀复用的持久化缓存另受SSD、主机内存和迁移带宽限制。

**技术理解：** “Global”表示可用历史覆盖全局，并不表示每次 Query 对全历史做稠密 attention。每层仍需自己的局部状态。单份 SWA 有界和所有会话的 SWA 快照总量很大并不矛盾：快照数与保留时长也会增长。

![单元04原理图：两套记忆：Global 与每层 SWA](swa_diagrams/01-global-local.png)

**读图：** 蓝色是历史资料，紫色是当前层的局部状态；不要把128当作整个上下文长度。

<a id="unit-05"></a>

### 05｜引言第3段：CED 与压缩结果的整体定位

**论文位置：** §1 第3段，介绍模型、CED 和整体资源结果，PDF第4页。[在线p.4](https://arxiv.org/pdf/2609.19969v1#page=4) / [本地p.4](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4)

**内容性质：** 架构与收益背景。

> **段落释义（非原文引用）**
>
> 论文把 Decoder Global KV 的来源移到 Encoder 最终表示，借此降低 Prefill 开销，并结合其他优化减少运行和持久化缓存。

**技术理解：** 这段先交代“为什么可以少算后半网络”。但仅能取得 Decoder Global 还不够，生成开始时仍需要各层 SWA。这个缺口到第9页和第20页才由 Decoder Replay 补上。模型整体性能提升也不能在此归因给 Replay。

![单元05原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 先看上方直接取得 Global 的路径，再看下方必须经过 Decoder 的局部尾窗。

<a id="unit-06"></a>

### 06｜引言第4段（跨页）：保留局部主干，压缩全局，再改变恢复方式

**论文位置：** §1 第4段，从架构/精度/部署联合优化开始，延续到第5页图2下方、下一独立段落之前，PDF第4、5页。[在线p.4](https://arxiv.org/pdf/2609.19969v1#page=4) / [本地p.4](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4) · [在线p.5](https://arxiv.org/pdf/2609.19969v1#page=5) / [本地p.5](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=5)

**内容性质：** 直接相关概述。

> **段落释义（非原文引用）**
>
> 作者保留每层局部状态，通过CSA2与FP4减少Global冗余；部署侧再用一个窗口的近似重放，替代跨层长跨度精确恢复，减少长期保存SWA的必要性。

**技术理解：** 这是同一跨页段落，不能把第5页续文当作独立实验。一般 L 层精确恢复跨度为 L×W，有界方式为 W；质量判断是作者评估中的经验结果。少量 Prefill 重算换取长期存储节省，才是这一段完整的因果链。图2本身是整体 Decode FLOPs，不是 Replay 测速。

![单元06原理图：持久化约 1/8 的两个因素](swa_diagrams/07-storage-savings.png)

**读图：** 观察“移出长期SWA”和“压缩剩余Global”两个阶段，避免把1/8全算在Replay头上。

<a id="unit-07"></a>

### 07｜引言的系统段（跨页）：明确有 Encoder 和 Decoder 两条 Replay

**论文位置：** §1 第5页最后一段至第6页首段续文，基础设施与推理系统概述，PDF第5、6页。[在线p.5](https://arxiv.org/pdf/2609.19969v1#page=5) / [本地p.5](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=5) · [在线p.6](https://arxiv.org/pdf/2609.19969v1#page=6) / [本地p.6](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=6)

**内容性质：** 直接相关概述及系统背景。

> **段落释义（非原文引用）**
>
> 推理系统分别实现Encoder和Decoder重放路径，并将长期Global与短期Encoder SWA分开管理；内核融合与通信计算重叠是同段介绍的其他部署优化。

**技术理解：** 这里提前埋下两条主线：Encoder解决缓存续接，Decoder解决Prefill后半网络的局部状态准备。15个Prefill kernel、11个Decode kernel描述CSA2 Reuse层的融合流程，不能转写成Replay单独带来的加速结果。

![单元07原理图：Replay、内核融合、EPD 的不同职责](swa_ordered_diagrams/13-system-boundaries.png)

**读图：** 并列的三块代表职责不同的优化，不是三个可以直接相乘的加速倍数。

<a id="chapter-3"></a>

## 三、§2.1 Overview：架构位置

<a id="unit-08"></a>

### 08｜图3：先在网络上找到两条 Replay 所在的层组

**论文位置：** Figure 3 与图注；图在 §2.1 标题之前浮动排版，PDF第7页。[在线p.7](https://arxiv.org/pdf/2609.19969v1#page=7) / [本地p.7](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=7)

**内容性质：** 相关原图导读。

> **段落释义（非原文引用）**
>
> 主干分为20层因果Encoder和20层Decoder；Encoder前两层只有SWA，其余采用CSA2。

**技术理解：** 这里的Encoder不是传统机器翻译中双向读取输入的Encoder，而是因果层组；也不是后面EPD中的视觉编码阶段。图3还有Engram、DSpark等模块，理解Replay时先聚焦两组主干层与Global/SWA来源。手绘图仅突出相关路径，完整图3请点原页查看。

![单元08原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 中间的20层Encoder与右侧20层Decoder是此次讲解的主干。

<a id="unit-09"></a>

### 09｜Overview 第1段：每层都有 SWA，前两层没有 Global

**论文位置：** §2.1 第1段，PDF第7页。[在线p.7](https://arxiv.org/pdf/2609.19969v1#page=7) / [本地p.7](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=7)

**内容性质：** 机制前提。

> **段落释义（非原文引用）**
>
> 40层主干中，前两层仅使用SWA；其余层同时具备全局与局部分支，输入可以包含文本和图像表示。

**技术理解：** 准确说法是“每层都有SWA”，而不是“每层都有Global+SWA”。因此不能用Global还在这一点，保证最早局部层的截断误差总能被补偿。多模态的重放还要取得正确的输入表示；论文没有在此公开所有多模态续接实现细节。

![单元09原理图：两套记忆：Global 与每层 SWA](swa_diagrams/01-global-local.png)

**读图：** 该图展示双分支层；前两层是只有紫色分支的例外。

<a id="unit-10"></a>

### 10｜Overview 第2段（跨页）：CED 和 CSA2 优化不同开销

**论文位置：** §2.1 第2段，从第7页末延续到第8页首，PDF第7、8页。[在线p.7](https://arxiv.org/pdf/2609.19969v1#page=7) / [本地p.7](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=7) · [在线p.8](https://arxiv.org/pdf/2609.19969v1#page=8) / [本地p.8](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=8)

**内容性质：** 容易漏掉的相关概述。

> **段落释义（非原文引用）**
>
> CED让多数提示词位置绕过完整Decoder计算，同时保留逐层局部注意力；CSA2通过共享Global和选择结果减少存储及索引工作。

**技术理解：** “多数位置绕过”比“Decoder完全不运行”准确。提示词尾窗仍经过Decoder，正是为了局部状态。CED、CSA2以及分层索引分别作用于计算深度、重复缓存和索引候选数；不能把它们统称为同一个Replay算法。

![单元10原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 整个提示词形成Encoder结果，只有尾窗继续穿过Decoder。

<a id="chapter-4"></a>

## 四、§2.2 CED：为何需要 Decoder Replay

<a id="unit-11"></a>

### 11｜CED 第1段：从 Agent Prefill 压力到架构选择

**论文位置：** §2.2 第1段，PDF第9页。[在线p.9](https://arxiv.org/pdf/2609.19969v1#page=9) / [本地p.9](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)

**内容性质：** 设计动机。

> **段落释义（非原文引用）**
>
> 频繁工具调用会带来大量Prefill，尤其在缓存缺失时；CED借鉴YOCO的思路，改造后半网络取得KV的方式。

**技术理解：** 这一段说明场景和灵感，不是宣称任意Decoder-only模型加一个Replay开关就可减半。收益依赖模型结构：后半网络的Global生成不能再要求每个提示词位置先走完后半网络。

![单元11原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 看Global路径的来源转移，它为后面只跑尾窗创造条件。

<a id="unit-12"></a>

### 12｜CED 第2段与式(1)：Decoder Global 从哪里来

**论文位置：** §2.2 第2段、式(1)及紧接公式的符号说明，PDF第9页。[在线p.9](https://arxiv.org/pdf/2609.19969v1#page=9) / [本地p.9](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)

**内容性质：** 关键公式。

> **段落释义（非原文引用）**
>
> 对于后半网络，Global KV及其压缩权重由Encoder最终隐状态经过对应投影得到，而非由各Decoder层自身隐状态生成。

**技术理解：** 统一记H_(L/2)为Encoder最终输出，C_l为KV条目，Z_l为相应压缩权重。投影仍有计算成本，不能说完全免费。结合CSA2时，还要遵守Full生成、其他模式复用的规则，不能因此为每层重复存一套Global。

**公式重排（对应原文式(1)，可在 Obsidian 中渲染）：**

$$
C_l = H_{L/2}W_l^{KV},\qquad
Z_l = H_{L/2}W_l^{Z},\qquad l>\frac L2.
$$

这里重排的是数学关系；不是把整段英文改造成公式截图。

![单元12原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 上方蓝色路径是式(1)表达的关系；下方橙紫路径是该公式未解决的SWA。

<a id="unit-13"></a>

### 13｜CED 第3段：层间依赖、有效感受野与近似动机

**论文位置：** §2.2 第3段，SWA逐层计算与对 Chen 等人工作的引用，PDF第9页。[在线p.9](https://arxiv.org/pdf/2609.19969v1#page=9) / [本地p.9](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)

**内容性质：** 核心原理与动机。

> **段落释义（非原文引用）**
>
> 局部KV仍来自各层自身表示，精确准备Decoder局部状态需要更长的历史跨度；已有研究对有效感受野的观察，促使作者尝试只处理提示词尾窗。

**技术理解：** 单层只看W，不代表多层状态只受最后W个输入影响。用纯局部路径说明，d层单位置的理论跨度可写成1+d(W−1)，但这只是教学推导，不能替代论文给出的恢复长度口径。有效感受野小是设计动机，并未给出Replay的误差上界或128普适最优的证明。

![单元13原理图：局部依赖如何沿层向过去扩展](swa_diagrams/02-layer-dependency.png)

**读图：** 从顶端位置沿连线向下追踪；W=4只是教学参数。

<a id="unit-14"></a>

### 14｜CED 最后一段：Prefill 近似减半的条件

**论文位置：** §2.2 最后一段，紧邻 §2.3 标题之前，PDF第9页。[在线p.9](https://arxiv.org/pdf/2609.19969v1#page=9) / [本地p.9](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)

**内容性质：** 计算收益。

> **段落释义（非原文引用）**
>
> 当提示词远长于局部窗口时，计算由全长通过全部层，变为全长通过前半层、尾窗通过后半层。

**技术理解：** 近半描述的是简化主导工作量，不是所有请求端到端时延必定减半。短提示词、缓存长前缀后的短新后缀，都应按实际新计算与重放开销单独计账。2,560→128的跨度对比，也不是20倍服务提速。

**原文复杂度关系重排：**

$$
O(NL)\longrightarrow O\left(\frac{NL}{2}+\frac{WL}{2}\right)
\approx O\left(\frac{NL}{2}\right),\qquad N\gg W.
$$

【推导】若按层工作量近似同权，新旧之比为 $\frac12+\frac{W}{2N}$；代入 $W=128,N=32768$ 得约0.502。该数值是教学计算，非论文测得的时延。

![单元14原理图：重放跨度与 Prefill 工作量的不同口径](swa_diagrams/08-replay-compute.png)

**读图：** 上半图讲恢复跨度，下半图讲长输入总工作量，两者不可互换。

<a id="chapter-5"></a>

## 五、§2.3 / §2.3.1：Global 复用为何不能替代 SWA

<a id="unit-15"></a>

### 15｜CSA2 开头段（跨页）：解释 Global 压缩的来源

**论文位置：** §2.3 第1段，从第9页末续至第10页图4下方，PDF第9、10页。[在线p.9](https://arxiv.org/pdf/2609.19969v1#page=9) / [本地p.9](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9) · [在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)

**内容性质：** 收益归因背景。

> **段落释义（非原文引用）**
>
> KV和注意力开销可以从单条目大小、序列压缩、跨层共享等方向降低；只共享索引并不等于省下主KV存储。

**技术理解：** 这一段是“剩余Global还可压到约1/4”的背景。它不引入SWA重放规则。为了把1/8讲清楚，需要知道Global优化自有来源，但无需把本节所有相关工作变成Replay技术的一部分。

![单元15原理图：持久化约 1/8 的两个因素](swa_diagrams/07-storage-savings.png)

**读图：** Global压缩对应第二个箭头；第一个箭头才是长期SWA责任的变化。

<a id="unit-16"></a>

### 16｜图4：三种模式的共同点是本层仍生成 SWA

**论文位置：** Figure 4 与图注，PDF第10页。[在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)

**内容性质：** 相关原图导读。

> **段落释义（非原文引用）**
>
> Full、Reindex、Reuse的差异在Global KV和索引结果如何取得；它们均保留本层Query与SWA KV。

**技术理解：** 原图的颜色描述计算与复用关系。下面是针对本问题的自主重绘，不沿用原图布局。理解Replay只需抓住：共享的是全局资料或选择结果，局部状态并没有跨层变成同一个对象。

![单元16原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 三列下方都通向紫色本层状态，说明三种模式均需要SWA。

<a id="unit-17"></a>

### 17｜CSA2 的联合复用段：把缓存共享与索引复用分开

**论文位置：** §2.3 图4下方，第1个完整新段落（紧接跨页续文），PDF第10页。[在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)

**内容性质：** 机制背景。

> **段落释义（非原文引用）**
>
> CSA2同时复用主KV、索引器K及Top-K选择，并将缓存共享和索引复用作为可分别控制的机制。

**技术理解：** 相同Global并不要求各层使用完全相同的稀疏选择。对Replay而言，“复用旧Global”只锁定已有的全局缓存，仍要执行当前层应有的Query、索引或复用逻辑，不能缩成仅运行一个局部KV投影。

![单元17原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 对照Reindex和Reuse：两者都复用Global，却不一定复用同一Top-K。

<a id="unit-18"></a>

### 18｜CSA2 的注意力段：选中的 Global 与本层 SWA 联合使用

**论文位置：** §2.3 下一段，说明indexer、Top-K与局部KV的联合注意力，PDF第10页。[在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)

**内容性质：** 机制前提。

> **段落释义（非原文引用）**
>
> Query使用稀疏选择的主KV和本层滑窗KV完成注意力；CSA2还简化了压缩器与索引器的生成路径。

**技术理解：** Replay截断的是局部分支的起点，不应把Global历史也一并裁成一个窗口。即使缓存包含未来位置，重放Query仍必须遵守全局因果可见性。后者是由机制推出的实现要求，不是原文提供的完整mask代码。

![单元18原理图：两套记忆：Global 与每层 SWA](swa_diagrams/01-global-local.png)

**读图：** 两条路径都汇入输出；局部恢复不能被解释成删除蓝色历史分支。

<a id="unit-19"></a>

### 19｜跨层复用小节第1段：模式固定，局部状态独立

**论文位置：** §2.3.1 第1段，PDF第10页。[在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)

**内容性质：** 机制前提的明确重申。

> **段落释义（非原文引用）**
>
> 每个CSA2层被静态分配到一种模式；无论哪一种，本层都计算自己的Query和SWA KV，并据此得到新的注意力输出。

**技术理解：** 这里再次排除一个常见误解：Reuse层不是跳过整层。每层仍有局部注意力和其他层计算。所以重放W个位置仍要经过相关层组，有界的是token跨度，不是只执行一次常数代价的操作。

![单元19原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** Reuse一列仍有紫色框，这就是“复用不等于整层跳过”。

<a id="unit-20"></a>

### 20｜Full 段：新的 Global 和索引从这里产生

**论文位置：** §2.3.1 Full Mode 段，跨第10—11页，PDF第10、11页。[在线p.10](https://arxiv.org/pdf/2609.19969v1#page=10) / [本地p.10](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10) · [在线p.11](https://arxiv.org/pdf/2609.19969v1#page=11) / [本地p.11](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=11)

**内容性质：** 实现背景。

> **段落释义（非原文引用）**
>
> Full层承担完整CSA2路径：生成主KV与索引所需状态，并计算新的选择。

**技术理解：** 正常新增后缀在相应Full层创建Global；重放已缓存前缀则应直接复用已有Global，不能因为常规Full路径会写入，就把近似重放结果覆盖回原缓存。后者是第20页Encoder算法额外规定的写入边界。

![单元20原理图：缓存前缀尾窗与新后缀分别写入什么](swa_diagrams/04-encoder-replay.png)

**读图：** 看Global这一行：旧前缀只读，新后缀才有绿色新增。

<a id="unit-21"></a>

### 21｜Reindex 段：共享缓存，重新选择

**论文位置：** §2.3.1 Reindex Mode 段，PDF第11页。[在线p.11](https://arxiv.org/pdf/2609.19969v1#page=11) / [本地p.11](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=11)

**内容性质：** 实现背景。

> **段落释义（非原文引用）**
>
> Reindex复用此前的主KV与索引器K，但用本层索引Query重新评分，得到新的Top-K。

**技术理解：** 已有Global不被覆盖，不意味着重放期间所有全局分支工作都消失。Reindex仍有自己的计算。最终耗时受到索引、局部attention、MoE、通信等共同影响，不能仅按重放token减少比例报加速。

![单元21原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 中列第二行保留“计算新Top-K”；它与右列的Reuse不同。

<a id="unit-22"></a>

### 22｜Reuse 段：既复用缓存，也复用选择

**论文位置：** §2.3.1 Reuse Mode 段，PDF第11页。[在线p.11](https://arxiv.org/pdf/2609.19969v1#page=11) / [本地p.11](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=11)

**内容性质：** 实现背景。

> **段落释义（非原文引用）**
>
> Reuse沿用已有主KV及与其对应的最新Top-K结果，省去本层索引Query及打分步骤。

**技术理解：** 省下的是索引部分，本层主Query、SWA以及后续层计算仍存在。结合前面的静态模式定义，能解释为什么网络里很多层很轻，但仍有跨层局部依赖需要Replay来恢复。

![单元22原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 右列省去全局索引计算，却保留本层SWA。

<a id="unit-23"></a>

### 23｜小节末段：CED 与 CSA2 怎样接在一起

**论文位置：** §2.3.1 最后一段，紧邻 §2.3.2 之前，PDF第11页。[在线p.11](https://arxiv.org/pdf/2609.19969v1#page=11) / [本地p.11](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=11)

**内容性质：** 关键连接点。

> **段落释义（非原文引用）**
>
> CED中Decoder的Full层从Encoder最后一层表示生成Global；Reindex和Reuse的复用规则继续有效。

**技术理解：** 式(1)描述投影来源，CSA2描述实际生成与共享关系。两者合起来，才是“Decoder Global已经可得、但Decoder SWA仍须补算”的完整架构前提。不能把投影公式直接理解成20层各保存一份不同Global。

![单元23原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 底部蓝色长条补充Global来源，上方三列说明后续如何复用。

<a id="chapter-6"></a>

## 六、§2.4.4：局部状态的精度

<a id="unit-24"></a>

### 24｜FP4 Main KV 最后一段：SWA 仍保留 FP8

**论文位置：** §2.4.4 第3段/最后一段，PDF第14页。[在线p.14](https://arxiv.org/pdf/2609.19969v1#page=14) / [本地p.14](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=14)

**内容性质：** 必要精度背景。

> **段落释义（非原文引用）**
>
> 主KV采用后训练量化感知训练支持FP4存储；SWA因为量化敏感继续使用FP8。

**技术理解：** Replay改变的是局部状态的保存期限和恢复方法，不是把局部KV再压到FP4。主KV精度收益发生在Global一侧。因此存储收益分解时，应把量化与取消长期SWA快照分别计账。该段还说明主KV在RoPE后量化，属于周边实现背景。

![单元24原理图：两套记忆：Global 与每层 SWA](swa_diagrams/01-global-local.png)

**读图：** 紫色框仍是FP8；蓝色框的精度优化有自己的来源。

<a id="chapter-7"></a>

## 七、§3.2：部署背景与缓存策略

<a id="unit-25"></a>

### 25｜Inference System 第1段（跨页）：内核融合不是 Replay 消融

**论文位置：** §3.2 第1段，从第18页末延续到第19页首，PDF第18、19页。[在线p.18](https://arxiv.org/pdf/2609.19969v1#page=18) / [本地p.18](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=18) · [在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 系统背景。

> **段落释义（非原文引用）**
>
> 通过融合注意力、门控、MoE等操作，CSA2的多数Reuse层以较少kernel执行Prefill和Decode。

**技术理解：** 15/11是每层内核数量的描述，不是Replay前后时延比。这里的FlashMLA、DeepGEMM等名称帮助定位整体系统设计；论文没有据此给出Replay单独的P50/P99或吞吐曲线。

![单元25原理图：Replay、内核融合、EPD 的不同职责](swa_ordered_diagrams/13-system-boundaries.png)

**读图：** 中间蓝色卡片代表执行层面的融合，与左侧局部恢复分开理解。

<a id="unit-26"></a>

### 26｜Inference System 第2段：EPD 的 Encoder 指视觉编码

**论文位置：** §3.2 第2段，位于 §3.2.1 标题之前，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 术语辨析。

> **段落释义（非原文引用）**
>
> EPD把视觉编码、Prefill、Decode分开部署，使阶段能够独立伸缩并重叠执行。

**技术理解：** 此处Encoder指视觉编码阶段，不能与CED的前20层因果Encoder混为一谈。Encoder SWA Bounded Replay恢复的是主干前半网络的局部状态，并非重新执行视觉Encoder的同义词。

![单元26原理图：Replay、内核融合、EPD 的不同职责](swa_ordered_diagrams/13-system-boundaries.png)

**读图：** 右列的三个服务阶段与前面图中的20+20层划分不是同一维度。

<a id="unit-27"></a>

### 27｜Persistent KV 第1段：1/8 的完整归因

**论文位置：** §3.2.1 第1段，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 核心收益证据。

> **段落释义（非原文引用）**
>
> 同负载下持久化KV约降到V4的1/8：去掉长期SWA约减半，剩余Global又由架构与精度优化缩到相应旧占用的约1/4。

**技术理解：** 这是系统配置与负载下的结果，不是任意模型、任意业务都成立的常数。短期DRAM池、运行时HBM和其他服务内存仍然存在。可讲持久化占用约少87.5%，不可讲整机总成本或总内存必减87.5%。

【推导】若旧持久化中SWA占比为 $f$，剩余Global压到原来的 $r$，则

$$\frac{C_{\mathrm{new}}}{C_{\mathrm{old}}}=(1-f)r.
$$

代入 $f\approx0.5,r\approx0.25$ 得0.125。这是对论文因素的代数表达。

![单元27原理图：持久化约 1/8 的两个因素](swa_diagrams/07-storage-savings.png)

**读图：** 用100→50→12.5讲清乘法关系。

<a id="unit-28"></a>

### 28｜Persistent KV 第2段：旧 LRU、双端点快照与72小时

**论文位置：** §3.2.1 第2段，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 旧方案的完整描述。

> **段落释义（非原文引用）**
>
> V4分别管理Global和SWA并按LRU淘汰；Global复用完整匹配前缀，SWA在提示词末尾和输出末尾保存快照。典型负载下两者在SSD留存超过72小时，SWA占持久化容量近半。

**技术理解：** 提示词尾部快照服务重新生成，输出尾部快照服务后续会话续接。许多短轮次会产生许多边界；每份只有一窗，累计仍很贵。注意旧方案这里是典型负载下的实际留存描述；新方案后文对Global给出至少72小时的保证，表述不完全相同。

![单元28原理图：长期 Global、短期 Encoder SWA 与恢复兜底](swa_diagrams/05-cache-lifetimes.png)

**读图：** 左边是旧方案，两个端点快照与独立LRU管理是本段重点。

<a id="unit-29"></a>

### 29｜Persistent KV 第3段：寿命错配与 Zero SWA Caching 的代价

**论文位置：** §3.2.1 第3段，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 核心问题。

> **段落释义（非原文引用）**
>
> Global有长尾复用，而特定边界SWA主要在活跃会话的短期内有用；旧报告提出不存SWA、缺失时重算，但精确恢复的长跨度前向在生产中太贵。

**技术理解：** 过时的是旧边界快照，不是从此不再需要局部状态。Zero SWA Caching说明“能不存”，Bounded Replay则通过接受近似让“不存后的恢复”更便宜。论文称精确恢复需L×W跨度；它仍有相关层的完整前向工作。

![单元29原理图：局部依赖如何沿层向过去扩展](swa_diagrams/02-layer-dependency.png)

**读图：** 沿多层依赖回溯，理解为何“单层局部”不等于“恢复只需一窗”。

<a id="unit-30"></a>

### 30｜管理条目1：10% 主机 DRAM 与分钟级 TTL

**论文位置：** §3.2.1 编号条目1；其前导句只用于引出列表，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 核心部署策略。

> **段落释义（非原文引用）**
>
> SWA移出长期持久化缓存，改放每台机器约10%主机DRAM构成的分布式短期池；分钟级TTL让过期条目快速回收，Global继续长期保存。

**技术理解：** 这里10%是每机host DRAM的比例，不是GPU HBM或模型参数比例。第6页已称其为短期Encoder SWA，第20页又说明Decoder SWA不用于前缀缓存，因此实现上必须区分两者。短期池仍要占容量、查找和管理生命周期。

![单元30原理图：长期 Global、短期 Encoder SWA 与恢复兜底](swa_diagrams/05-cache-lifetimes.png)

**读图：** 右侧紫色框只承担短期活跃状态；蓝色Global保持长期责任。

<a id="unit-31"></a>

### 31｜管理条目2：为何允许短期 SWA 被淘汰

**论文位置：** §3.2.1 编号条目2，PDF第19页。[在线p.19](https://arxiv.org/pdf/2609.19969v1#page=19) / [本地p.19](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)

**内容性质：** 核心兜底机制。

> **段落释义（非原文引用）**
>
> Global命中而SWA缺失的请求不可避免但不常见；Encoder Bounded Replay把恢复限制在一窗，使短期池的miss可承担。

**技术理解：** 该机制不是要求每个请求都重放Encoder。正确决策是：有效短期SWA也命中则直接续算；只有Global命中、SWA缺失时才走重放兜底。论文没有公开精确miss率，不能自行补一个生产比例。

![单元31原理图：缓存前缀尾窗与新后缀分别写入什么](swa_diagrams/04-encoder-replay.png)

**读图：** 先确认触发条件，再从缓存前缀尾窗开始重建。

<a id="chapter-8"></a>

## 八、§3.2.2：算法逐段精读

<a id="unit-32"></a>

### 32｜统一定义段：截断哪一部分，接受什么近似

**论文位置：** §3.2.2 第1段及其中未编号的局部可见范围公式，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** 核心算法。

> **段落释义（非原文引用）**
>
> 算法只重放最近一窗，并禁止局部注意力读取重放起点以前的SWA键；这样得到的状态是近似状态。

**技术理解：** 截断的是局部依赖图，而不是所有历史信息。即使最后一个Query看满W个键，这些键的高层表示仍来自截断后的计算，不能据此宣称最后一步已经精确恢复。下面的W=4表格是教学示例，实际窗口是128。

**原文局部可见范围重排：**

$$j\in[\max(s,i-W+1),i],\qquad W=n_{\mathrm{win}}.$$

| Query位置 | 普通SWA局部窗口 | 从s=100重放时 |
|---|---|---|
| 100 | 97—100 | 100 |
| 101 | 98—101 | 100—101 |
| 102 | 99—102 | 100—102 |
| 103 | 100—103 | 100—103 |

【工程表达】`allow_local(i,j) = max(s,i-W+1) <= j <= i`。Global仍使用自己的因果与稀疏规则。

![单元32原理图：重放起点截断局部可见范围](swa_diagrams/03-bounded-mask.png)

**读图：** 红叉代表被删掉的局部键，橙色保留重放段内的键。

<a id="unit-33"></a>

### 33｜Encoder 第1段：长期 Prefix Cache 只需依赖 Global

**论文位置：** §3.2.2 Encoder 粗体小节标题所在段，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** Encoder目标。

> **段落释义（非原文引用）**
>
> Encoder重放使前缀复用不再以长期保存SWA为前提，从而允许SWA离开持久化缓存。

**技术理解：** 这里说的是长期前缀复用的状态依赖，不是运行时只需要Global，也不是以后不用查询短期SWA池。适用的Global、输入位置、模型配置以及相关压缩状态仍要一致，不能将任意一段Global当作完整可用前缀。

![单元33原理图：长期 Global、短期 Encoder SWA 与恢复兜底](swa_diagrams/05-cache-lifetimes.png)

**读图：** 长期蓝色缓存与可丢失的短期紫色状态分开，由橙色恢复流程连接。

<a id="unit-34"></a>

### 34｜Encoder 第2段：前缀尾窗与后缀一起跑，旧 Global 不改写

**论文位置：** §3.2.2 Encoder 小节第2段，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** Encoder执行步骤。

> **段落释义（非原文引用）**
>
> SWA缺失时重放缓存前缀尾窗，并与未缓存后缀一起处理；旧位置只重建SWA、复用已有Global，新后缀才生成两类KV。

**技术理解：** 重放区是缓存前缀尾窗，不是整个新提示词尾窗。“只重建SWA”限制的是旧位置的KV写入，并不表示只执行局部投影。要保留原始位置编号和全局因果性；否则会把恢复近似之外的位置错误或未来信息混入。

【教学记号】前缀为 `[0,P)`，完整提示词为 `[0,N)`：

$$s=\max(0,P-W),\quad\text{replay}=[s,P),\quad\text{suffix}=[P,N).$$

`max(0,...)`处理短于一窗的前缀；原文没有提供可运行的分配器或调度器代码。

![单元34原理图：缓存前缀尾窗与新后缀分别写入什么](swa_diagrams/04-encoder-replay.png)

**读图：** 以P为界读图：左侧旧Global只读，右侧后缀产生新Global和SWA。

<a id="unit-35"></a>

### 35｜Encoder 第3段：后缀的两类 KV 都依赖命中边界

**论文位置：** §3.2.2 Encoder 小节第3段，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** 近似性与质量证据。

> **段落释义（非原文引用）**
>
> 近似重放前缀会影响后续计算，所以新后缀Global和SWA都可能随cache-hit位置变化；作者报告回答质量受到的影响很小。

**技术理解：** “旧Global没有覆盖”与“新Global可能变化”同时成立。恢复边界改变了前缀局部状态，后缀继承这一差异。测试时应比较不同命中点、重复续接和首批生成token；逐位一致不是算法保证。这里没有给出独立benchmark分数或具体下降百分比。

![单元35原理图：近似如何传播及评估边界](swa_diagrams/09-quality-boundary.png)

**读图：** 先看不同边界的近似前缀，再沿箭头追到后缀两类状态。

<a id="unit-36"></a>

### 36｜Decoder 第1段：第二种用途是限制后半网络前向

**论文位置：** §3.2.2 Decoder 粗体小节标题所在段，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** Decoder目标。

> **段落释义（非原文引用）**
>
> Decoder重放把后半网络在Prefill中的处理跨度限制到一窗，以支持整体Prefill计算接近减半。

**技术理解：** Encoder路径解决状态缺失，Decoder路径则是每次Prefill的计算策略。它们使用相同截断思想，但触发条件、输入区间和产物用途不同，不能把两者合并成一个“cache miss时重放”的笼统流程。

![单元36原理图：重放跨度与 Prefill 工作量的不同口径](swa_diagrams/08-replay-compute.png)

**读图：** 下半图的全长Encoder加尾窗Decoder，是这一目标的计算结构。

<a id="unit-37"></a>

### 37｜Decoder 第2段：每次 Prefill 使用完整提示词尾窗

**论文位置：** §3.2.2 Decoder 小节第2段，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** Decoder完整执行步骤。

> **段落释义（非原文引用）**
>
> Decoder Global可从Encoder取得，但首批Decode仍需每层局部状态；因此每次Prefill取提示词尾窗的Encoder输出，按同样局部截断通过Decoder，结果只供解码使用。

**技术理解：** Decoder SWA不用于前缀缓存。精确恢复跨度为(L/2)×W，长缓存前缀后接短后缀时尤其贵。新方案取完整prompt尾窗，可能包含命中前缀中的位置；调度必须取得那些位置的Encoder最终输出，不能假定由投影后的Global可以反演。其具体保存或补算方式未完整公开。

【按模型参数推算】20×128=2,560，而有界跨度至多128；这是序列跨度的20:1，非实测端到端加速。

| 对照项 | Encoder Replay | Decoder Replay |
|---|---|---|
| 触发 | Global命中、Encoder SWA缺失 | 每次Prefill |
| 区间 | 缓存前缀末尾一窗 | 完整提示词末尾一窗 |
| 输入 | 对应token或输入表示 | 对应Encoder输出 |
| 结果用途 | 恢复局部状态以续算后缀 | 构造后续Decode所需局部状态 |
| 前缀缓存关系 | 使长期复用不依赖SWA保存 | Decoder SWA不用于前缀缓存 |

![单元37原理图：Encoder 输出的两条去向](swa_diagrams/06-decoder-ced.png)

**读图：** 下方输入是Encoder输出，不是从零重新采样token；新生成token仍跑完整主干。

<a id="unit-38"></a>

### 38｜Decoder 第3段：非等价、经验质量与后训练模拟

**论文位置：** §3.2.2 Decoder 小节第3段，§4标题之前，PDF第20页。[在线p.20](https://arxiv.org/pdf/2609.19969v1#page=20) / [本地p.20](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)

**内容性质：** 质量与训练适配。

> **段落释义（非原文引用）**
>
> 重建的Decoder SWA与完整Decoder前向并不数学等价；作者观察到质量影响很小，并在后训练中模拟同样的重放来做适配。

**技术理解：** 这段位于Decoder小节，不能扩写成作者公开了两条路径统一的完整训练配方。未见模拟比例、专用损失、训练调度或独立消融。把方法直接搬到未经适配的其他模型，是需要自己评估的新使用条件；适配本身也不提供无损保证。

![单元38原理图：后训练模拟与部署重放对应](swa_ordered_diagrams/11-training-adaptation.png)

**读图：** 绿色训练侧和橙色部署侧对应同一种局部截断；红色底栏保留边界评估。

<a id="chapter-9"></a>

## 九、§4.2.1：参数落到实际模型

<a id="unit-39"></a>

### 39｜Model Setups 长段（跨页）：20+20、128与实际模式配置

**论文位置：** §4.2.1 模型配置段，从第21页末延续到第22页、§4.2.2之前，PDF第21、22页。[在线p.21](https://arxiv.org/pdf/2609.19969v1#page=21) / [本地p.21](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=21) · [在线p.22](https://arxiv.org/pdf/2609.19969v1#page=22) / [本地p.22](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=22)

**内容性质：** 参数证据。

> **段落释义（非原文引用）**
>
> 模型有40层，分成20层Encoder与20层Decoder；前两层纯SWA，局部窗口设为128，剩余主干按CSA2模式组合。

**技术理解：** Encoder余下18层为三个六层组，每组一Full加五Reuse，压缩率2。Decoder为五个四层组，首组一Full加三Reuse，后四组一Reindex加三Reuse，压缩率1。这里证实每层局部状态仍存在，不能按Global缓存份数替代局部深度。W=128是本模型配置，非算法普适常数。

| 参数/配置 | 论文给定值 | 对本技术的含义 |
|---|---|---|
| 总层数L | 40 | 分两组分析，别把全网40直接当成实际Decoder深度 |
| Encoder / Decoder | 20 / 20 | Decoder精确恢复跨度代入20×W |
| 主干SWA窗口W | 128 | 有界重放使用的窗口配置 |
| Encoder前两层 | 纯SWA | “每层双分支”存在例外 |
| Decoder主Global压缩率 | 1 | 并不妨碍跨层共享，和SWA窗口不是同一参数 |

第14页DSpark草稿网络也有128滑窗，但它是另一个模块，不是此处主干Replay参数的独立证据。

![单元39原理图：CSA2 三种模式均保留本层 SWA](swa_ordered_diagrams/10-csa2-local-state.png)

**读图：** 用三种模式理解层组；不是20层各产生一份不同的Global。

<a id="chapter-10"></a>

## 十、§6：总结、局限与未来验证

<a id="unit-40"></a>

### 40｜结论第1段：再次给出整体结果，保持正确归因

**论文位置：** §6 第1段中CED、Global KV与持久化KV的总结，PDF第37页。[在线p.37](https://arxiv.org/pdf/2609.19969v1#page=37) / [本地p.37](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)

**内容性质：** 结果复核。

> **段落释义（非原文引用）**
>
> 作者再次总结Prefill的计算效率、Global KV约890 bytes/token以及持久化KV约为V4-Flash的1/8，并报告模型整体能力结果。

**技术理解：** 到这里应能把三个结论分别连回第9、19、20页。对领导可以给出肯定结论：论文提出了有价值的系统折中；但整体模型更强不构成Replay自身提升能力的因果证据。论文没有把所有收益拆成可相加的独立实验。

![单元40原理图：持久化约 1/8 的两个因素](swa_diagrams/07-storage-savings.png)

**读图：** 沿两个压缩因素回看摘要中的1/8，形成前后闭合。

<a id="unit-41"></a>

### 41｜结论第2段：未测边界与 cache-resumption 压力测试

**论文位置：** §6 第2段，PDF第37页。[在线p.37](https://arxiv.org/pdf/2609.19969v1#page=37) / [本地p.37](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)

**内容性质：** 明确局限与未来工作。

> **段落释义（非原文引用）**
>
> 内部评估未观察到系统性能力退化，但无法穷尽输入和部署条件；CSA2选择误差与SWA近似恢复仍可能在未测边界导致退化，作者将继续针对长上下文检索和缓存续接重建做压力测试。

**技术理解：** 这段是汇报必须保留的结论限定。建议固定模型、量化和解码条件，分别改变命中位置、后缀长度、TTL失效和重复恢复次数，联合看任务成功率、logits/logp差异、TTFT及尾延迟。它们是落地建议，不是论文已公布的测试结果。

![单元41原理图：近似如何传播及评估边界](swa_diagrams/09-quality-boundary.png)

**读图：** 图中展示误差可能传播的路径，不表示作者测到了某个固定误差大小。

<a id="chapter-11"></a>

## 十一、参考文献：动机来源

<a id="unit-42"></a>

### 42｜Chen 等人的 PowerAttention 条目

**论文位置：** References 中 Chen 等人的 PowerAttention 文献条目，PDF第38页。[在线p.38](https://arxiv.org/pdf/2609.19969v1#page=38) / [本地p.38](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=38)

**内容性质：** 动机溯源。

> **段落释义（非原文引用）**
>
> 第9页关于有效感受野的设计动机，引用了Chen等人的PowerAttention工作。

**技术理解：** 本导读只核对V4.1报告如何使用这一引用，未把PowerAttention的其他实验移植为Replay证据。可以继续阅读该文，但不能把其结论写成对Bounded Replay误差、128长度或所有部署条件的定理保证。

**延伸资料：** [PowerAttention，arXiv:2503.03588](https://arxiv.org/abs/2503.03588)。

![单元42原理图：局部依赖如何沿层向过去扩展](swa_diagrams/02-layer-dependency.png)

**读图：** 区分“存在较远的依赖路径”和“这条路径的实际影响有多大”。

## 附录A：本次覆盖范围与排除项

本稿以逐页相关词检索、完整段落阅读和关键页视觉核对为基础。直接算法及其存储策略均逐段处理；架构、精度、系统背景在解释本技术所需的范围内保留。表格不是声称论文每一句都属于Replay。

| 原文位置 | 本稿处理 | 覆盖理由或边界 |
|---|---|---|
| p.1 摘要与图1(b) | 单列 | 区分Global与持久化结果；防止整体图误归因 |
| pp.4—6 §1相关段落 | 按出现顺序 | 两类状态、存储—恢复折中、两条Replay及系统概述 |
| pp.7—8 图3、§2.1前两段 | 单列图注并处理跨页段 | 20+20层、前两层例外、CED与CSA2分工 |
| p.9 §2.2 全节 | 四个正文单元 | 动机、式(1)、局部依赖、复杂度及条件 |
| pp.9—11 §2.3相关段落、图4、§2.3.1 | 分段 | 全局共享不能替代本层SWA，投影和复用如何结合 |
| p.14 §2.4.4末段 | 单列 | SWA保持FP8；与主Global量化分开 |
| pp.18—19 §3.2两段 | 单列 | 内核融合与EPD为周边背景，非Replay专项结果 |
| p.19 §3.2.1 | 三个说明段+两个编号条目 | 1/8分解、旧缓存、寿命错配、短期池与兜底 |
| p.20 §3.2.2 全节 | 一个定义段+Encoder三段+Decoder三段 | mask、执行区间、写入约束、质量、后训练适配 |
| pp.21—22 §4.2.1配置段 | 单列并给参数表 | 主干窗口128、实际层数与模式组合 |
| p.37 §6前两段 | 分段 | 收益复核、评测限定、边界风险与未来工作 |
| p.38 PowerAttention参考文献 | 补充条目 | 把第9页动机追到参考文献，不引入未核对的外部实验 |

下列位置不作为SWA Bounded Replay的算法段落：

- p.2目录只是定位信息；p.5图2是整体Decode FLOPs比较。
- §2.3.2分层稀疏索引属于全局索引优化，不能自动视为局部Replay的一部分。
- p.14上半部DSpark草稿模型的128滑窗属于另一个模块。其窗口数字与主干相同，不意味着重放路径相同。
- §3.1训练基础设施中的激活重计算、共享状态管理不是SWA Bounded Replay本身。
- §5的失败轨迹重放、专家路由重放等“replay”与本文局部KV恢复不同。
- 整体benchmark和多模态能力结果，不是SWA Replay单项消融。

## 附录B：汇报中保持一致的七个结论

1. W=128是本模型局部窗口配置，不是整个模型的上下文上限。
2. Encoder重放缓存前缀尾窗；Decoder重放完整提示词尾窗的Encoder输出。
3. 旧Global不重算、不覆盖；新后缀Global仍可能因为近似前缀而变化。
4. Encoder短期SWA命中可直接续算；Decoder SWA每次Prefill建立，不用于前缀缓存。
5. 有界的是重放跨度；W个位置仍经过相关层组，也仍有索引、MoE及数据访问等成本。
6. 1/8是持久化缓存的组合结果，接近减半是CED配合Decoder Replay的工作量结论。
7. 状态数学上近似；质量影响很小是论文评估下的经验判断，未来重点包括缓存续接边界。

## 附录C：论文未公开什么

在指定v1报告中，未找到Replay专项的逐项benchmark开关结果、重放长度消融曲线、反复恢复误差统计、独立P50/P99或吞吐倍数、生产miss精确比例、后训练模拟比例与专用损失，也未给出完整调度器/分配器实现。这里是本次文献核查结论，不是论文的一段原话。

因此，图示、教学mask和参数代入用于理解机制；它们不能替代代码级实现验证或本地业务的成本—质量评测。

## 附录D：配图文件与阅读提示

蓝色=Global；紫色=SWA；橙色=Replay；绿色=新增状态或适配；红色=截断与风险。相同机制在论文中重复出现时复用同图，使读者能把引言概述和后文具体执行联系起来。

本文复用9张已有手绘机制图，新增4张概念图，共13张不同配图。新增图分别解释CSA2局部状态、后训练模拟、存储口径、系统优化分工。每个讲解单元都有图和读图重点。

若把本文移到Obsidian库，请一并复制 `swa_diagrams/`、`swa_ordered_diagrams/`、`references/` 文件夹。PNG用于直接显示，对应SVG可放大查看。在线页码链接固定到v1；部分本地阅读器不处理 `#page=` 时，按所标页码手动跳转。
