# SWA Bounded Replay 论文讲解

> 来源：DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression（§1 引言、§2.2 CED、§3.2.1 Persistent KV Cache Management、§3.2.2 SWA Bounded Replay、§6 结论）
> 用途：准备会汇报——算法原理 + 实现方法。全部论断标注「**第N页 · §小节 · 搜索关键词**」三元组定位：页码是 PDF 阅读器里的页码（打开 `paper/DeepSeek-V4.1-Flash Pushing the Limits of KV Cache Compression.pdf` 直接跳页），关键词是论文英文原句，在 PDF 里 `Ctrl+F` 搜索即可命中，可回溯。

---

## 一、要解决的问题：SWA KV 的"存储-计算"两难

### 1.1 背景：为什么 SWA KV 会成为部署瓶颈

DeepSeek-V4 起每一层都同时跑两条注意力分支（第 4 页 §1 Introduction，搜 "combines a global attention branch"；同论断另见第 5 页 §1，搜 "uses Sliding-Window Attention (SWA) in every layer"；第 7 页 §2.1 Overview，搜 "Each layer incorporates both global attention"）。**例外：前两层只有 SWA、没有全局分支**（第 7 页 §2.1，搜 "except for the first two layers"；架构图注另见第 7 页 Figure 3，搜 "The first two encoder layers use sliding window attention"；超参处另见第 22 页 §4.2.1，搜 "we use pure sliding window attention"）。

> 概念框架（第 4 页 §1，搜 "SWA-based local-processing backbone"）：论文把 V4 定性为「**SWA 局部处理骨干 + 压缩全局上下文增强**」——这解释了 V4.1 的改造取向：**只简化全局分支，局部（SWA）设计基本保留**。理解 Bounded Replay 时这是底色：SWA 是骨干感知通道，动它的状态精度要格外谨慎（后文 FP8 精度选择同此逻辑）。

- **全局分支**（global attention）：全上下文，KV = main KV + indexer K，受 HBM 容量约束；
- **局部分支**（SWA）：固定窗口 win，KV 存储有界、与序列长度无关（第 4 页 §1，搜 "SWA KV storage is bounded independently of sequence length"）。

序列足够长时，**运行时** KV 主要是全局 KV；但**持久化**（persistent KV cache，为 prefix 复用而保存，落 SSD/主机内存）那一侧，V4 的实测里 **SWA KV 占了将近一半容量**（第 19 页 §3.2.1，搜 "SWA KV accounts for nearly half"）。

V4 的做法（第 19 页 §3.2.1，搜 "SWA KV is cached at two specific points"）：

- 全局 KV 全量持久化，LRU 驱逐，命中即整段复用，保证 ≥72h 驻留；
- SWA KV 只在两个位置各存 win 条——**prompt 尾部**和**输出尾部**，分别服务"重新生成"与"多轮会话续接"。

问题：SWA KV 的访问模式和持久缓存的长期驻留策略**天然不匹配**（第 19 页 §3.2.1，搜 "its access pattern does not match the persistent KV cache"）——它只在活跃会话内分钟级的时间窗里被复用，会话结束或下一轮开始就变成死数据。多轮短会话场景下，未压缩的 SWA KV 存储开销依然可观。

### 1.2 两条老路都走不通

| 路线                                             | 做法                     | 为什么被否                                                   |
| ------------------------------------------------ | ------------------------ | ------------------------------------------------------------ |
| **存下来**（V4）                                 | SWA KV 持久化到 SSD      | 占一半持久缓存容量；访问模式是分钟级 TTL，配 72h 长驻留策略，纯属浪费 |
| **不存、精确重算**（V4 报告的 Zero SWA Caching） | miss 时重算缺失的 SWA KV | SWA 依赖**跨层累积**——**精确重建 L 层的 SWA KV 需要 replay 最近 **L×win** 个 token 做全前向**（第 5 页 §1，搜 "Exact reconstruction requires replaying the most recent"；第 19 页 §3.2.1，搜 "whose cost proved prohibitive"；第 20 页 §3.2.2，搜 "exactly reconstructing the SWA KV"），生产部署成本过高，"proved prohibitive" |

> **跨层累积是理解本算法的钥匙**：SWA 每层只看 win 个 token，但第 L 层的输入是第 L−1 层的输出，而第 L−1 层只处理过它自己窗口内的 token——所以想把第 L 层的 SWA KV 精确恢复出来，得一层层往前追，追到底就是 L×win 个 token 的完整前向。

### 1.3 V4.1 的答案：两条策略组合（第 19 页 §3.2.1，搜 "revises persistent KV cache management as follows"）

1. **SWA KV 彻底移出 persistent cache**，放进"每机 10% host DRAM"组成的分布式内存池，**TTL 只有分钟级**，过期即刻回收。容量小但周转快，足以服务绝大多数并发活跃会话；全局 KV 留在 persistent cache，保 ≥72h。
2. 内存池必然产生 miss——**Encoder SWA Bounded Replay 做廉价兜底**：命中全局 KV、miss SWA KV 的请求，只重算 win 个 token（而非 L×win 全前向）。原文称这是"cornerstone of the design"：把灾难性 miss 变成优雅的、廉价的降级（第 19 页 §3.2.1，搜 "cornerstone of the design"）。

---

## 二、算法原理：SWA Bounded Replay 的数学定义（第 20 页 §3.2.2 SWA Bounded Replay，搜 "SWA Bounded Replay instead replays only"）

### 2.1 核心定义（一句话版）

> 只 replay 最近 **win** 个 token，并把 SWA 窗口**截断到 replay 段内**，接受近似状态：replay 起点为 s，则位置 t 的 query 只 attend 到 SWA keys ∈ **[max(s, t−win+1), t]**。（第 20 页 §3.2.2，搜 "truncates SWA to the replay segment"）

形式化对比：

|                              | replay 长度     | 位置 t 的 SWA 可见范围                            | 状态 |
| ---------------------------- | --------------- | ------------------------------------------------- | ---- |
| 精确重建（Zero SWA Caching） | L×win（全前向） | [t−win+1, t] 完整                                 | 精确 |
| **Bounded Replay**           | **win**         | **[max(s, t−win+1), t]**（被 replay 起点 s 截断） | 近似 |

**截断的含义**：replay 段内靠前的位置（t < s+win−1），其 SWA 窗口左边界本应越过 s 之外、够到更早的 token；截断后看不见 s 之前的内容——这丢弃的正是"跨层累积"里本该由更早 token 贡献的那部分状态。Bounded Replay 的赌注是：这段被丢弃的远端上下文对 SWA 分支的输出影响可忽略。

### 2.2 理论依据：SWA 的有效感受野远小于理论值

论文动机直接引用 Chen et al. 2025（PowerAttention，arXiv:2503.03588）：**SWA 实际有效感受野远小于理论上的 win×L**（第 9 页 §2.2，搜 "effective receptive field of SWA is much smaller"）。也就是说，理论跨层累积要求 L×win，但真实注意力质量集中在最近的局部——只 replay win 个 token 丢掉的信息，模型基本不在乎。

### 2.3 两个部署变体

#### 变体 A：Encoder SWA Bounded Replay（管"缓存复用"）

目标：**让 prefix caching 只依赖 global KV**，SWA KV 得以从 persistent cache 移除（第 20 页 §3.2.2，搜 "makes prefix caching depend only on global KV"）。

miss 时的处理流程（第 20 页 §3.2.2，搜 "we replay the last win tokens of the cached prefix"）：

```
[cached prefix .............. | replay 段 win | uncached suffix .........]
                               ↑ 一起进 prefill ↑
```

1. 取 cached prefix 的**最后 win 个 token** 作为 replay 段，与 uncached suffix **拼在一起处理**；
2. replay 段 token **只重建 SWA KV**——global KV 直接**复用缓存，不重算、不覆盖**；
3. suffix 正常同时生成 global KV + SWA KV。

**近似性的诚实说明**（第 20 页 §3.2.2，搜 "the replayed prefix state is approximate"）：replay 出来的 prefix 状态是近似的，所以 suffix 上的 global KV 和 SWA KV **依赖 cache-hit 位置**、跨位置不严格数学相等。但实验证据表明"barely compromises quality"（对回答质量几乎无损害，搜 "barely compromises response quality"）。

#### 变体 B：Decoder SWA Bounded Replay（管"省 prefill 计算"）

背景是 CED（Causal Encoder-Decoder）架构（第 9 页 §2.2，搜 "the KV entries are not derived from"）：

- 下半 L/2 层是 causal encoder；上半 decoder 层的**全局 KV 不由自身 hidden states 生成**，而是从第 L/2 层 hidden states 用逐层投影权重直接投影（公式 1，第 9 页 §2.2，搜 "layer-dependent projection weights"）→ decoder 的全局 KV 几乎零成本；
- 但 **SWA 不吃这个红利**：CED 里 SWA 保持逐层计算（第 9 页 §2.2，搜 "CED maintains the conventional layer-wise"），每层的 local KV 由**本层** hidden states 生成。**这不是 CED 独有——CSA2 也一样**：三模式（Full/Reindex/Reuse）无论哪种，**每层都自算自己的 SWA KV**（第 4 页 §1，搜 "each layer retains its own global Q and SWA KV"；第 10 页 §2.3，搜 "All three modes compute main Q and SWA KV in the current layer"；第 10 页 §2.3.1，搜 "the layer computes its own query and SWA KV"）。于是想"prefill 到 encoder 结束就停"，唯一障碍是 decoder 各层自己的 SWA KV——首步 decode 需要它，而精确重建要跑 decoder 的 L/2 层 × win 个 token（第 20 页 §3.2.2，搜 "The only obstacle to ending prefill at the encoder"）。

解法（第 20 页 §3.2.2，搜 "we replay the last win tokens of the prompt"）：**每次 prefill 都 replay prompt 的最后 win 个 token**，把这些 token 的 **encoder 输出**喂进 decoder 层（同样做 SWA 截断），产出的 decoder SWA KV **只用于 decoding，不用于 prefix caching**。

收益量化（第 9 页 §2.2，搜 "effectively halving the overall computation"）：CED + 本机制把 prefill 复杂度从 O(L·s) 降到 **O(L/2·s + win·L/2) ≈ O(L/2·s)**——总 prefill 计算近似**减半**。对"长缓存前缀 + 短未缓存后缀"的多轮场景尤其值（精确重算成本集中在 decoder 侧，第 20 页 §3.2.2，搜 "expensive when a short uncached suffix follows a long cached prefix"）。

**保底手段**（第 20 页 §3.2.2，搜 "train-aware adaptation"）：post-training 阶段**模拟同样的 replay 流程**做 train-aware adaptation，让模型在训练时就见过这种近似状态分布。

### 2.4 产出：persistent KV 足迹降到 V4 的 1/8（两因子分解）

第 19 页 §3.2.1（搜 "reduces the persistent KV cache footprint to 1/8"）与第 37 页 §6 结论（搜 "persistent KV cache footprint (always on SSD or in host memory) to roughly 1/8"）：

```
1/8 ≈ (SWA KV 不进 persistent cache，约减半 ×0.5) × (global KV 架构+精度压缩 ×0.25)
```

论文还明确了两侧存储的物理位置分工（第 6 页 §1 末段，搜 "separate long-lived global KV storage from short-lived encoder SWA KV"）：**长寿命 global KV 与短寿命 encoder SWA KV 在 host memory 中分开管理**，缺失的 encoder SWA 状态用 bounded replay 近似重建。

**两个与存储估算直接相关的补充事实**：

- **win 的具体值是 128**（第 22 页 §4.2.1，搜 "the window size win is set to 128"）。此前全篇用 win 符号，落地估算时按 128 代入——例如 V4 两位置缓存各存 win 条 = 各 128 条，重算兜底成本 = 128 个 token 的 KV 投影。注意这是 V4.1-Flash 的取值，**omniinfer 平台模型（如 Pangu）的窗口参数以其自身 config 为准**（Pangu 实为 512），不可直接套用。
- **SWA KV 保持 FP8，没有跟 main KV 一起压到 FP4**（第 14 页 §2.4.4，搜 "We retain FP8 for the SWA KV cache due to its sensitivity to quantization"）：论文明确 SWA KV 对量化**敏感**，故精度上单独对待——main KV FP4、SWA KV FP8。且该节说明这个精度组合相比 V4 的 FP8 main KV "nearly halves the storage footprint"（第 14 页 §2.4.4，搜 "nearly halves the storage footprint"）。对 1/8 因子分解的含义：global KV ×0.25 的压缩里**含精度因子**，而 SWA 侧只靠"移出 persistent cache"，**没有精度压缩贡献**——这也是"SWA 骨干要谨慎"的又一体现。对 omniinfer 适配的提示：若平台侧对 SWA KV 走了不同量化路径，精度对比实验要单独评估。

---

## 三、实现方法（推理系统视角，可直接映射到工程）

> **前提限定（2026-11-03 实操后补）**：「可直接映射」的前提是目标平台具备 **hidden states 保全 + 声明式 bounded_replay 机制**这两项基础设施（上游 vLLM ≥0.26 #56227 系 / vllm-ascend 等价物）。我们在 omniinfer vllm 0.25.1 pin 上的实操实证：缺这两项时，下方工程部件做全**也修不成正确**——replay 段重建的 SWA KV 只能是"被截断上下文污染的近似 KV"（详见主报告第 5 章根因 ② 与第 6.3 节路线图）。

### 3.1 persistent KV 管理策略

| 对象           | 存哪                                 | 寿命                   | miss 兜底                                    |
| -------------- | ------------------------------------ | ---------------------- | -------------------------------------------- |
| global KV      | persistent cache（SSD），随 HBM 常驻 | ≥72h                   | —                                            |
| SWA KV         | 分布式内存池（每机 10% host DRAM）   | 分钟级 TTL，过期即回收 | Encoder SWA Bounded Replay（win token 重算） |
| decoder SWA KV | **从不缓存**                         | —                      | 每次 prefill 必做 bounded replay             |

**精度分工（第 14 页 §2.4.4，搜 "We retain FP8 for the SWA KV cache"）**：main/global KV = FP4，**SWA KV = FP8**（对量化敏感，不随 main KV 压到 FP4）。推理框架的 KV 写入路径若对两分支统一精度，需为 SWA 分支单独保留 FP8 通道。

### 3.2 一次请求的关键路径（伪代码）

> **关键分野（2026-11-03 实操后改写）**：replay 段的 SWA KV 重建有**两种实现路线**，正确性天差地别——
>
> | 路线                   | 做法                                                         | 正确性                                                       |
> | ---------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
> | **论文原生路线**       | 缓存 layer 输入侧 hidden states，replay 只重算 KV 投影、**不跑 attention 前向** | 近似可控（截断边界信息丢失是唯一的近似源）                   |
> | 错误路线（实操已证伪） | replay token 与 suffix 拼一起**重新过 attention 前向**       | **结构性错误**：SWA 重建的层间递归依赖（layer L 需 L−1 的 hidden，L−1 又依赖自己窗口）使重过前向只能得到"被截断上下文污染的近似 KV"，且随截断边界移动非确定 |
>
> 实操实证：按错误路线实现的 patch 在 temp=0 同 prompt 两连发产出互不相同的乱码（hit1≠hit2），冷跑正常——主报告第 5 章三方受控实验完整取证。**伪代码按论文原生路线改写如下**。

```
on_request(prompt):
    hit = lookup_global_kv_cache(prompt_prefix)     # 只查 global KV
    if hit:
        s = hit_len - win                            # replay 起点
        replay_tokens  = prompt[s : hit_len]         # 最近 win 个
        suffix_tokens  = prompt[hit_len : ]
        # replay 段: 不走 attention 前向！
        for layer in layers:
            hidden = cached_hidden_states[layer][s : hit_len]   # 保全的 layer 输入
            swa_kv[layer] = k_proj(hidden), v_proj(hidden)      # 只重算 KV 投影
            # global KV 直接用缓存（不重算不覆盖）
        run_prefill(suffix_tokens):                  # 只有 suffix 走前向
            suffix 段: global KV + SWA KV 都算
        # SWA 可见域: [max(s, t-win+1), t]
    else:
        run_full_prefill(prompt)                     # 全量算
    # CED 情形额外一步:
    replay_last_win_prompt_through_decoder_layers()  # 产 decoder SWA KV，只给 decoding 用
    start_decoding()
```

工程上要动的五类部件（论文未给实现细节，此处按推理框架通用结构归纳 + 2026-11-03 实操修正）：

1. **prefix 命中逻辑**：命中判定只看 global KV 的 block 哈希，SWA KV 不参与命中、不参与驱逐计账；
2. **调度器的计算边界**：cache hit 后 num_computed_tokens 只对 global KV 有效，SWA 层要按 replay 段对齐（replay 段起点之前的 SWA 位置标记为"不可见"而非"已计算"）；
3. **attention mask/元数据**（**强制，非可选**）：banded mask 的左边界从 t−win+1 改为 max(s, t−win+1)——即 mask 支持"窗口被 replay 起点截断"。**实操实证：缺失它时 SWA query 窗口伸进 null 块区，读到块池复用残留的未清零物理内存 → 输出乱码**（vllm-ascend `dsa_v41.py build_replay_swa_visible_lens` 的 clamp 正是这半边）；
4. **KV 写入路径**：replay 段 token 写 SWA KV 时要有明确的 slot 归属（写回原 prefix 位置还是新分配），且**禁止覆盖**已缓存的 global KV；
5. **hidden states 保全层（实操判定的最大新增/成败件）**：缓存 replay 段各 layer 输入侧的 hidden states，使 replay 只需重算 KV 投影、**不跑 attention 前向**。这是绕开"SWA 重建层间递归依赖"的唯一途径——没有它，部件 1-4 做全也只能得到污染 KV。上游 #56227 `bounded_replay` 声明式机制 + hidden 状态保全是其等价物；**老 pin（如 vllm 0.25.1）上无此基础设施 = 结构性缺失，不可修成正确**。

### 3.3 训练侧配套

post-training 用同样截断方式模拟 replay（train-aware adaptation，第 20 页 §3.2.2，搜 "simulate the same replay during post-"，PDF 内该句跨行断为 "post-\ntraining"，可只搜 "simulate the same replay"）——这是"近似可以接受"的重要保险，纯推理侧改造（不重训）属于论文验证之外的用法，需要自己评估精度。**实操已证实此警告的分量（2026-11-03）**：未重训的推理侧实现在长题（prompt 1.7k-3k）上确实退化，且退化形态是最重的一种——temp=0 同 prompt 两连发产出互不相同的乱码（主报告第 5 章三方受控实验取证）。

---

## 四、论文自述的局限（汇报时必须带上；第 37 页 §6 Conclusion, Limitations, and Future Directions，搜 "create robustness boundaries"）

1. CSA2 的选择误差 + SWA Bounded Replay 的近似状态重建，**在未测边界情况仍可能造成能力退化**（第 37 页 §6，搜 "may still cause capability degradation"）；
2. 内部评测覆盖多样场景未观察到系统性退化，但"no finite test suite can cover every extreme input"（第 37 页 §6，搜 "no finite test suite"）；
3. 未来工作明确点名：**cache-resumption 边界的 SWA 状态重建**要做专项压力测试，长上下文稀疏检索要持续监控（第 37 页 §6，搜 "cache-resumption boundaries"）。

> 汇报建议：我们的适配属于"推理侧改造 + 不重训"，正好落在论文自述的风险区里——所以任务 4 的 logp 精度对比（cache 命中 vs 不命中、不同 hit 位置）是必做项，不是可选项。

---

## 五、一句话总结（给领导的电梯稿）

SWA KV 占了 V4 一半的持久缓存，但它的访问模式只配得上分钟级寿命；精确重算又得 replay L×win 个 token，太贵。V4.1 的 SWA Bounded Replay 把重算量砍到 **win 个 token**、SWA 窗口截断到 replay 段内，赌"SWA 有效感受野远小于理论值"（PowerAttention 实证）——赌赢了：质量几乎无损，persistent KV 直接降到 **1/8**，CED 场景下 prefill 计算还近似**减半**。配套保险是 post-training 模拟 replay 做适配，风险点集中在 cache 续接边界，需要专项精度压测。

---

## 附：与 omniinfer 现状的对照钩子（衔接任务 2）

| 论文概念                                                     | omniinfer 对应物                                             | 备注                                                        |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ----------------------------------------------------------- |
| 每层 global + SWA 双分支（前两层仅 SWA）                     | CLA reuse 层（`npu_cla.py`）：global 分支读 source layer cache + local 分支 `attn_cla_swa` | 结构同源（跨层复用 + 本层 SWA）                             |
| SWA KV 存储                                                  | `ShareKVSlidingWindowSpec` + `ShareKVSlidingWindowManager`   | sliding_window=win+1（留 1 token 给 decode 重算）           |
| prefix 命中含 SWA                                            | 上游 `SlidingWindowManager.find_longest_cache_hit`（右起找 window 连续块，前缀填 null_block） | **当前 SWA 层命中天然只吃 window 尾巴——改造点**             |
| 分布式内存池/TTL                                             | `kv_offload`（cpu_bytes、arc/lru 驱逐）+ PD 分离传输         | 现有 infra 可承接                                           |
| replay 段 mask 截断                                          | `_apply_local_swa` 的 banded attention（sparse_mode=4, pre_tokens=win−1） | 需支持左边界 max(s, ·)                                      |
| **SWA KV 精度 FP8**（main KV FP4；第 14 页 §2.4.4，搜 "We retain FP8 for the SWA KV cache"） | 平台侧 KV 量化路径（若对两分支统一精度）                     | **两分支精度需分离**：SWA 对量化敏感，不可随 main KV 压 FP4 |
| win=128（第 22 页 §4.2.1 超参，搜 "the window size win is set to 128"） | Pangu config 的 sliding_window=512                           | **取值平台各异，机制同构**：估算/对比须按各自 config 代入   |

**已甄别为"SWA 提及但不属于 Bounded Replay 机制"的内容**（自检时扫到，特此记录避免后人重复排查）：DSpark 投机解码的 drafter 自带 "a sliding attention window of 128 tokens"（第 14 页 §2.4.3，搜 "three Transformer blocks with a sliding attention window"）——那是 drafter 小模型自己的注意力设计，与主干的 SWA KV 缓存管理正交，不影响本机制的嫁接方案。