# SWA Bounded Replay：技术原理、实现与收益

基于《DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression》，arXiv:2609.19969v1，2026-09-17。核对日期：2026-11-03。

用途：约20分钟内部汇报的备讲稿，工程细节可作为答疑附录。文中的【论文】为v1原文披露；【官方部署文档】与【官方源码】为后续DeepInfer资料；【推导】为解释或计算；【工程建议】不代表作者公开实现。没有运行模型或复现实验；伪代码为机制说明。论文页码均为PDF印刷页码。

**官方部署补充（2026-11-03）：** 已读取用户提供的[知乎文章MHTML存档](<DeepSeek V4.1 Flash 大规模推理部署实践 - 知乎.mhtml>)，完成SWA Bounded Replay、KVCache Storage、命中策略及相关配图的逐段核对。已结合官方Q&A与固定版本源码补入状态布局、保存边界、命中回退、128/134/140的口径和mask/compact实现；原文新增确认SWA池TTL约180秒、命中率超过98%，并保留官方140-token Prefill基准图。逐段对照与原文摘录见[核对记录](SWA_Bounded_Replay_官方部署资料核对.md)。

**溯源阅读方式（2026-11-03补充）：**关键结论后已加入脚注，文末第15节按论点列出具体章节、段落与在线/本地PDF页码链接。英文只摘录少量关键短语，中文释义单独标注。引用固定到v1版本；PDF共51页，本文使用的印刷页码与阅读器页序对应。文中的教学算例、伪代码和落地建议不冒充论文原话。

**配图版说明：**已加入9张手绘风原理图，另在第7.7节附官方部署Prefill基准原图。手绘图中蓝色=Global，紫色=SWA，橙色=Replay，绿色=新增状态，红色=截断或风险。教学示例、论文参数与后续线上数据分别标注。图片文件夹须与本报告保持相对位置。

## 1. 核心结论

SWA Bounded Replay（滑动窗口注意力有界重放）用一个短窗口的近似重计算，替代跨层局部状态的精确恢复，降低恢复成本，并改变哪些状态值得长期保存。

【论文】有两个用途：

- Encoder：Global KV命中、Encoder SWA KV缺失时，重放缓存前缀末尾一个窗口，恢复局部状态，使SWA不必长期持久化。
- Decoder：每次Prefill仅将完整提示词末尾一个窗口的Encoder输出送入Decoder，建立生成所需局部状态，使CED的Prefill接近只跑前半网络。

模型40层，Encoder和Decoder各20层，SWA窗口128 token。[^SWA01]重建状态不与完整前向数学等价；作者称评估中质量影响可忽略，但承认未覆盖边界可能退化。[^SWA13][^SWA17]

来源：§2.1，[第7页](https://arxiv.org/pdf/2609.19969v1#page=7)；§3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)；§4.2.1，[第21–22页](https://arxiv.org/pdf/2609.19969v1#page=21)；§6，[第37页](https://arxiv.org/pdf/2609.19969v1#page=37)。

## 2. 两类KV与两种存储口径

![图01：两套记忆，各自负责什么？](swa_diagrams/01-global-local.png)

**图01读图提示：**先看两条分支：蓝色保留全局历史，紫色维护每层局部状态。重放只改变局部状态恢复方式，不把整个模型上下文缩到128。[^SWA01][^SWA02][^SWA03]


| 状态 | 用途 | 关键特点 |
|---|---|---|
| Global KV | 保存全局历史信息 | 包括main KV和indexer K，可压缩、跨层复用、量化 |
| SWA KV | 保存近期局部细节 | 每层生成自己的状态，运行时仅需最近一个窗口 |

【论文】CSA2的Full、Reindex、Reuse模式都保留每层自己的SWA KV；共享Global不等于共享SWA。[^SWA02]前两层只有SWA，其余层结合全局与局部注意力。[^SWA01]SWA因量化敏感仍用FP8，FP4 main KV是另一项优化。[^SWA03]

【论文】引言还提供了理解架构的视角：把V4看作以SWA进行局部处理、由压缩的全局上下文增强的网络；V4.1因此主要简化Global分支，同时基本保留局部注意力设计。[^SWA20]【解释】这说明SWA并不是可以随意删除的附属缓存。Bounded Replay改变它的恢复与保存方式，并不取消每层局部计算；SWA保留FP8则是另一项独立的精度选择。

单个请求在HBM中的SWA占用受窗口约束；长上下文下Global是主要增长项。持久化缓存则为未来前缀复用保留大量请求、恢复边界的状态，受到SSD、主机内存容量与I/O、互连带宽约束。[^SWA02]

【推导】每份快照只有128个位置，不代表很多会话、很多边界、数天留存的快照总量很小。

Replay是对已知token重做前向，恢复状态，不是重新采样旧回答。重放128 token也不等于上下文缩成128：Global KV仍保留历史信息。

【官方部署文档】部署Q&A把main KV与indexer K组成的分页缓存称为**Block KV cache**，对应本文主要讨论的Global缓存；SWA则归入按序列管理的**state cache**。后者保存的是运行状态，不能仅因名称含state就理解成“保存所有层输入hidden states”。[^DEP01]

来源：§1，[第4–5页](https://arxiv.org/pdf/2609.19969v1#page=4)；§2.1，[第7页](https://arxiv.org/pdf/2609.19969v1#page=7)；§2.3.1与图4，[第10–11页](https://arxiv.org/pdf/2609.19969v1#page=10)；§2.4.4，[第14页](https://arxiv.org/pdf/2609.19969v1#page=14)；§3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19)。

## 3. 为什么精确恢复很贵

### 3.1 局部依赖跨层扩展

![图02：一个小窗口，为什么会依赖很远？](swa_diagrams/02-layer-dependency.png)

**图02读图提示：**从最上方的一个位置沿连线往下看，所需输入逐层向左扩展。这里用W=4、三层演示理论依赖；实际模型窗口为128。[^SWA04][^SWA05]


每层的位置i看最近W个位置，这些位置在上一层又依赖更早的窗口。逐层展开，依赖跨度随深度增长。

【推导】最简单的纯局部因果注意力中，d层后单个输出位置的理论感受野跨度：

    R(d) = 1 + d × (W − 1)

这是教学推导，不是论文新增公式；恢复最后整窗的各层KV还涉及层索引与端点约定，不能直接用单位置感受野作为精确恢复API长度。

【论文】一般L层SWA的精确恢复需要重放最近L×n_win个token；L/2层Decoder则需处理提示词最后(L/2)×n_win个token。[^SWA04][^SWA12]

### 3.2 有界重放的核心公式

![图03：有界重放：在起点切断局部依赖](swa_diagrams/03-bounded-mask.png)

**图03读图提示：**左右对照同一个Query：红叉表示重放起点之前、原本可见但现在被截断的局部键。最后一行虽看满窗口，窗口内高层表示仍可能近似。[^SWA04]


【论文】只重放最后n_win个token，SWA可见范围截断到重放段内，接受近似状态。统一W=n_win，重放起点s，位置i的局部可见键为：

    [max(s, i − W + 1), i]

公式定位：§3.2.2开头第一段的未编号公式；W与本文的n_win为同一窗口长度。[^SWA04]

相比普通SWA的[max(0,i−W+1),i]，多了“不能看s之前局部状态”的限制。这里0是本文的序列起点约定。

局部mask可写成：

    allow_local(i,j) = (j >= s) and (j <= i) and (j >= i-W+1)

截断作用于SWA分支，Global仍按因果和稀疏选择规则访问，不应将所有历史注意力截断到s。

### 3.3 W=4教学示例

实际模型W=128。用4说明重放100～103时的变化：

| Query | 正常局部可见位置 | 重放可见位置 |
|---|---|---|
| 100 | 97～100 | 100 |
| 101 | 98～101 | 100～101 |
| 102 | 99～102 | 100～102 |
| 103 | 100～103 | 100～103 |

最后一个Query虽看到了完整窗口，但窗口内较早位置的高层表示是在截断条件下生成的，所以不能断言末尾已精确恢复。

### 3.4 近似为什么可能可用

【论文】§2.2引用Chen等人的PowerAttention工作，指出实际有效感受野小于理论跨层感受野，作为Decoder重放的动机；本文实验称质量影响很小。[^SWA05][^SWA13]

【解释】理论感受野指“存在影响路径”，有效感受野指“实际影响是否显著”。存在远程路径不代表必须完整重建每条路径。全局分支保留历史也是理解该架构的关键，但不保证完全补偿所有局部截断误差。

来源：§2.2，[第9页](https://arxiv.org/pdf/2609.19969v1#page=9)；§3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)。

## 4. Encoder路径：Global命中、SWA缺失

### 4.1 触发位置与流程

![图04：Encoder：前缀命中了，局部状态却丢了](swa_diagrams/04-encoder-replay.png)

**图04读图提示：**沿三条水平带对照：旧Global只读复用；前缀尾窗只重建SWA；新后缀才生成两类KV。虚线P明确区分重放区与新增区。[^SWA06][^SWA07]


请求tokens[0:N]，命中前缀tokens[0:P]，未缓存后缀tokens[P:N]。使用半开区间：

    s = max(0, P-W)
    replay_prefix = tokens[s:P]
    uncached_suffix = tokens[P:N]

【论文】重放缓存前缀最后一窗，并与未缓存后缀一起处理：[^SWA06]

1. 检查Global命中与短期Encoder SWA快照；SWA命中则正常续算。
2. SWA缺失时，重放缓存前缀尾窗。
3. 对旧前缀位置，只重建SWA KV；旧Global KV直接复用，不重算、不覆盖。
4. 对新后缀，正常生成Global KV和SWA KV。

第2～4项为论文核心机制，第1项用于说明完整执行顺序。

> **原文短引｜旧Global如何处理**
> “without recomputation or overwriting”
>
> **释义：**已有Global KV不重新计算，也不被重放结果覆盖。定位：§3.2.2，Encoder小节第2段，第20页。[^SWA06]

    旧前缀 [0 .................. P) | 新后缀 [P ........ N)
            已缓存Global继续复用     | 新增Global
                    [P−128 ... P)   |
                    重放、重建SWA ──→ 正常处理新后缀

这是“缓存前缀尾窗”，不能拿“整个新提示词尾窗”替代，否则新后缀开头可能缺少局部状态。

### 4.2 关键实现边界

不能在重放时用近似隐状态产生的新Global覆盖旧Global，论文明确要求旧Global不重算、不覆盖。

【论文】近似前缀状态会影响新后缀，因此后缀生成的Global KV和SWA KV都依赖命中位置，在不同命中边界下并非数学相同。[^SWA07]

【推导】同一输入换不同缓存切分点，隐状态乃至输出可能变化；不能以跨边界逐位一致作为算法必然保证。

来源：§3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19)；§3.2.2 Encoder段，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)。

## 5. 配套缓存生命周期设计

![图05：缓存分层：按寿命保存，缺失时恢复](swa_diagrams/05-cache-lifetimes.png)

**图05读图提示：**左边是旧方案的长期快照，右边将Global长寿命与Encoder SWA短寿命分开。短期SWA丢失后，只有Global仍命中时才进入图中的恢复路径。[^SWA08][^SWA09][^SWA10]


### 5.1 V4原方案

【论文】Global和SWA独立管理，LRU淘汰。Global完整保存，命中复用整个匹配前缀；SWA在提示词末尾和输出末尾保存快照，服务重新生成、多轮交互。典型负载下两类状态均在SSD中留存超过72小时。SWA占持久化容量近一半，短轮次多轮会话尤其明显。[^SWA08]

Global有长尾复用；特定边界的SWA快照主要在活跃会话的分钟级时间窗口复用，会话结束或进入下一轮后，旧快照通常失去价值。[^SWA08]“旧快照过时”不等于后续不用SWA，活跃计算仍需更新当前局部状态。

【官方部署文章】知乎原文进一步说明V4生产路径是“落盘加精确重算”：快照缺失时沿“层数×窗口”的历史做完整前向，恢复成本高，因此需要较大的SSD容量把miss压得很低。这使短寿命SWA也占用了长时间留存空间。[^ZH03]【理解提炼】Bounded Replay先把缺失后的恢复代价降下来，再让SWA按短寿命保存；短期池覆盖常见复用，重放承接淘汰后的请求。

### 5.2 V4.1的安排

| 状态 | 位置/管理方式 | 生命周期 |
|---|---|---|
| Global KV | 长期持久化缓存；运行时加载到相应计算位置 | 至少72小时 |
| Encoder SWA | 每台机器约10%主机DRAM构成分布式池 | 分钟级TTL；缺失则重放 |
| Decoder SWA | 当前请求的解码状态 | Prefill重建供Decode，不用于前缀缓存 |

本表定位：第19页编号条目1描述Global与Encoder SWA；第20页Decoder小节描述Decoder SWA。[^SWA09][^SWA12]

> **原文短引｜主机内存比例与长期留存**
> “10% of the host DRAM”；“at least 72 hours”
>
> **释义：**前者是每台机器贡献给短期池的主机DRAM比例，后者是Global KV的长期生命周期保证。定位：§3.2.1编号条目1，第19页。[^SWA09]

【论文】小而高周转的短期池已可覆盖实际负载下绝大多数并发活跃会话。Global命中但SWA缺失并不常见，却不可避免；Bounded Replay提供便宜的兜底。[^SWA09][^SWA10]

系统不是不再保存任何SWA；运行时HBM和短期DRAM仍有对应状态。

【官方部署文章】后续线上数据把“分钟级、高命中”进一步量化：**SWA池TTL约180秒，命中率在98%以上**。这是官方在其部署负载下报告的结果，不是论文给出的通用配置或质量指标；与整体输入缓存命中率96%的区别见第7.7节。[^ZH01][^ZH04]

### 5.3 相比Zero SWA Caching的进步

【论文】V4已提出靠重算免除SWA存储的Zero SWA Caching，但精确恢复L×W token的代价在生产中过高。V4.1接受近似，将恢复跨度限制为W，使免除长期SWA存储更实用。[^SWA10]

【解释】可把存储与恢复的选择放在同一张表里，理解V4.1为何同时需要短期池和Replay：

| 路线 | 保留什么 | 状态缺失后的代价 | 主要取舍 |
|---|---|---|---|
| V4长期保存SWA | 指定边界的SWA快照与Global | 命中时直接续算；缺失时精确重算 | 高恢复成本要求尽量压低miss，短期复用与长期留存不匹配 |
| Zero SWA Caching的精确恢复思路 | 不靠保存SWA来续接 | 沿跨层依赖处理更长的历史跨度 | 节省存储，但论文称精确恢复在生产中太贵 |
| V4.1短期池＋有界重放 | 长期Global、短期Encoder SWA | 短期SWA命中则续算，缺失则重放一窗 | 用有限重算和近似状态换取更低的长期存储责任 |

前两行不是说保存与精确重算在所有系统中都不可用；第三行是论文在其负载下选择的折中。V4缺失时精确重算的生产描述另由后续知乎文章确认。[^SWA08][^SWA09][^SWA10][^ZH03]

来源：§3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19)。

### 5.4 官方部署如何存放SWA：StateBlock与短期目录

【官方部署文档】论文讲的是两类缓存的寿命；DeepInfer Q&A进一步给出了存储组织。每条序列对应一个固定大小的`StateBlock`，SWA不放入Global的分页Block中。[^DEP01]

| 区域 | 内容 | 跨请求保存及使用方式 |
|---|---|---|
| stored region | 前20层Encoder SWA | 提取为短期快照，留在产生它的机器主机内存中 |
| dropped region | 后半网络的YOCO consumer SWA，以及`ca_state`/`ica_state`压缩边界状态 | 不写入跨请求保存的SWA快照；当前推理仍需要它们，P→D传输可包含这些状态 |
| 独立的Block KV | main KV＋indexer K | 长期保存在专用3FS存储集群，供各Prefill机器复用 |

这里源码的YOCO consumer对应后半网络的消费层。压缩边界状态可以不随快照保存，是因为其压缩窗口与128-token保存粒度对齐；这项边界条件不能直接推广到任意模型。[^DEP01][^DEP02]

【官方部署文章】知乎“KVCache Storage”开头还明确：Block以128个token为单位管理，保存4层的main KV与indexer K；供跨请求短期复用的SWA快照则来自前20层，各有134个位置。这是Global跨层复用与SWA逐层维护在存储布局上的具体差别，不应理解成每层都持久化一份Global。[^ZH02]

Q&A给出的SWA快照数据量为：

    20层 × 134个位置 × 528 B = 1,415,040 B / 序列（约1.35 MiB）

528 B由512 B的FP8数据与16 B的缩放数据组成；134的位置数含128的窗口和6的位置余量，详见第8.8节。这个数字仅指需保存的SWA区域，不含完整运行时StateBlock、Global、目录和传输缓冲。源码变量`state_size_to_disk`及部分注释沿用“disk/落盘”名称，但Q&A明确：**这份SWA快照留在主机内存，不进入3FS长期存储**。[^DEP01][^DEP02]

短期SWA只有单副本；逻辑统一、按key分片的Entrypoint内存目录记录持有它的机器，跨机器命中时通过400G VLAN拉取。P→D传输与Block KV共用传输路径。因而“本机没有SWA”不必然就是全局miss；真正缺失时才需要重放。[^DEP01]

### 5.5 官方保存时机与长期缓存的分工

【官方部署文档】SWA快照只挂在128-token整数倍边界。Prefill结束时，先预留末尾1个token，再向下对齐到128；不足一个保存单位则不存，chunked prefill的中间chunk也不保存。Decode每跨过128边界，就在设备内将当时窗口复制到独立副本区；结束时使用最近完成的副本。一次跨步可能越过边界最多5个token，环形缓冲区的6个额外位置用于承接这类情况。[^DEP01]

【解释】“在提示词尾部或输出尾部保存”是用途描述；“实际存在哪个对齐边界”是实现规则。不能把任意token位置都当成已有快照的位置，也不能把环形缓冲区的物理长度当成attention窗口。

Q&A还细化了长期Block缓存的部署：由3FS回收，Agent流量保留3天、Chatbot流量保留7天；任意Prefill机器都可命中同一长期前缀，有利于计算负载均衡。它补充了论文“至少72小时”的部署语境，不意味着Encoder SWA也保留3—7天。[^DEP01]

## 6. Decoder路径：让CED Prefill接近减半

![图06：Decoder：只让提示词尾窗穿过后半网络](swa_diagrams/06-decoder-ced.png)

**图06读图提示：**从Encoder出口分成两路：一路投影和复用Global，另一路只取提示词尾窗送入Decoder，准备局部KV。图中省略了具体缓存命中调度。[^SWA11][^SWA12][^SWA13]


### 6.1 CED的结构前提

【论文】40层分为20层Encoder和20层Decoder。Decoder的Global KV可由Encoder最终隐状态投影，而不是逐层依赖每个Decoder层自己的隐状态：

    C_l = H_(L/2) W_l^KV
    Z_l = H_(L/2) W_l^Z,  l > L/2

公式定位：§2.2第2段及式(1)，第9页。[^SWA11]

C为KV条目，Z为压缩权重。结合CSA2实际配置，Full层生成Global，后续Reindex/Reuse层复用；不能理解成每层最终都单独存一套Global。[^SWA11]

### 6.2 剩下的障碍是Decoder SWA

Decoder SWA仍来自各层自身隐状态，第一批Decode步骤需要它们。仅投影Global不足以准备好生成。[^SWA12]

【论文】Decoder SWA不做前缀缓存，精确恢复需要在L/2个Decoder层上处理提示词最后(L/2)×n_win个token。“长命中前缀＋短新后缀”时该成本明显。[^SWA12]【按模型参数推算】L/2=20、n_win=128，因此跨度为20×128=2,560个token；2,560是本文代入参数的结果，不是独立实测值。[^SWA01]

### 6.3 每次Prefill只跑提示词尾窗

【论文】取完整提示词最后一窗的Encoder输出，在同样局部截断下通过Decoder各层，得到Decoder SWA KV，仅供接下来的Decode，不用于前缀缓存。

> **原文短引｜Decoder局部状态的用途**
> “not for prefix caching”
>
> **释义：**这些Decoder SWA状态用于随后的解码，不用于前缀缓存。定位：§3.2.2，Decoder小节第2段末尾，第20页。[^SWA12]

    提示词 → Encoder计算/缓存复用
                    ├→ 最终隐状态 → 投影、复用Decoder Global
                    └→ 提示词末尾至多128个位置的Encoder输出
                                            ↓
                                    20层Decoder前向
                                    SWA在起点截断
                                            ↓
                                    近似Decoder SWA
                                            ↓
                                        正常Decode

【工程建议】短新后缀时，Decoder尾窗可能部分落在命中前缀里，调度器仍须取得这些位置的Encoder最终输出。只拿到投影后的Global，不能假设可反演隐状态。论文没有完整公开所有命中组合的调度代码；后续官方Q&A补充了通过限制前缀命中长度、预留尾部计算的策略，见第8.7节。

【官方部署文档】上述128是论文机制的窗口口径。实际Decoder尾部保留量还需覆盖投机回退余量，DeepInfer README建议`KEEP_TOKENS=140`；模型的SWA窗口仍为128，见第8.8节。[^DEP03]

【表述校准】知乎Decoder条目开头概括为“prefill计算仅在encoder层进行”，同一条目随后明确还会在Decoder处理末尾128个token。因此汇报应说：**完整提示词的主要Prefill工作集中于Encoder，Decoder仍执行有界尾窗前向**，不能说Decoder在Prefill阶段完全不运行。[^ZH03]

### 6.4 两条路径对比

| 维度 | Encoder | Decoder |
|---|---|---|
| 触发 | Global命中、Encoder SWA缺失 | 每次Prefill |
| 位置 | 缓存前缀最后一窗 | 完整提示词最后一窗 |
| 输入 | 已知token/输入表示 | 对应Encoder输出 |
| 产物 | 缺失的Encoder SWA；新后缀正常产生两类KV | 解码用Decoder SWA |
| 作用 | 解除长期SWA存储依赖 | 限制后半网络Prefill计算 |
| 是否近似 | 是，后缀两类KV也随命中点变化 | 是，不等价于完整Decoder前向 |

### 6.5 后训练模拟

【论文】Decoder路径说明中，作者表示后训练期间模拟相同replay，做train-aware adaptation。[^SWA13]未给出模拟比例、具体调度、专门损失项或独立消融。

【工程建议】只改推理系统、不做相应适配，或迁移到其他模型/精度配置时，不能直接继承论文的“质量影响很小”结论。应在实现正确性的检查之外，另做固定输入、不同缓存命中位置下的质量评估。后训练适配与实现正确性是两件事：训练不能代替对mask、位置编号、非法缓存读取和写入边界的检查。

来源：§2.2，[第9页](https://arxiv.org/pdf/2609.19969v1#page=9)；§2.3.1，[第11页](https://arxiv.org/pdf/2609.19969v1#page=11)；§3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)。

## 7. 收益应如何归因

### 7.1 持久化约降至1/8

![图07：持久化占用 1/8：是两项收益相乘](swa_diagrams/07-storage-savings.png)

**图07读图提示：**以原占用100为示例，先移出约50的长期SWA，再把剩余Global从50压到12.5。两段箭头对应不同优化，不是Replay独自贡献八倍。[^SWA14]


【论文】同负载下，V4.1持久化KV约为V4的1/8，由两个因素相乘：移除长期SWA，约去掉原占用的一半；留下的Global经架构和精度优化，再缩到原对应占用的约1/4。[^SWA14]

【推导】原SWA比例f、Global压缩后比例r：

    C_new/C_old = (1-f) × r
    f≈0.5, r≈0.25 → 0.125

教学算例：原100单位，Global50、SWA50；移出SWA剩50，再压成12.5，即持久化占用减少约87.5%。

不能说Replay单独压缩8倍，也不能说整个服务总内存或成本减少87.5%。短期池、HBM、权重和元数据仍占资源。1/8也与负载中SWA快照比例有关，不是普适常数。

来源：§3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19)。

### 7.2 Global的890 bytes/token属于另一项收益

【论文】Global KV为890 bytes/token，约为V4-Flash的1/4，来自CSA2跨层复用、FP4等优化。[^SWA15]它不是整个请求所有状态的总每token占用，也不是Replay单独结果。

来源：摘要，[第1页](https://arxiv.org/pdf/2609.19969v1#page=1)；§1，[第4–5页](https://arxiv.org/pdf/2609.19969v1#page=4)；§6，[第37页](https://arxiv.org/pdf/2609.19969v1#page=37)。

### 7.3 序列跨度减少不是端到端加速倍数

![图08：计算收益：先分清跨度，再谈 Prefill](swa_diagrams/08-replay-compute.png)

**图08读图提示：**上半图按token跨度绘制2560与128，比例为20:1；下半图是长输入下的简化计算模型。两者都不能直接替代端到端时延测量。[^SWA01][^SWA12][^SWA16]


| 口径 | 精确恢复长度表述 | 有界重放 |
|---|---:|---:|
| 一般L层局部依赖链 | L×128 | 128 |
| 实际20层Decoder | 2,560 | 128 |

表中数值由原文恢复长度公式与模型参数换算；跨度比较不是端到端时延测量。[^SWA01][^SWA04][^SWA12]

Decoder跨度缩短20倍。一般公式代入总深度40可得5,120→128的40倍跨度，但模型实际分成两个20层层组，不能将5,120冒充论文独立实测的Encoder恢复长度。

重放token仍需通过相应层组的Attention、MoE等。Global加载、索引、通信、访存、批处理影响实际时间；有界的是token跨度，不是保证整个请求时间与历史长度无关。论文没有独立端到端20倍/40倍提速结果。

【表述校准】知乎文章与官方Q&A均用“与上下文长度、层数无关的常数”概括重算代价。汇报时应把它收紧为：**需要向历史回放的token跨度固定为一窗，不再随深度扩大；这一窗仍须经过相应层组。** 用D表示需经过的层数，简化的token×layer工作量仍约为D×W，不能理解为增加层数完全不增加计算。[^DEP01][^ZH03]

### 7.4 长输入Prefill接近减半的条件

【论文】N远大于W时，按简化工作量模型：

    原：O(NL)
    新：O(NL/2 + W×L/2) ≈ O(NL/2)

公式定位：§2.2最后一段，即§2.3标题之前，第9页。前提是N远大于n_win。[^SWA16]

【推导】工作量比例约1/2+W/(2N)。W=128、N=32,768时约0.501953，即减少49.8%。这是假设层计算近似同权的教学计算，不是实测时延。它描述主导项常数近半，不代表大O渐进类别改变。

短提示词、短新后缀中，固定窗口重放等开销比例更大，不能直接套完整N的公式声称任意请求提速两倍。Prefill收益依赖CED与Decoder Replay配合，不适用于任意架构单开Replay。

来源：§2.2，[第9页](https://arxiv.org/pdf/2609.19969v1#page=9)；§3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)。

### 7.5 质量证据的边界

![图09：近似会传到哪里？怎样理解质量结论？](swa_diagrams/09-quality-boundary.png)

**图09读图提示：**相同输入从两个命中边界恢复，会产生不同的近似前缀状态，并影响新后缀的两类KV。该图表达误差路径，不表达实测误差大小。[^SWA07][^SWA13][^SWA17]


【论文】两条路径质量影响被描述为很小；重建不等价；后训练模拟Decoder replay；结论承认未测试边界风险。

> **原文短引｜近似性与质量结论**
> “not mathematically equivalent”；“only a negligible impact”
>
> **释义：**数学上不等价，但作者报告在其评估中回答质量影响很小。定位：§3.2.2，Decoder小节第3段，第20页。[^SWA13]

边界提醒的原文位置：§6第2段，第37页；作者将缓存恢复边界上的SWA重建列为继续测试的重点。[^SWA17]

在**v1论文范围内**，全文核对未找到这些SWA Replay专项披露：开关前后的逐项benchmark分数、重放长度消融曲线、重复恢复误差统计、独立P50/P99时延或吞吐倍数、精确生产miss比例、128为普适最优长度的证明。[^SWA19]后续知乎文章补充了SWA池命中率下界和启用140-token Decoder Replay的整体Prefill曲线，见第7.7节；这些新披露不构成Replay的独立开关消融。

不能把模型整体榜单提升归因于Replay，也不能把“影响可忽略”写成完全无损、逐位一致或未经披露的精确百分比。

来源：§3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20)；§6，[第37页](https://arxiv.org/pdf/2609.19969v1#page=37)；全文相关词检索与相关页核对。

### 7.6 论文自述的局限与未来验证重点

【论文】§6第2段给出的限定可以分为四层，汇报时应与“质量影响很小”一起陈述：[^SWA17]

| 论文陈述 | 应如何理解 |
|---|---|
| 内部评估覆盖多样测试与边界，已评估设置中未见系统性能力退化 | 是有限评估范围内的观察，不是覆盖所有输入的保证 |
| 测试无法穷尽极端输入与部署条件 | 换模型、换缓存调度或换精度后，需要重新确认适用范围 |
| CSA2的选择误差与SWA近似状态重建可能在未测边界引发能力退化 | 论文同时指出两类风险，不能把所有异常自动归因于Replay |
| 后续将重点压测长上下文稀疏检索与缓存续接边界上的SWA重建，并观察真实负载 | 除平均任务分数外，还要关注恢复边界、连续恢复及真实请求模式 |

【工程建议】对本技术最直接的验证对象是cache-resumption边界：SWA淘汰后重新进入计算的时刻，以及同一提示词由不同命中位置续接的情形。第9.4—9.5节给出可执行的评估分工，不将平台个例提升为论文的普适结论。

来源：§6第2段，[在线第37页](https://arxiv.org/pdf/2609.19969v1#page=37) · [本地第37页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)。

### 7.7 后续官方线上数据：分清SWA命中、输入复用与整体性能

【官方部署文章】以下来自2026-10-20更新的知乎文章及其配图，属于论文之后的部署披露：[^ZH01][^ZH04]

| 数据 | 原文位置与对象 | 正确解读 |
|---|---|---|
| TTL约180秒、命中率超过98% | “SWA KVCache”第1段；短期SWA池 | 支持短期保存足以覆盖其大部分实际复用；不是所有业务均可达到的保证 |
| 平均输入缓存命中率96% | “实际线上运行数据”图；整体输入缓存 | 与SWA状态命中率属于不同统计对象，不能相互替换 |
| Prefill每卡60K tokens/s（不含缓存命中）、1.5M tokens/s（含缓存命中） | 同一线上数据图 | 计入已复用输入后的服务吞吐与实际新算吞吐口径不同；不能据此声称Replay单独加速25倍 |
| 平均TTFT 400 ms、P99 1,000 ms | 同一线上数据图；完整服务 | 是整套系统的时延，不能当作单次SWA恢复耗时 |

文章没有在SWA段落给出命中率的完整采样窗口与统计分母；“超过98%”也不是一个精确miss比例。因此不能直接把2%套到全部请求上，宣称平均每请求重放2.56个token。第9.3节的p×W仍需由自身业务中实际触发Encoder Replay的概率估计。Decoder Replay则是另一条每次Prefill执行的路径。

![官方部署原图：启用140-token Decoder Bounded Replay的Prefill吞吐与时延](references/zhihu_deepinfer_prefill_140.jpg)

图源：[知乎文章“离线性能基准测试数据”](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_2)，从用户提供的MHTML中提取，未改动原图。原图条件为EP4/DP4、384＋32 experts、上下文131,072，以及Decoder Bounded Replay 140 tokens；横轴是每个Prefill step的延迟，纵轴是不含缓存命中的每GPU输入吞吐，点标签是每个DP rank的Prefill batch token数。[^ZH04]

这张图直接证明官方部署基准使用了140-token保留配置；它只展示启用该配置后的不同批大小表现，没有Replay关闭或精确恢复对照，不能从曲线单独分离Replay贡献。原图也没有解释140相对134的差值来源，第8.8节继续保留这一限定。

## 8. 实现方法：请求流程、伪代码与工程接口

第8.1—8.6节把论文机制映射为通用工程建议；第8.7—8.10节补充后续官方部署规则及已阅读的DeepInfer源码。两者分开标注，通用伪代码不等于完整生产实现。

### 8.1 一次请求的分流与处理顺序

先确定有效的Global命中前缀长度P，再检查与该边界兼容的短期Encoder SWA快照。长期前缀复用不依赖SWA永久保存，不等于完全跳过短期SWA查询。[^SWA06][^SWA09]

| 请求状态 | Encoder处理 | CED下的Decoder准备 |
|---|---|---|
| Global没有可复用前缀，P=0 | 正常处理缺失的完整提示词，建立所需状态 | 取得完整提示词尾窗的Encoder输出，再准备Decoder SWA |
| Global命中，且该边界的Encoder SWA有效 | 从P续算未缓存后缀 | 每次Prefill仍建立供Decode使用的Decoder SWA |
| Global命中，但Encoder SWA缺失或不兼容 | 从s=max(0,P−W)重放前缀尾窗，与新后缀共同处理；旧Global只读 | 取得完整提示词尾窗的Encoder输出，在局部截断下经过Decoder各层 |

【工程建议】短期快照应匹配请求的前缀边界、模型/权重版本、位置处理和缓存格式；不能把“找到了一个SWA对象”当作可直接续算。全前缀命中或新后缀不足一窗时，也要落实Decoder所需尾窗Encoder输出的来源。

### 8.2 机制伪代码

以下是论文机制的教学伪代码，不是官方源码，也不是可直接运行的服务。省略压缩块、输入表示、并行通信、分配器及稀疏路由。调用前假定Global命中长度已验证，传入的非空SWA快照已通过上述兼容性检查。

~~~python
W = 128  # 本论文模型配置；迁移到其他模型时从其配置取得。

def local_visible(i, j, replay_start):
    return max(replay_start, i - W + 1) <= j <= i

def encoder_resume(tokens, prefix_len, global_cache, swa_snapshot):
    P, N = prefix_len, len(tokens)
    if P == 0:
        return encoder_forward(
            tokens, start_pos=0, global_cache=global_cache,
            mode="normal_append")
    if swa_snapshot is not None:
        return encoder_forward(
            tokens[P:N], start_pos=P,
            global_cache=global_cache, swa_state=swa_snapshot,
            mode="normal_append")
    s = max(0, P - W)
    return encoder_forward(
        tokens[s:N], start_pos=s,
        local_attention_lower_bound=s,
        global_cache=global_cache, replay_prefix_end=P,
        # [s,P)：重建SWA，历史Global只读，不生成或覆盖。
        # [P,N)：正常生成Global与SWA。
        mode="bounded_prefix_replay_then_append")

def decoder_prepare(prompt_length, encoder_outputs, global_cache):
    t = max(0, prompt_length - W)
    H_tail = ensure_encoder_outputs(t, prompt_length, encoder_outputs)
    swa_state = decoder_forward(
        H_tail, start_pos=t, local_attention_lower_bound=t,
        global_cache=global_cache, build_local_state=True)
    return swa_state  # 供Decode，不用于前缀缓存。
~~~

### 8.3 必须保持的状态一致性

实现一致性要求：

1. 保留原始位置编号，使RoPE、压缩和因果索引对齐；重放起点不应被误认为整个历史的新起点。
2. SWA在s截断，Global不套用同样截断。
3. 重放旧前缀不改写旧Global；新后缀才正常新增Global。
4. 已缓存Global即使含有某Query之后的条目，Query仍只能读取因果可见位置。
5. Decoder尾窗的Encoder输出必须可取得；Global命中不自动意味着对应隐状态可用。
6. Global未命中时，128-token replay不能凭空重建整个历史，仍须正常处理缺失上下文。

第2、3项直接来自论文，其余为根据机制提出的一致性要求，不能声称论文已公开具体代码。[^SWA06][^SWA12]特别是多模态输入、压缩块边界、全命中但需取尾窗隐状态等场景，生产实现仍需补全。

### 8.4 推理框架需要承接的六类接口

下表是从机制推导的工程拆分；具体类名、缓存组织和kernel接口须以目标框架为准。后续官方实现的具体承接方式见第8.7—8.9节。

| 部件 | 需要完成的职责 | 需要特别区分的边界 |
|---|---|---|
| 前缀匹配与缓存生命周期 | 以有效Global状态确定可复用前缀，另外查询匹配边界的短期Encoder SWA | SWA移出长期持久化，不代表不再为短期池和运行时SWA统计容量、淘汰及回收 |
| 调度器与计算进度 | 分别描述已缓存区、重放区、未缓存后缀，保留原始位置编号；在分块/批处理时传递重放起点 | 单个`num_computed_tokens`计数若只代表Global命中，不能直接证明所有层SWA已准备好 |
| Attention mask与元数据 | SWA按max(s,i−W+1)限制左边界；让可见长度、块表和有效slot一致；Global仍遵守自己的因果规则 | 不可把重放起点以前的SWA逻辑位置当作可读，也不可读取无效块或把回收物理块的残留内容当作有效KV |
| KV写入与分配 | 为重放SWA分配有效目标slot，旧前缀Global只读，新后缀正常追加；维护共享Global的引用关系 | “旧位置只重建SWA”是写入规则，不是“只算KV投影、跳过attention”的同义词 |
| 输入表示与状态取得 | 确保重放所需输入可取得；Decoder尤其需要完整提示词尾窗的Encoder最终输出 | 这是Decoder的输入条件，不等于论文要求长期缓存每个层的输入hidden states；如何取得须单独设计 |
| 模型参数与缓存精度 | 从目标配置读取窗口、层组、位置规则和各分支精度；复现本模型时尊重主KV与SWA的精度差异 | 128是V4.1-Flash配置；SWA保留FP8，不能因主KV采用FP4就自动给SWA套相同路径 |

其中mask、旧Global处理、Decoder输入和SWA精度分别对应第20、14页的论文依据；进度计数、分配器与块表是框架实现层面的表达。[^SWA03][^SWA04][^SWA06][^SWA12]

### 8.5 隐状态取得与“只重算KV投影”应如何区分

**论文没有把“缓存所有层输入hidden states、只做KV投影、不跑attention”规定为SWA Bounded Replay的原生路线。** 第20页Encoder段描述重放缓存前缀尾窗、与未缓存后缀共同处理；Decoder段明确把尾窗Encoder输出送过Decoder各层。接受跨层近似及命中位置依赖，本身就是论文设计的一部分。[^SWA06][^SWA07][^SWA12]

【官方部署文档】知乎原文及后续Q&A均明确：Encoder重放的128个token与未缓存后缀一起做前向，旧Block KV保持原样。官方源码还对后半网络的query布局进行`compact`，保留的是Encoder/Decoder边界上的当前计算表示；这不等于长期保存所有层输入以跳过attention。[^DEP01][^DEP04][^ZH03]

| 情形 | 定位与含义 |
|---|---|
| Decoder需要尾窗的Encoder最终输出 | 论文明确的输入条件；不能假定投影后的Global足以反演这些表示 |
| 系统另行保存各层输入hidden states，再用投影生成KV | 是需要另行设计和计账的状态保存/恢复方案；正确性取决于保存的状态、位置及投影/量化流程，不能自动等同于本文算法 |
| 仅因截断后重算产生近似KV，就认定论文机制结构性错误 | 不成立；近似KV与后缀依赖命中点是论文承认的行为，应继续区分允许的近似和实现错误 |

【工程建议】若选用保存隐状态的方案，需额外说明保存哪些层和位置、寿命/容量、缓存一致性、状态如何失效，以及它与论文持久化收益口径的差别。若重放阶段完全不执行attention，本次attention mask也不能被当作这一路径唯一的近似来源；应追溯实际使用的隐状态和生成流程。

### 8.6 OmniInfer / vLLM的候选排查入口（待代码核验）

下列名称来自[Claude版的工程附录](<SWA Bounded Replay 论文讲解-claude-code.md>)，保留其定位价值，但本任务没有读取对应仓库、确认提交版本或复现实验。这是一份后续代码审查清单，不是DeepSeek官方实现清单，也不证明当前平台一定支持相应能力。

| Claude版给出的候选入口 | 应核对什么 |
|---|---|
| `npu_cla.py`、`attn_cla_swa` | 全局共享源、本层SWA数据流、不同层组的真实执行路径 |
| `ShareKVSlidingWindowSpec`、`ShareKVSlidingWindowManager` | 物理窗口容量、逻辑可见窗口、slot分配与decode重算是否分开定义 |
| `SlidingWindowManager.find_longest_cache_hit` | Global和SWA如何参与命中；尾窗连续块、占位块与恢复起点如何关联 |
| `kv_offload`及PD传输路径 | 现有host内存容量与淘汰策略能否表达独立短期SWA池；跨阶段传输哪些状态 |
| `_apply_local_swa`、`build_replay_swa_visible_lens`等候选mask入口 | 原始位置、局部下界、有效长度与块表是否一致；是否存在无效slot可见的问题 |
| 模型配置与KV量化入口 | 实际W、层数、两分支精度，以及可能的额外保留位置；不要直接套128或未经核对的W+1规则 |

Claude版还记录了特定vLLM版本、PR号、模型窗口数值及重复请求乱码的实操结论。这里不把这些记录当作已验证事实，也不据此给出“某版本一定不能实现”的结论。确认它们需要对应commit、patch、输入、缓存命中轨迹和日志；仅凭摘要无法确定因果。可借鉴的验证方法见第9.5节。

### 8.7 官方部署中的命中与回退：两个进度要分开

【理解提炼】**Block决定长期前缀能复用到哪里；SWA决定续算前是否需要回放一窗。** 这是对官方命中规则的中文概括，不是逐字引文。[^DEP01]

知乎“命中策略”与官方Q&A一致给出的流程是：[^ZH03]

1. 为Decoder尾部计算保留余量。若输入长度为N，文档示例将最大命中长度限制到N−134以内（128窗口＋6回退余量）。
2. 在该上限内查Block KV，得到128整数倍的命中长度H。
3. 再查H−128到H范围内的SWA快照。满足文档命中条件时保留H；SWA缺失则把续算进度退到H−128，重放最后一块。

【实现含义】退回的是“从哪里开始前向”，不代表该块原有Global要失效或被覆盖。应分别记录**可复用Block末端H**与**前向重放起点F**。这正对应第8.2节的`prefix_len`与`s`；新后缀仍从H开始，F到H之间的Global只读。[^DEP01]

【教学算例】N=1,000，按Q&A的上限先得866；假设Block命中H=768。SWA缺失时从F=640开始：640—767重建局部状态，768—999为新后缀。这里只演示边界区分；短输入、H不足128、快照覆盖区间与当前配置的处理仍须结合实现，不能机械得到负起点。

保留尾部未命中区，也解释了系统如何为Decoder取得近期Encoder输出，避免把“输入能命中”误当成“整条Prefill可以零计算”。Q&A的134是其给出的命中余量口径；README的140是Decoder配置口径，需分别核对，不能直接替换或相加。

### 8.8 128、134、140，以及mask与compact的区别

【官方部署文档／源码】这三个数字属于不同对象：[^DEP01][^DEP02][^DEP03]

| 数值 | 对象 | 应如何理解 |
|---|---|---|
| 128 | 模型SWA窗口W；论文基本重放跨度；另也是保存粒度 | 数值相同，语义仍需分开 |
| 134＝128＋6 | Q&A所述SWA状态环长度及命中余量 | 包含投机回退空间，不把attention窗口扩大到134 |
| 140 | README推荐的Decoder尾部保留参数R | 覆盖窗口与最大回退量；不是论文把W改成140 |

源码的约束是`R >= W + MAX_BACKTRACKING_TOKENS`；默认最多投机5个token，回退配置至少为5＋1。README明确推荐R=140，知乎的离线Prefill图也标明140；两者均未把140相对134多出的6个位置逐项解释为另一项固定机制，因此本稿不补造“128＋6＋6”的来源。更改投机长度后应重新检查上述约束。[^DEP03][^ZH04]

启用Decoder优化的推荐配置为`DEEPINFER_YOCO_PREFILL_TRUNCATION_MODE=compact`、`DEEPINFER_YOCO_PREFILL_KEEP_TOKENS=140`。需要显式设置：环境变量声明的模式默认值是`off`，KEEP默认0；README中的推荐配置不等于源码默认已启用。[^DEP03]

| 模式 | SWA可见范围 | query与后半网络计算 |
|---|---|---|
| `off` | 不施加这项尾部截断 | 基线模式 |
| `mask` | 滑窗与尾部保留区间的交集 | 保留全部query行，只改变局部可见域；可用于对照截断语义 |
| `compact` | 与mask使用相同截断规则 | 真正移除不需保留的query行，并同步调整位置、索引与写入槽，以减少后半网络计算 |

【官方源码】`yoco_swa_visibility`还把SWA状态有效起点纳入下界，避免访问无效历史；`compact_yoco_boundary`收集保留行的hidden/residual等表示，`get_consumer_view`切换元数据。分块Prefill中，位于保留区间之前的chunk可能保留一个占位行，且禁止它写入SWA ring。因此“有界”不等于所有调度形态下恰好只有128个计算行。[^DEP04]

【解释】修改mask确保“看哪些key”正确；compact负责“哪些query真正不用再算”。前者本身不能证明已获得后者的计算收益。以R表示保留跨度时，SWA窗口仍用W，不能把公式中的W一并改成R。

### 8.9 已核验的官方实现入口与开源边界

以下均已静态阅读，固定到DeepInfer提交`553741557a57`；没有运行GPU模型或复现实测。它们与第8.6节尚未核验的OmniInfer候选入口应区别使用。

| 官方入口 | 可核对的内容 |
|---|---|
| [cache_engine.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/cache_engine.py#L221) | StateBlock两区布局、SWA环大小、保存区域与P→D传输范围 |
| [environ.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/environ.py#L194)与[model_runner.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/model_runner.py#L101) | 模式默认值、保留长度与窗口/回退量约束 |
| [prepare_tensor_input_v4.cpp](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/csrc/engine/input_metadata/prepare_tensor_input_v4.cpp#L129) | 可见域下界、保留行、占位行与slot映射 |
| [input_metadata/yoco.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/input_metadata/yoco.py#L86)与[v4_modules/yoco.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/models/v4_modules/yoco.py#L93) | consumer元数据切换与边界表示压缩 |
| [examples/yoco](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/examples/yoco/README.md) | mask/compact的元数据与固定轨迹输出对照 |

【官方部署文档】开源包提供具备核心能力的离线推理；完整服务仍需要KV缓存系统、分离部署和负载均衡等配套，缓存管理与负载均衡没有完整开源。读取到状态布局和重放代码，不等于已拿到全部短期目录、TTL和线上命中调度实现。[^DEP06]

### 8.10 缓存命中后的数据路径与调度成本

【官方部署文章】旧Global“不重算”，仍需要匹配、读取和换入。知乎“Block KVCache”第3段把命中路径分为三段：[^ZH05]

| 阶段 | 官方部署方式 | 与Replay讲解的关系 |
|---|---|---|
| 匹配 | Entrypoint在本机CHECK角色查询哈希链元数据，路由前得出命中长度 | 这是不能被后续前向隐藏的前置步骤 |
| 取KV | 独立进程从3FS异步搬到主机共享内存 | 复用旧Global仍可能发生存储与网络读取 |
| 换入 | engine线程把共享内存中的KV搬入HBM，目标是逐层H2D与前向重叠；使用GDR/RDMA改善细粒度传输 | 重放跨度固定不代表旧历史加载零成本；重叠效果需在具体负载下验证 |

文章将后两段按异步重叠设计描述，不能据此承诺任意负载都完全隐藏I/O。Block由Decode实例落盘，使Prefill与Decode产出的前缀都能复用；独立存储集群也让任意Prefill实例可命中任意前缀，避免为缓存亲和牺牲负载均衡。[^ZH02][^ZH05]

【官方部署文章】Prefill调度用拟合的`cost(q,c)`预算，其中q是本次待算token量、c是已计算前缀长度，并按时间预算反解chunk大小。[^ZH05]【工程建议】评估Replay时应把额外回放的工作与普通未命中后缀分别记账；相同数量的新token，在不同历史长度下并不一定有相同时延。文章的代价模型是整体调度背景，不是论文公开了某个Replay专用成本公式。

## 9. 落地评估建议

第9.1—9.5节为工程建议；第9.6节补充官方已有的验证入口及其覆盖范围。

### 9.1 对照组

A：保留完整所需状态；B：丢失SWA后精确恢复；C：128-token有界恢复；D：可选2W、4W，检查成本—质量曲线。固定权重、量化、输入及解码参数，分别测试Encoder-only、Decoder-only、二者同时启用。

### 9.2 必测边界

- 新后缀长度1、W−1、W、W+1，以及总提示词短于W。
- 两类状态都命中、Global命中而SWA缺失、两者都缺失。
- 同一输入变化命中点，多次间断恢复、TTL到期、淘汰。
- 恢复边界附近的变量定义、实体指代、结构化输出和工具参数。
- 长距离检索与局部细节依赖同时出现。
- 多模态输入位于重放边界附近时的表示和位置处理。

### 9.3 指标

| 层面 | 指标 | 目的 |
|---|---|---|
| 质量 | 成功率、精确匹配、工具成功率、检索表现 | 平均质量与关键任务是否退化 |
| 恢复偏差 | 固定后续token序列上的logits/logp、KV差异、首批token差异 | 控制比较条件，定位截断影响，不以跨边界逐位一致为预期 |
| 时延 | TTFT、恢复时间、P50/P95/P99 | 区分整体延迟与miss尾延迟 |
| 计算 | replay token数、GPU时间、吞吐 | 区分序列跨度与实际速度 |
| 存储 | 持久化容量、短期池占用、TTL周转 | 不遗漏转移到短期池的成本 |
| 负载 | 两类缓存命中率、轮次长度、恢复频率 | 判断论文收益是否适合自身业务 |

【推导】以全部待评估请求为分母，实际触发Encoder SWA miss恢复的概率为p时，每请求平均额外Encoder replay token数约pW。它不是完整计算成本；全短前缀、边界对齐等还需按实现修正。p必须对应同一统计分母，不能直接由知乎的“SWA命中率超过98%”替代，也不包括每次Prefill的Decoder Replay。

### 9.4 只改推理、不做后训练适配时的验证

【工程建议】将验证分成两件事：先确认程序忠实执行了既定重放机制，再评估目标模型能否承受该近似。只通过其中一件，不能宣称完整复现了论文效果。

| 维度 | 建议比较 | 需要记录的条件 |
|---|---|---|
| 缓存路径 | 冷请求、保留完整状态的命中、精确恢复、有界恢复 | Global命中长度、SWA快照状态、重放起点、处理层组 |
| 边界敏感性 | 相同提示词在不同命中点恢复；后缀长度覆盖1、W−1、W、W+1 | 输入token序列及位置保持一致，区分重放状态和新增状态 |
| 参数与精度 | 按目标模型自己的W和精度配置比较；条件允许时再研究重放长度 | 不把窗口、量化或权重变化与Replay开关同时混在一起 |
| 训练条件 | 明确有无相应重放适配；若可获得可比权重，再比较适配效果 | 不能把实现缺陷归因于没训练，也不能默认换模型仍质量无损 |

在相同后续token序列上比较logp/logits，有助于在生成轨迹分叉前定位差异；实际任务成功率和边界场景仍须另测。验收阈值应根据业务目标制定，论文没有提供通用阈值。没有CED结构的模型，也不能直接引用Decoder Prefill接近减半的结论。[^SWA13][^SWA16][^SWA17]

### 9.5 区分允许的近似与缓存实现错误

【工程建议】遇到同一提示词多次恢复结果不同，或出现明显乱码时，按以下顺序排查：

1. **固定比较条件。** 记录权重、精度、token输入、采样配置、Global命中边界、SWA状态、批处理及后端设置；温度0不等于缓存路径和底层算子必然完全相同。
2. **先查状态与内存访问。** 对照局部mask下界、位置编号、块表、有效长度、SWA目标slot、旧Global是否被覆盖及Decoder输入是否齐备；不可用清零缓存代替正确的可见性和分配规则。
3. **用受控组定位。** 在同一有效命中边界比较完整快照、精确恢复、有界恢复；再单独改变命中位置。前者帮助查实现，后者研究近似敏感性，不能混为一组结论。
4. **最后评价质量与复现范围。** 统计同条件重复性、固定序列logp差异、任务成功率及延迟；保存commit、patch和缓存轨迹。跨命中边界KV不同是允许的机制行为，但明显乱码也不能仅用“本来就是近似”解释过去。

原技术报告明确承认新后缀状态依赖命中位置，也明确保留未测边界风险；两者都不能替代对具体平台失败原因的取证。[^SWA07][^SWA17]

### 9.6 官方验证入口：实现等价与近似质量分开测

【官方部署文档】仓库`examples/yoco`提供两层验证：L1比较SWA可见键、写入槽和压缩键范围，无需加载模型权重；L2在兼容V4.1权重上，沿固定teacher-forcing轨迹逐项比较logprob与top-K。对照时除截断模式外，其余相关环境配置须一致。[^DEP05]

这两项主要回答**mask与compact是否实现了相同的截断计算**，不能替代“截断与完整历史前向相比，任务质量是否可接受”的评估。本次只阅读脚本和文档，未运行它们。

【工程建议】在已有第9.2节边界用例上，再加入128对齐前后、环形缓冲回绕、投机回退、140保留量、分块占位行、跨机器SWA命中及P→D状态传输。记录H与F两个进度，避免将缓存缺失的恢复次数与物理计算量混为一个指标。

## 10. 常见追问与答法

**Q1：模型上下文是不是只有128？**

不是。128是局部重建跨度，全局历史仍由Global提供。

**Q2：缓存都命中了，为何还要算？**

可能只命中Global；继续逐层计算还需当前边界的局部SWA状态。

**Q3：能否从Global直接还原SWA？**

两者生成方式不同。每层SWA来自该层隐状态，论文没有给出从Global精确反演所有局部状态的方法。

**Q4：SWA是否彻底不缓存？**

没有。Encoder有短期DRAM池，当前Decode也需局部状态；移除的是长期持久化责任。Decoder SWA不用于前缀缓存。

**Q5：八倍压缩全靠Replay吗？**

不是。移出长期SWA的约1/2因素，与Global降至约1/4的因素相乘。

**Q6：2,560→128等于快20倍吗？**

不是。这是重放序列跨度，实际时间还取决于层计算、访存、通信和完整请求路径。

**Q7：这是无损优化吗？**

不是数学无损。两类重建都近似；Encoder后缀两类KV还随命中边界变化。质量影响可忽略是有限评估下的经验结论。

**Q8：后训练模拟有什么作用？**

适应部署时的近似恢复。没有公开专门损失或模拟比例，不应自行补造。

**Q9：普通Decoder-only模型可直接Prefill减半吗？**

不能直接照搬。这里依赖CED让Decoder Global由Encoder最终表示生成；其他架构需要重新分析依赖。

**Q10：论文强调什么风险？**

未覆盖的极端输入和部署条件仍可能退化。作者未来重点之一是缓存恢复边界上的SWA状态重建。

**Q11：15个Prefill kernel、11个Decode kernel属于Replay收益吗？**

不是。这是§3.2对CSA2 Reuse层整体内核融合的描述。EPD解耦、通信计算重叠等也是周边部署背景，不能当作Replay的独立实验结果。[^SWA18]

**Q12：官方代码保留140，为什么论文一直讲128？**

128是模型局部窗口，140是部署推荐的Decoder尾部保留量，还需容纳回退余量；134又是Q&A中状态环与命中余量的口径。三者不能混作同一个窗口参数，见第8.8节。

**Q13：既然有mask，为什么还要compact？**

mask规定注意力可见范围；compact进一步删去无需计算的query行，才能减少对应的后半网络工作。两种模式的截断语义可对照验证，不能把它们的计算量视作相同。

## 11. 可直接口述的开场与收尾

### 约1分钟开场

今天汇报的SWA Bounded Replay，解决的是长上下文模型里一个容易忽略的问题：历史内容虽然已有全局KV，但从某个边界继续计算，还需要每一层的局部窗口状态。长期保存这些状态会消耗大量存储；完全精确地重建，又要沿跨层依赖回算很长一段。DeepSeek的做法是接受近似，只重放最近128个token。Encoder侧用它恢复缺失的短期状态，Decoder侧用它减少Prefill的后半网络计算。今天重点讲这两条路径，以及为什么论文中的八倍持久化压缩是组合收益。

### 约45秒收尾

这项工作的启发，是按状态的复用寿命与恢复成本决定如何保存它。长期有价值的Global继续保留，局部SWA放在短期内存中，缺失后用一个窗口恢复。它同时服务于存储优化和CED的Prefill计算优化。论文给出了有吸引力的系统结果，但接受近似、缺少专项详细消融，是落地评估时需要保留的判断边界。

## 12. 建议的12页汇报顺序

| 页 | 标题 | 重点 | 时间 |
|---|---|---|---|
| 1 | 一个窗口，两条收益 | Encoder省长期存储，Decoder省Prefill | 1分钟 |
| 2 | 两类KV、两种生命周期 | Global/SWA、HBM/持久化 | 1.5分钟 |
| 3 | 小窗口为何恢复很贵 | 跨层依赖、理论与有效感受野 | 2分钟 |
| 4 | 截断并重放 | mask公式与W=4示例 | 2分钟 |
| 5 | Encoder：命中与缺失并存 | 前缀尾窗＋后缀；旧Global不覆盖 | 2分钟 |
| 6 | 长期与短期存储分工 | 10% DRAM、分钟TTL、Global至少72小时 | 1.5分钟 |
| 7 | CED剩余障碍 | Global可投影，SWA须逐层生成 | 2分钟 |
| 8 | Decoder尾窗重放 | 20层、128 token、不用于前缀缓存 | 1.5分钟 |
| 9 | 收益归因 | 1/8分解与Prefill接近减半的条件 | 2分钟 |
| 10 | 质量证据与边界 | 近似、后训练适配、无专项精确分数 | 1.5分钟 |
| 11 | 如何验证可用性 | 边界、短后缀、重复恢复、TTFT | 1.5分钟 |
| 12 | 结论与答疑 | 按寿命和恢复成本设计缓存 | 1分钟 |

合计约19.5分钟，不含答疑。压缩到10分钟可合并2/6、3/4、7/8，伪代码及详细验证作为附录。

## 13. 原文覆盖清单

| 原文位置 | 相关内容 | 本稿章节 |
|---|---|---|
| 摘要，[第1页](https://arxiv.org/pdf/2609.19969v1#page=1) | 持久化约1/8、Global 890 bytes/token | 1、7 |
| §1，[第4–5页](https://arxiv.org/pdf/2609.19969v1#page=4) | 两类状态与缓存、精确LW、有界W、组合优化 | 2、3、7 |
| §1，[第5–6页](https://arxiv.org/pdf/2609.19969v1#page=5) | 两条Replay路径与长短期状态分离 | 4、5、6 |
| §2.1与图3，[第7页](https://arxiv.org/pdf/2609.19969v1#page=7) | 40层、20+20、前两层纯SWA | 1、2、6 |
| §2.2，[第9页](https://arxiv.org/pdf/2609.19969v1#page=9) | CED公式、逐层依赖、有效感受野、Prefill工作量 | 3、6、7 |
| §2.3.1与图4，[第10–11页](https://arxiv.org/pdf/2609.19969v1#page=10) | 每层保留SWA，CED Full层生成Global | 2、6 |
| §2.4.4，[第14页](https://arxiv.org/pdf/2609.19969v1#page=14) | SWA保留FP8，与FP4 main KV区别 | 2、7 |
| §3.2，[第18–19页](https://arxiv.org/pdf/2609.19969v1#page=18) | 内核融合与EPD是周边背景 | 10的Q11 |
| §3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19) | 旧LRU、双端点、超过72小时、近半容量、Zero SWA Caching | 5 |
| §3.2.1，[第19页](https://arxiv.org/pdf/2609.19969v1#page=19) | 10% DRAM、分钟TTL、Global至少72小时、miss兜底 | 4、5 |
| §3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20) | mask、Encoder、旧Global不覆盖、后缀随命中点变化 | 3、4、8 |
| §3.2.2，[第20页](https://arxiv.org/pdf/2609.19969v1#page=20) | Decoder每次Prefill、只供Decode、后训练模拟 | 6、8 |
| §4.2.1，[第21–22页](https://arxiv.org/pdf/2609.19969v1#page=21) | 窗口128、20+20层配置 | 1、6、7 |
| §6，[第37页](https://arxiv.org/pdf/2609.19969v1#page=37) | 整体收益、内部评估范围、未测边界、恢复边界压力测试 | 7.5—7.6、9.4—9.5、10 |

§5.1.1的失败轨迹replay与§5.2的专家路由replay不是SWA Bounded Replay。第14页§2.4.3的DSpark草稿网络也有128-token滑窗，但它属于草稿模型的注意力配置，不是主干SWA恢复路径。实际部署中，投机回退又会影响主干SWA环的额外容量；知乎同时披露了draft一次生成5个token及SWA额外6个位置，见第8.8节。知乎DSpark变长验证的6%吞吐提升属于另一项优化，不能归给Replay。[^ZH06]整体benchmark不能当成本技术的单项消融。

## 14. 原始资料与核对说明

主依据：[DeepSeek-V4.1-Flash原始论文](https://arxiv.org/pdf/2609.19969v1)。核心证据第9、19、20、22、37页，其中第19、20页同时核对PDF视觉页面和提取文字。

动机参考：[PowerAttention](https://arxiv.org/abs/2503.03588)，Chen et al. (2025)。这里只说明原文引用关系，不把它自身的速度或质量数字转嫁给Bounded Replay。

论文覆盖范围是指定v1报告中直接相关、或解释机制必需的内容。后续部署补充已阅读DeepInfer的相关文档及部分源码，属于静态核对；没有运行推理、复现质量或性能结果。第8.2节仍为教学伪代码，未升级为可运行的生产实现。

### 本次补充的来源与取舍

借鉴文档：[SWA Bounded Replay 论文讲解-claude-code.md](<SWA Bounded Replay 论文讲解-claude-code.md>)。该文档的论文解释、工程建议和实操记录分别处理：

| 有价值的内容 | 本稿落点 | 处理原则 |
|---|---|---|
| 局部处理主干＋压缩Global增强的理解框架 | 第2节 | 按第4页原文核对后补入 |
| 保存与恢复的成本对照 | 第5.3节 | 整理为三种策略对照，避免把某种方案说成普遍不可用 |
| 请求分流、调度、mask、写入及精度接口 | 第8.1—8.4节 | 以论文机制为约束，明确标为工程组织建议 |
| 隐状态保存、平台版本与实现成败的判断 | 第8.5—8.6节 | 区分论文输入条件与额外平台方案；未核验记录不提升为论文结论 |
| 论文自述局限及不重训时的验证 | 第7.6、9.4—9.5节 | 补全内部评估范围、未测风险、后续压力测试，并给受控验证建议 |
| OmniInfer候选类名、配置与排查线索 | 第8.6节 | 保留审查入口，实际语义和版本待代码/日志核验 |

### 后续官方部署资料：此次补充依据与访问边界

已读取用户指定的[DeepSeek官方知乎文章](https://zhuanlan.zhihu.com/p/2095560295930508953)及其[本地MHTML存档](<DeepSeek V4.1 Flash 大规模推理部署实践 - 知乎.mhtml>)。存档页面作者为DeepSeek，页面标示编辑于2026-10-20 19:30；MHTML保存于2026-11-03 15:18:34（北京时间）。本次已逐段核对“SWA Bounded Replay”“KVCache Storage”及各子节，并查看系统结构、线上数据与两张离线性能图；相关调度和投机解码内容仅按与SWA恢复的联系纳入。

另一组依据为[官方部署Q&A](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md)、[README](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md)及第8.9节源码，仍固定到提交`553741557a57df44a46fb3ab72b6aafeaf945337`。文章、Q&A、源码不是同一份材料：StateBlock字段和mask/compact细节来自后两者；180秒、98%以上以及本文引用的性能原图已从知乎存档直接核对。

对照结果与逐段落点见[官方部署资料核对](SWA_Bounded_Replay_官方部署资料核对.md)。本轮进一步补全V4缺失恢复路径、SWA池线上数据、Global的4层分页布局、命中后的三段数据路径，并澄清“常数代价”“Prefill仅在Encoder”的适用口径。知乎的原文与原图使用ZH编号，后续仓库资料使用DEP编号，论文仍使用SWA编号。

整集群吞吐、收入、平均输入缓存命中率以及DSpark收益不作为Replay单项效果。本地快照中个别文内参考序号与文末列表存在错位，因此按标题、段落与直接链接定位，未机械复制原文的引用编号。

## 15. 原文证据与逐条溯源

SWA系列证据使用固定版本arXiv:2609.19969v1，DEP系列使用固定版本DeepInfer官方资料，ZH系列使用用户提供的知乎MHTML快照。既有英文短引已与PDF逐字核对；完整语境通过页码或源码行链接查看。编号脚注可从正文跳到证据条目。

**本地阅读：**[打开随报告保存的论文PDF](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf)。Markdown与references文件夹保持同级即可保留相对链接。在线链接使用PDF的page定位参数；若阅读器未自动跳页，按链接文字的页码手动定位。

**段落编号：**Encoder/Decoder各自从该粗体小节标题同一段起算，不包括上一小节；§3.2.1的正文从标题下第1段起算，编号列表单独标明。

| 证据编号 | 对应论点 | 精确位置 | 快速定位 |
|---|---|---|---|
| SWA01 | 模型结构与窗口 | §2.1首段；§4.2.1的模型配置段 | [第7页](https://arxiv.org/pdf/2609.19969v1#page=7) |
| SWA02 | Global与SWA的职责、运行/持久化区别 | §1第2段；图4图注与§2.3.1首段 | [第4页](https://arxiv.org/pdf/2609.19969v1#page=4) |
| SWA03 | SWA继续使用FP8 | §2.4.4最后一段 | [第14页](https://arxiv.org/pdf/2609.19969v1#page=14) |
| SWA04 | 跨层精确恢复与截断公式 | §3.2.2开头第1段及未编号公式 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA05 | 有效感受野动机 | §2.2第3段，讨论SWA依赖与相关工作的位置 | [第9页](https://arxiv.org/pdf/2609.19969v1#page=9) |
| SWA06 | Encoder触发条件、重放区与旧Global只读 | §3.2.2，Encoder小节第2段 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA07 | 新后缀两类KV依赖命中边界 | §3.2.2，Encoder小节第3段 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA08 | V4缓存策略与SWA快照生命周期 | §3.2.1第2、3段 | [第19页](https://arxiv.org/pdf/2609.19969v1#page=19) |
| SWA09 | 10%主机DRAM、分钟TTL、Global长期保证 | §3.2.1编号条目1 | [第19页](https://arxiv.org/pdf/2609.19969v1#page=19) |
| SWA10 | Zero SWA Caching与缺失兜底 | §3.2.1第3段及编号条目2 | [第19页](https://arxiv.org/pdf/2609.19969v1#page=19) |
| SWA11 | CED投影与CSA2复用的关系 | §2.2第2段、式(1)；§2.3.1末段 | [第9页](https://arxiv.org/pdf/2609.19969v1#page=9) |
| SWA12 | Decoder局部恢复及不用于前缀缓存 | §3.2.2，Decoder小节第2段 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA13 | 数学非等价、质量判断及后训练适配 | §3.2.2，Decoder小节第3段；另见Encoder第3段 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA14 | 持久化约1/8的两个乘法因素 | §3.2.1第1段 | [第19页](https://arxiv.org/pdf/2609.19969v1#page=19) |
| SWA15 | Global KV为890 bytes/token与约1/4 | 摘要；§6第1段 | [第1页](https://arxiv.org/pdf/2609.19969v1#page=1) |
| SWA16 | 长输入下Prefill工作量接近减半 | §2.2最后一段，紧邻§2.3标题之前 | [第9页](https://arxiv.org/pdf/2609.19969v1#page=9) |
| SWA17 | 未覆盖边界与后续压力测试 | §6第2段 | [第37页](https://arxiv.org/pdf/2609.19969v1#page=37) |
| SWA18 | 15/11个kernel及EPD属于周边部署优化 | §3.2在第19页开头的续文，位于§3.2.1之前 | [第19页](https://arxiv.org/pdf/2609.19969v1#page=19) |
| SWA19 | “未找到专项结果”的证据等级 | 报告作者的文献核查记录；先对照§3.2.2与§6 | [第20页](https://arxiv.org/pdf/2609.19969v1#page=20) |
| SWA20 | 局部处理主干与Global增强的架构视角 | §1第4段，第4页，跨页段落的开头部分 | [第4页](https://arxiv.org/pdf/2609.19969v1#page=4) |

### 后续官方部署证据

| 证据编号 | 对应内容 | 固定版本定位 |
|---|---|---|
| DEP01 | Block/state区分、保存边界、跨机SWA、命中回退 | [Q&A：KV cache storage及其子节](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L129-L191) |
| DEP02 | StateBlock布局、528 B格式、运行与保存范围 | [cache_engine.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/cache_engine.py#L210-L306) |
| DEP03 | 140推荐值、off默认、回退量下限 | [README](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md#L25)、[环境定义](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/environ.py#L194-L201)、[运行约束](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/model_runner.py#L101-L113) |
| DEP04 | mask/compact可见域与实际计算布局 | [C++元数据](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/csrc/engine/input_metadata/prepare_tensor_input_v4.cpp#L129-L280)、[边界表示处理](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/models/v4_modules/yoco.py#L93-L123) |
| DEP05 | 元数据与固定轨迹等价性验证 | [官方examples/yoco说明](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/examples/yoco/README.md) |
| DEP06 | Q&A与知乎的关系、开源范围 | [Q&A引言](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L17-L21)、[README服务配套说明](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md#L38-L42) |

### 知乎原文与配图证据

| 编号 | 对应内容 | 在线标题定位 | 本地摘录／原图 |
|---|---|---|---|
| ZH01 | SWA池TTL约180秒、命中率超过98%、保存时机 | [SWA KVCache](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_15) | [原文](SWA_Bounded_Replay_官方部署资料核对.md#zh-01) |
| ZH02 | Block 4层布局、长期存储与SWA存储的区别 | [KVCache Storage](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_13) | [对照](SWA_Bounded_Replay_官方部署资料核对.md#zh-02) |
| ZH03 | V4精确恢复、截断公式、两条重放路径与命中回退 | [SWA Bounded Replay](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_18)／[命中策略](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_16) | [逐段原文](SWA_Bounded_Replay_官方部署资料核对.md#zh-03) |
| ZH04 | 线上96%及吞吐/时延，离线Prefill的140-token配置 | [线上统计](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_1)／[离线基准](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_2) | [原图](SWA_Bounded_Replay_官方部署资料核对.md#zh-04) |
| ZH05 | 匹配、取KV、换入三段与cost(q,c)调度 | [Block KVCache](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_14)／[Prefill Load Balancer](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_8) | [原文与边界](SWA_Bounded_Replay_官方部署资料核对.md#zh-05) |
| ZH06 | 生产draft长度及未完整开源的服务组件 | [DSpark](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_19)及引言 | [范围说明](SWA_Bounded_Replay_官方部署资料核对.md#zh-06) |

在线锚点若未定位，按表内标题在[本地存档](<DeepSeek V4.1 Flash 大规模推理部署实践 - 知乎.mhtml>)中搜索；本地摘录保留对应段落ID，便于与保存页面核对。

### 证据脚注

[^SWA01]: **模型结构与窗口**。位置：§2.1首段；§4.2.1的模型配置段，第7页。层数见第7页；窗口数值见第22页。 [在线第7页](https://arxiv.org/pdf/2609.19969v1#page=7) · [本地第7页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=7)。 补充：[在线第22页](https://arxiv.org/pdf/2609.19969v1#page=22) · [本地第22页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=22)。

[^SWA02]: **Global与SWA的职责、运行/持久化区别**。位置：§1第2段；图4图注与§2.3.1首段，第4页。各层保留局部状态的说明见第10页。 [在线第4页](https://arxiv.org/pdf/2609.19969v1#page=4) · [本地第4页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4)。 补充：[在线第10页](https://arxiv.org/pdf/2609.19969v1#page=10) · [本地第10页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=10)。

[^SWA03]: **SWA继续使用FP8**。位置：§2.4.4最后一段，第14页。定位到该节末段关于局部缓存量化的说明。 [在线第14页](https://arxiv.org/pdf/2609.19969v1#page=14) · [本地第14页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=14)。

[^SWA04]: **跨层精确恢复与截断公式**。位置：§3.2.2开头第1段及未编号公式，第20页。恢复跨度与局部可见范围在同一段。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。

[^SWA05]: **有效感受野动机**。位置：§2.2第3段，讨论SWA依赖与相关工作的位置，第9页。此处是本文对既有工作的引用，不是误差上界证明。 [在线第9页](https://arxiv.org/pdf/2609.19969v1#page=9) · [本地第9页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)。

[^SWA06]: **Encoder触发条件、重放区与旧Global只读**。位置：§3.2.2，Encoder小节第2段，第20页。对照旧前缀重放与未缓存后缀的不同处理。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。

[^SWA07]: **新后缀两类KV依赖命中边界**。位置：§3.2.2，Encoder小节第3段，第20页。该段讨论近似状态及命中位置依赖。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。

[^SWA08]: **V4缓存策略与SWA快照生命周期**。位置：§3.2.1第2、3段，第19页。LRU、双端点快照、长期留存及短期复用在这两段。 [在线第19页](https://arxiv.org/pdf/2609.19969v1#page=19) · [本地第19页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)。

[^SWA09]: **10%主机DRAM、分钟TTL、Global长期保证**。位置：§3.2.1编号条目1，第19页。两项比例/时间短引均在此条目。 [在线第19页](https://arxiv.org/pdf/2609.19969v1#page=19) · [本地第19页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)。

[^SWA10]: **Zero SWA Caching与缺失兜底**。位置：§3.2.1第3段及编号条目2，第19页。前者解释旧方案成本，后者解释有界恢复兜底。 [在线第19页](https://arxiv.org/pdf/2609.19969v1#page=19) · [本地第19页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)。

[^SWA11]: **CED投影与CSA2复用的关系**。位置：§2.2第2段、式(1)；§2.3.1末段，第9页。投影公式见第9页；结合CSA2的说明见第11页。 [在线第9页](https://arxiv.org/pdf/2609.19969v1#page=9) · [本地第9页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)。 补充：[在线第11页](https://arxiv.org/pdf/2609.19969v1#page=11) · [本地第11页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=11)。

[^SWA12]: **Decoder局部恢复及不用于前缀缓存**。位置：§3.2.2，Decoder小节第2段，第20页。精确恢复长度、每次Prefill尾窗与用途限制同段。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。

[^SWA13]: **数学非等价、质量判断及后训练适配**。位置：§3.2.2，Decoder小节第3段；另见Encoder第3段，第20页。短引只对应关键限定词，具体语境请读整段。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。

[^SWA14]: **持久化约1/8的两个乘法因素**。位置：§3.2.1第1段，第19页。100→50→12.5是本文将该关系归一化后的教学算例。 [在线第19页](https://arxiv.org/pdf/2609.19969v1#page=19) · [本地第19页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)。

[^SWA15]: **Global KV为890 bytes/token与约1/4**。位置：摘要；§6第1段，第1页。整体Global压缩指标，不能单独归功于Replay。 [在线第1页](https://arxiv.org/pdf/2609.19969v1#page=1) · [本地第1页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=1)。 补充：[在线第37页](https://arxiv.org/pdf/2609.19969v1#page=37) · [本地第37页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)。

[^SWA16]: **长输入下Prefill工作量接近减半**。位置：§2.2最后一段，紧邻§2.3标题之前，第9页。该段给出N远大于窗口长度的条件和复杂度表达。 [在线第9页](https://arxiv.org/pdf/2609.19969v1#page=9) · [本地第9页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=9)。

[^SWA17]: **未覆盖边界与后续压力测试**。位置：§6第2段，第37页。重点查缓存恢复边界相关的局限讨论。 [在线第37页](https://arxiv.org/pdf/2609.19969v1#page=37) · [本地第37页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)。

[^SWA18]: **15/11个kernel及EPD属于周边部署优化**。位置：§3.2在第19页开头的续文，位于§3.2.1之前，第19页。该处不是Replay单项消融。 [在线第19页](https://arxiv.org/pdf/2609.19969v1#page=19) · [本地第19页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=19)。

[^SWA19]: **“未找到专项结果”的证据等级**。位置：报告作者的文献核查记录；先对照§3.2.2与§6，第20页。这不是论文自称“没有消融”的原句，不应以英文引号包装；如需复核披露完整性，应检索整篇报告。 [在线第20页](https://arxiv.org/pdf/2609.19969v1#page=20) · [本地第20页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=20)。 补充：[在线第37页](https://arxiv.org/pdf/2609.19969v1#page=37) · [本地第37页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=37)。


[^SWA20]: **局部处理主干与Global增强的架构视角**。位置：§1第4段开头，第4页。作者以SWA局部主干加压缩全局上下文的视角解释架构取向：主要简化Global分支、基本保留局部注意力设计。 [在线第4页](https://arxiv.org/pdf/2609.19969v1#page=4) · [本地第4页](references/DeepSeek_V4_1_Flash_2609_19969v1.pdf#page=4)。关于量化敏感性另见SWA03，两项证据不相互替代。


[^DEP01]: **官方部署：缓存组织、保存与命中**。DeepInfer提交`553741557a57`，Q&A的“KV cache storage”“SWA KV cache”“KV cache hits and recomputation”。[存储与生命周期](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L129-L157) · [状态快照与传输](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L159-L177) · [重放与命中规则](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L179-L191)。这是后续官方说明，不标为论文v1原句。

[^DEP02]: **官方源码：StateBlock及容量**。[cache_engine.py](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/cache_engine.py#L210-L306)说明528 B格式、stored/dropped区域及保存字节数；[SWA环大小](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/cache_engine.py#L89-L110)和[保存/传输处理](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/cache_engine.py#L763-L818)补充布局边界。变量名称不替代Q&A对实际存储介质的说明。

[^DEP03]: **官方配置：窗口、回退与尾部保留**。[README推荐值](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md#L25)；[投机/回退定义](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/environ.py#L136-L139)；[模式默认与KEEP说明](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/environ.py#L194-L201)；[长度约束断言](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/model_runner.py#L101-L113)。Q&A的134与README的140分属不同口径，未见对额外差值逐项拆分的说明。

[^DEP04]: **官方源码：截断语义与计算压缩**。[yoco_swa_visibility及保留行构造](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/csrc/engine/input_metadata/prepare_tensor_input_v4.cpp#L129-L280)；[consumer元数据视图](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/input_metadata/yoco.py#L86-L121)；[compact_yoco_boundary](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/models/v4_modules/yoco.py#L93-L123)。静态阅读确认两模式的元数据组织，本次未执行数值验证。

[^DEP05]: **官方验证入口与范围**。[examples/yoco/README.md](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/examples/yoco/README.md#L1-L41)描述L1元数据对照和L2固定轨迹logp/top-K比较。该验证聚焦mask/compact一致性，不自动证明有界重放与完整前向等价。

[^DEP06]: **官方资料身份与开源边界**。[Q&A引言](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L17-L21)明确关联用户指定知乎文章，并说明缓存管理与负载均衡尚未完整开源；[README](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md#L38-L42)列出完整服务所需配套。知乎原文现已通过用户提供的MHTML完成相关部分逐段核对，见ZH系列证据。


[^ZH01]: **知乎原文：SWA短期池与保存边界**。“SWA KVCache”第1、2段，段落ID `6Ry6ijGr`、`jRHWXil1`。第1段直接报告TTL约180秒、命中率98%以上；统计分母与采样窗口未在该段详述。[在线](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_15) · [本地逐段摘录](SWA_Bounded_Replay_官方部署资料核对.md#zh-01)。

[^ZH02]: **知乎原文：Block/state布局与长期存储**。“KVCache Storage”引导段和表格、随后“Block KVCache”各段；引导段ID `TMYJDAFK`。包括128-token Block、4层main KV/indexer K及前20层134位置SWA ring。[在线](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_13) · [本地对照](SWA_Bounded_Replay_官方部署资料核对.md#zh-02)。

[^ZH03]: **知乎原文：机制与命中规则**。“SWA Bounded Replay”第1、2段及Encoder/Decoder两个条目，ID `nGU21zEo`、`huDcmftR`、`uh38Ot4O`、`MLdouh-X`；“命中策略”段ID `XRK3Rj41`。与论文机制交叉核对，原文的概括性表述在正文标明解释范围。[在线机制](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_18) · [本地原文](SWA_Bounded_Replay_官方部署资料核对.md#zh-03)。

[^ZH04]: **知乎原图：线上运行数据及离线Prefill**。“推理系统设计概览”下两组配图；已直接查看MHTML内图片。Prefill离线图明确写Decoder Bounded Replay 140 tokens；线上图的96%是平均输入缓存命中率。[在线](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_2) · [本地原图及指标解读](SWA_Bounded_Replay_官方部署资料核对.md#zh-04)。图中不是Replay单项消融。

[^ZH05]: **知乎原文：缓存I/O与调度成本**。“Block KVCache”第3段（`LXMIoa0U`）及“Prefill Load Balancer”两段（`48kvBZJl`、`FYbS4BEp`）。分别解释匹配/取KV/换入和依赖待算长度及历史长度的调度模型。[在线](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_14) · [本地摘录](SWA_Bounded_Replay_官方部署资料核对.md#zh-05)。

[^ZH06]: **知乎原文：相邻优化与开源范围**。引言段`hEUZmXCx`说明缓存管理和负载均衡未完整开源；“DSpark投机解码”段`S8YrSaLK`给出一次生成5个draft token及变长验证6%吞吐收益，后者不归因于Replay。[在线DSpark](https://zhuanlan.zhihu.com/p/2095560295930508953#h_2095560295930508953_19) · [本地范围说明](SWA_Bounded_Replay_官方部署资料核对.md#zh-06)。
