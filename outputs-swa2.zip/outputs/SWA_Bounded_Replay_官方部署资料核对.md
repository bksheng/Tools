# SWA Bounded Replay：官方部署资料逐段核对记录

核对日期：2026-11-03。已更新[原技术汇报](SWA_Bounded_Replay_技术汇报.md)。

## 核对结果

已读取用户提供的[知乎MHTML存档](<DeepSeek V4.1 Flash 大规模推理部署实践 - 知乎.mhtml>)，并完成SWA Bounded Replay、KVCache Storage各子节及相关图表核对。**核心算法没有发现新的缺项；新增价值主要是线上SWA池数据、生产存储与I/O细节，以及原图中明确的140-token部署配置。**

页面作者：DeepSeek；标题：[DeepSeek V4.1 Flash 大规模推理部署实践](https://zhuanlan.zhihu.com/p/2095560295930508953)；页面显示编辑于2026-10-20 19:30；存档保存于2026-11-03 15:18:34（北京时间）。此前在线抓取受限的问题已由本地存档解决。此文不是官方Q&A的逐字副本，二者分别引用。

仍保留上一轮对[官方Q&A](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md)、[README](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md)与相关源码的核对，固定提交`553741557a57df44a46fb3ab72b6aafeaf945337`。没有运行模型或复现实验。

## 按知乎文章顺序的覆盖清单

| 原文位置 | 核对内容 | 原技术汇报落点及处理 |
|---|---|---|
| 引言与推理系统设计概览 | 长期缓存目标；服务组件未完整开源；整体系统图 | 第5、8.9、14节；作为部署背景，不冒充Replay单项设计 |
| 线上统计图 | 平均输入缓存命中96%；Prefill吞吐与TTFT | 新增第7.7节，区分SWA状态命中和整体输入复用 |
| 离线性能图 | Prefill明确使用140-token Decoder Replay；点标签为每DP rank的batch token数 | 第7.7节附原图；第8.8节新增直接依据；Decode图属于整体基准，不作Replay消融 |
| Prefill Load Balancer两段 | cost(q,c)、非固定chunk和时间预算 | 新增第8.10节；强调回放与新后缀的工作需分别记账 |
| KVCache Storage引导段及表格 | 128-token Block；4层main KV/indexer K；前20层134位置SWA ring；三类存储介质 | 第5.4节补4层布局；其余与上一轮Q&A补充一致 |
| Block KVCache第1段 | 独立存储、任意前缀命中、与路由及计算扩缩容解耦 | 第5.5、8.10节；强调复用和负载均衡的配合 |
| Block KVCache第2段 | 3/7天TTL、容量与带宽指标 | TTL已覆盖；容量/带宽保留在本记录的周边背景，不作为Replay收益 |
| Block KVCache第3段 | Decode落盘；匹配、异步取KV、逐层换入；GDR/RDMA | 新增第8.10节；旧Global复用仍有读取成本 |
| SWA KVCache第1段 | 分布式目录、跨机拉取、TTL约180秒、命中率超过98%、miss兜底 | 第5.2、7.7节补线上数据；统计分母不擅自扩展 |
| SWA KVCache第2段 | 128对齐保存、Prefill末chunk、Decode副本、最多越界5个token与6位置余量 | 第5.5、8.8节已有，现由知乎原文再确认 |
| 命中策略 | N−134上限、先查Block再查SWA、缺失回退一块 | 第8.7节已有，补知乎直接出处；保留H与F的区分 |
| 3FS三个条目 | 10+2纠删码、11读10返、LRU回收 | 属于长期Block存储可用性背景，见下文；不混入SWA算法 |
| SWA Bounded Replay第1段 | V4落盘＋缺失后精确重算、高miss成本要求低miss率、分钟与数天寿命错配 | 第5.1、5.3节补完整因果链 |
| SWA Bounded Replay第2段 | 128窗口、截断mask、近似状态、“常数代价” | 第3、7.3节；保留层计算口径澄清 |
| Encoder条目 | 尾窗＋后缀一起前向、旧Block不重算不覆盖 | 第4、8.5节已有；进一步支持对Claude版“只投影、不跑attention”的纠正 |
| Decoder条目 | CED、20层×2560跨度、只处理尾部128、仅供Decode、总Prefill近半 | 第6、7节已有；新增“完整提示词主干工作”与“Decoder尾窗工作”的表述区分 |
| DSpark相关段 | 一次draft 5个token，与回退余量相关；变长验证6%提升 | 第8.8、13节；6%明确不归给Replay |

其余API协议、Tokenizer、结构化输出、专家重排等不属于SWA Bounded Replay技术链，未扩展进主报告。

## 本次借鉴与校准的表达

1. **先降低状态丢失后的恢复成本，再缩短状态保存寿命。** 比单说“把SWA从SSD搬到内存”更能解释Replay的作用。
2. **Block决定可复用到哪里，SWA决定续算前是否回放一窗。** 保留原文命中规则，同时明确缓存有效末端与计算起点不是一个数。
3. **完整提示词主要经过Encoder，Decoder仍执行尾窗前向。** 不把官方条目开头的概括孤立读成“Decoder完全不算”。
4. **固定的是回放跨度，不是所有计算和I/O。** 将“常数代价”与层数、历史读取及实际时延分开。

## 原文摘录与图证

以下文字来自用户提供的MHTML；保留原文措辞，技术限定与解释放在引用之外。原文部分参考编号[2]/[3]与文末列表存在错位，引用中的编号按原样保留，证据定位以标题、段落ID及直接链接为准。

<a id="zh-01"></a>

### ZH01｜SWA KVCache：线上数据与保存时机

原文标题：“SWA KVCache”。

段落ID：`6Ry6ijGr`。

> SWA KV 不进持久化缓存，而是留在产生它的那台机器的内存里，由一个逻辑上统一、实际按 key 分开存放在各台 Entrypoint 上的内存目录记录在哪台机器，命中时本机没有就跨机取回。由于 SWA KV 只在会话内的分钟级窗口里被复用，池子总容量虽小但周转快，足以覆盖同时活跃的会话，线上数据显示，其TTL约 180 秒，命中率在 98% 以上。被驱逐造成的未命中由上述的 Encoder SWA Bounded Replay[3] 重算。

段落ID：`jRHWXil1`。

> SWA KVCache 只在 128 tokens 的整数倍位置上存储。Prefill 阶段结束后存储：位置取序列末尾留出一个 token 后向下对齐到 128 所得的位置，不足一个 128 tokens 则本轮不存储；chunked prefill 中途不存储，只有最后一个 chunk 才存储。Decode 阶段在显存中另开一块副本区，每跨过一个 128 tokens 边界就把该请求当前的窗口在显存内拷入副本区，请求结束时从副本区中最近一次完成拷贝的位置存储，附着点向下对齐到 128 边界，拷贝位置最多越过边界 5 个 token，由 ring 比窗口多出的 6 个位置吸收。

核对：180秒和98%以上是此前遗漏的直接线上披露；文章未在这里说明完整统计分母、采样窗口，也未给出SWA miss的精确百分比。

<a id="zh-02"></a>

### ZH02｜Block与SWA的布局、长期存储背景

原文“KVCache Storage”引导段：

段落ID：`TMYJDAFK`。

> 随着对话上下文的增长和 agent 的广泛使用，KVCache 前缀缓存复用能够极大减少 prefill 重算，从而显著降低成本。DeepSeek-V4.1-Flash 模型的 KVCache 存储分为两个部分：Block KVCache 和 State KVCache，分别存储于 3FS 集群和本机内存中。
> Block KVCache：以 128 tokens 为一个 block 进行分页式管理，根据模型架构设计，存储 4 层的 main KV 和 indexer K。
> SWA KVCache：前 20 层各一个 134 token 的 ring（窗口长度=128 + 投机回退=6），不存储压缩中间态。

“Block KVCache”第1、2段还披露独立3FS存储，约100 PiB容量；Agent缓存3天、Chatbot缓存7天；Chatbot若只保留约3天，经验上损失0.5%—1%的缓存命中率；针对约112 KiB的Block随机读写优化，峰值聚合读10 TiB/s、写约850 GiB/s。这些是整个缓存系统的配置与统计，不是SWA Replay单项压缩或提速数字。

“3FS分布式文件系统”条目说明10+2纠删码，每组可容忍2节点同时故障；读时向11节点请求、任意10个响应后返回；GC Worker按LRU周期性回收。这些机制支持长期Block的可用性，与短期SWA单副本＋缺失重放分别说明。

<a id="zh-03"></a>

### ZH03｜命中策略与SWA Bounded Replay全文相关段落

原文“命中策略”：

段落ID：`XRK3Rj41`。

> 命中的原则是：命中长度由 Block KVCache 决定，最后一个 block 是否需要重算由 SWA KVCache 决定，若 SWA KVCache 未命中，就退一块重算。具体地，根据YOCO截断要求，对于输入长度 L，最大的命中长度最多为 L - 134（窗口 128 + 投机回退 6）。在这个上限下，首先查询 Block KVCache 命中情况，假设命中长度为 L1（L1为block size=128的整数倍），再查询SWA KVCache命中情况。假如在 L1 - 128 至 L1 长度范围内，存在 SWA KVCache 则命中长度为 L1，否则命中长度为 L1 - 128，其中 128 为重算窗口。

原文“SWA Bounded Replay”第1段：

段落ID：`nGU21zEo`。

> SWA KVCache 不进行持久化存储，缺失时以重算恢复，这是 V4.1 相对 V4 在 KVCache 管理上的主要变化，具体可参考 V4.1 技术报告[2]。V4 的做法是落盘加精确重算：SWA KVCache 在两个位置写入持久化存储，未命中时重算“层数 × 窗口”个 token 做完整前向，逐层精确恢复窗口状态。这条路径代价很高，必须用足够大的 SSD 容量把未命中率压到极低，代价是 SWA KVCache 占去持久 KVCache 近一半容量，且未能带来相应的命中收益：Block KVCache 呈长尾复用，一段前缀可在数天内被反复命中；SWA KVCache 只在活跃会话内被分钟级复用，会话结束或进入下一轮即失效。以数天留存的 SSD 容量承载分钟级生命期的数据，在多轮短对话场景下尤其不划算。因此，V4 技术报告提出的 Zero SWA Caching（即完全不落盘、仅依赖精确重算）因其代价在生产部署中过高，在V4.1推理系统中未实际采用。

原文第2段：

段落ID：`huDcmftR`。

> V4.1推理系统采用 SWA Bounded Replay，只重算最近 128 个 token，并把注意力窗口截断在重算段内：从位置 s 起回放，位置 i 的 query 只和 max(s, i − 127) 到 i 区间的 key 计算，重算得到近似的 SWA KVCache。重算代价由此降为与上下文长度和层数无关的常数。该机制用在两处：

原文Encoder条目：

段落ID：`uh38Ot4O`。

> Encoder SWA Bounded Replay：前缀缓存命中长度从此只依赖 Block KVCache。SWA KVCache 缺失时，重算命中前缀的最后 128 个 token，与未命中后缀一同前向；重算段只重建 SWA KVCache，Block KVCache 原样复用、不重算不覆写。

原文Decoder条目：

段落ID：`MLdouh-X`。

> Decoder SWA Bounded Replay：prefill 计算仅在 encoder 层进行。CED 架构下 decoder 层的 Block KVCache 由 encoder 末层 hidden state 投影得到，仅 decoder SWA KVCache 需各层自算，精确重建要 20 个 decoder 层跑最后 2560 个 token；改为每次 prefill 在 decoder 层只重算 prompt 末尾 128 个 token，产出仅供 decode、不进前缀缓存，总 prefill 计算量近乎减半。

核对：截断的近似和两条路径与报告一致。“常数代价”限定为回放跨度；Decoder的开头概括须结合末尾128-token前向一起理解。原文不支持“缓存所有层hidden states后只做KV投影”是论文原生路线的判断。

<a id="zh-04"></a>

### ZH04｜线上统计与140-token Prefill原图

原文“DeepSeek-V4.1-Flash线上系统的实际统计数据”：

![知乎官方线上运行数据原图](references/zhihu_deepinfer_online_metrics.jpg)

原文“离线性能基准测试数据”第一张图：

![知乎官方Prefill基准原图：140-token Decoder Bounded Replay](references/zhihu_deepinfer_prefill_140.jpg)

两图均直接从MHTML提取，未改动。第一图的96%是平均输入缓存命中率，不能替代SWA池98%以上的命中率。第二图明确140-token保留配置，横轴每Prefill step延迟、纵轴不含缓存命中的每GPU输入吞吐、点标签每个DP rank的batch token数。图中各点按batch token数标注，没有Replay开关对照。

同节第二张Decode图已查看：它展示整体Decode吞吐与每用户速度的取舍，条件含EP64/DP64、nextn=3 fixed等；不能与正文线上draft=5混为同一实验配置，也不能解释为Decoder Replay的独立收益。本记录不重绘或复用该曲线。

<a id="zh-05"></a>

### ZH05｜命中数据路径与调度预算

原文“Block KVCache”第3段：

段落ID：`LXMIoa0U`。

> 推理框架层面，Block KVCache 由 decode 实例落盘存储，使得 prefill 和 decode 输出均被复用。对于 KVCache 命中开销，命中路径分为三段，只有第一段在关键路径上：匹配由 Entrypoint 在本机 CHECK 角色的 kvcache-store 上做哈希链前缀匹配，只查元数据，但命中长度需在路由前进行计算，无法掩盖；取 KV 在独立进程里异步做，把 KVCache 从 3FS 搬进宿主机 shm；换入从 shm 到 HBM 在 engine 进程内的线程里做，目标是实现逐层 H2D （Host-to-Device） 传输与前向计算重叠，由于 CUDA copy engine 对于 KVCache Block 细粒度的拷贝性能不佳，换入使用 GDR 实现，用 RDMA 网卡就能打满 PCIe 带宽，并且不占 SM。

原文“Prefill Load Balancer”第1段：

段落ID：`48kvBZJl`。

> Prefill Load Balancer 的实现机制可分为 4 层，思路是围绕拟合的注意力子层计算量（记为 compute-quota，是预先拟合的二次代价模型cost(q, c)，q = 序列中未命中的 token 数，c = 这条序列已经算完的前缀长度）来进行请求的路由和分布调度。

后续段落按总输入长度分桶、DP组间与组内分配计算配额，并按时间预算反解每次chunk大小。主报告只借用它解释：恢复时的成本不只由新后缀长度决定；I/O重叠是系统设计目标，需要具体条件才能转化为时延收益。

<a id="zh-06"></a>

### ZH06｜开源边界与投机回退的关联

原文引言：

段落ID：`hEUZmXCx`。

> 推理系统中的 KVCache 管理与负载均衡组件因与内部基础设施耦合较深，相关代码目前尚未完整开源。本文将从上述设计目标出发，介绍 DeepSeek V4.1 Flash 推理系统的整体架构与关键实现，以及这两部分的设计细节。

“DSpark投机解码”段`S8YrSaLK`说明线上一次draft 5个token，变长验证相对固定验证5个token提升吞吐6%。前者与SWA保存段落中的5-token越界、6位置余量一起核对；后者是DSpark对照结果，不归因于Replay。保留量140的依据是原图和README，未找到官方对140−134差值的逐项说明。

## 校验与版本

主报告保留9张手绘图，新增1张官方Prefill原图；原有论文引用保留，新增ZH01—ZH06溯源，与DEP01—DEP06及SWA01—SWA20分开。本文原文摘录来自用户提供资料，未改写引用内部措辞。

MHTML SHA-256：`3dac333807337f624c338fea96584de3d2d5c656437843b96b16a56299fe8fce`。本次未修改MHTML原文件。
