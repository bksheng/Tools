# SWA 图解素材（报告同色版）

本目录复制自 `C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs\swa_diagrams`，配色与本项目《SWA Bounded Replay 技术报告（手绘图解版）》一致，适合单独摘取、裁切或插入其他文档。

![全部配图总览](00-总览.png)

## 选取与使用

- **PNG**：直接插入文档、幻灯片或笔记，也可裁切局部；保留原图分辨率，普通图为 2400 × 1500 像素，03B 为 3000 × 2265 像素。
- **SVG**：矢量格式，适合放大和进一步编辑；文字仍为文本，换电脑打开时需要相应字体。PNG 的字形已固定。
- **Excalidraw**：全部 11 张图均提供 `.excalidraw`，可在 Excalidraw 中打开或拖入；文字、形状、箭头均为可编辑对象。原有 03B 源文件保留，其余 10 张根据本目录的 SVG 转换。
- **Obsidian**：全部 11 张图也提供 `.excalidraw.md`，将目录放入笔记库后，用 Excalidraw 插件打开对应笔记即可编辑和摘取。
- **03 坐标澄清版**：标明了 Query 行、Key / Value 列，建议讲解 mask 时优先选用。

| 编号 | 图解内容 | PNG | SVG | Excalidraw | Obsidian |
| --- | --- | --- | --- | --- | --- |
| 01 | 全局 KV 与局部 SWA KV | [图片](01-global-local.png) | [矢量](01-global-local.svg) | [编辑](01-global-local.excalidraw) | [笔记](01-global-local.excalidraw.md) |
| 02 | 多层局部窗口的依赖范围 | [图片](02-layer-dependency.png) | [矢量](02-layer-dependency.svg) | [编辑](02-layer-dependency.excalidraw) | [笔记](02-layer-dependency.excalidraw.md) |
| 03 | 普通 SWA 与有界回放的 mask | [图片](03-bounded-mask.png) | [矢量](03-bounded-mask.svg) | [编辑](03-bounded-mask.excalidraw) | [笔记](03-bounded-mask.excalidraw.md) |
| 03（坐标澄清） | Query 与 Key / Value 坐标说明 | [图片](03-bounded-mask_坐标澄清版.png) | [矢量](03-bounded-mask_坐标澄清版.svg) | [编辑](03-bounded-mask_坐标澄清版.excalidraw) | [笔记](03-bounded-mask_坐标澄清版.excalidraw.md) |
| 03B | 精确恢复的 D×W 历史跨度 | [图片](03b-exact-recovery-span.png) | [矢量](03b-exact-recovery-span.svg) | [编辑](03b-exact-recovery-span.excalidraw) | [笔记](03b-exact-recovery-span.excalidraw.md) |
| 04 | Encoder 前缀命中后的局部重建 | [图片](04-encoder-replay.png) | [矢量](04-encoder-replay.svg) | [编辑](04-encoder-replay.excalidraw) | [笔记](04-encoder-replay.excalidraw.md) |
| 05 | 缓存寿命与分层保存 | [图片](05-cache-lifetimes.png) | [矢量](05-cache-lifetimes.svg) | [编辑](05-cache-lifetimes.excalidraw) | [笔记](05-cache-lifetimes.excalidraw.md) |
| 06 | CED 与 Decoder 尾窗回放 | [图片](06-decoder-ced.png) | [矢量](06-decoder-ced.svg) | [编辑](06-decoder-ced.excalidraw) | [笔记](06-decoder-ced.excalidraw.md) |
| 07 | 持久化缓存约 1/8 的来源 | [图片](07-storage-savings.png) | [矢量](07-storage-savings.svg) | [编辑](07-storage-savings.excalidraw) | [笔记](07-storage-savings.excalidraw.md) |
| 08 | 回放跨度与 Prefill 计算收益 | [图片](08-replay-compute.png) | [矢量](08-replay-compute.svg) | [编辑](08-replay-compute.excalidraw) | [笔记](08-replay-compute.excalidraw.md) |
| 09 | 近似状态传播与质量边界 | [图片](09-quality-boundary.png) | [矢量](09-quality-boundary.svg) | [编辑](09-quality-boundary.excalidraw) | [笔记](09-quality-boundary.excalidraw.md) |

编辑画布采用暖白底和同一色板。Excalidraw 使用自身字体和手绘线条渲染，外观可能与固定字形的 PNG 略有差异。文字内容与对应 SVG 逐项核对；背景装饰点阵不作为独立编辑对象。

## 色板

| 用途 | 线条 / 强调色 | 填充色 |
| --- | --- | --- |
| Global KV | `#396e9b` | `#e4f0fa` |
| SWA / 尾窗回放 | `#a5682c` | `#fff0d7` |
| 架构、流程、依赖路径 / 精确恢复跨度 | `#7954a3` | `#eee5f5` |
| 新计算 / 后续生成 | `#427a60` | `#e5f3e9` |
| 截断 / 质量边界 | `#a65b61` | `#f7e5e7` |
| 中性元素 | `#8a8790` | `#f0eef1` |

背景 `#fffefb`，正文 `#34313d`，次要文字 `#65616d`，点阵 `#dbd5e1`（60% 不透明度）。色板取自 [`build_swa_diagrams.cjs`](../scripts/build_swa_diagrams.cjs)。

保留了原图的技术内容、尺寸、布局与字体；03B 的依赖路径改为紫色，因此图例中的“橙线”同步改为“紫线”。PNG 全部由改色后的 SVG 重新导出，包括原目录中 PNG 与 SVG 内容不同步的“坐标澄清版”。

## 重新生成

在项目目录依次运行：

```powershell
python .\scripts\recolor_swa_diagrams.py
node .\scripts\render_swa_diagrams.cjs
python .\scripts\complete_swa_excalidraw.py
```

这会从原始目录重新生成本目录的图文件，覆盖本地同名素材。原始目录不作修改。源文件校验值与完整色板见 [`color_style.json`](color_style.json)；原有 `diagram_manifest.json` 原样保留，仍记录原始 9 张主图。

`complete_swa_excalidraw.py` 默认只补缺失的标准 Excalidraw 文件，并同步生成 Obsidian 笔记。若之后修改了 SVG，可使用 `--rebuild-generated` 重新转换本次生成的 10 张图；这会覆盖相应的手动编辑。原有 03B 标准源文件始终保留。对象数量清单见 [`excalidraw_manifest.json`](excalidraw_manifest.json)。
