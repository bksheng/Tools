# SWA 聊天核验报告使用说明

打开 [SWA_Bounded_Replay_聊天核验与原理详解.md](SWA_Bounded_Replay_聊天核验与原理详解.md) 即可阅读完整报告。

- 报告含 10 个主题章节、58 项核验结论、9 张手绘解释图及来源索引。
- 时间有限时，先读第一章的核验结论，再读第十章的统一解释；遇到追问可按附录 A 的聊天行号定位。
- `assets/swa-chat-audit` 保存 PNG、SVG、Excalidraw 和 Obsidian 图件。PNG 已嵌入报告；编辑图请打开同名 `.excalidraw` 或 `.excalidraw.md`。
- Obsidian 中编辑 `.excalidraw.md` 需要 Excalidraw 插件。请保持浅色显示，以接近报告 PNG 的配色。
- 数学公式使用 `$...$` 和 `$$...$$`，可在 Obsidian 的阅读视图中显示。PDF 页码链接是否直接跳页，取决于阅读器。
- `references/chat-audit/聊天记录_带行号.txt` 用来逐行复核；原始聊天和论文也随报告包附上。
- 官方资料以 DeepInfer 固定提交保存，路径和 SHA-256 记录在 `references/chat-audit/download_manifest.json`。源码原许可证保留在该目录的 `deepinfer/LICENSE`。

压缩包解压后，保留目录结构即可查看图片和本地参考文件。不要只转发单独的 Markdown，否则相对路径图片会缺失。

本次已检查本地链接、公式渲染、图片加载和 Excalidraw 原生导入/导出。源码仅作静态核验，未运行模型或测量生产性能；报告已区分论文事实、官方实现补充和解释性推导。

图件生成脚本另存于工作区 `scripts/build_swa_chat_audit_diagrams.cjs`，使用此前同一套绘图组件。图件本身可独立编辑，不要求安装生成脚本使用的依赖。
