# SWA Bounded Replay 技术报告（图解精简版）

**基于：** *DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression*，arXiv:2609.19969v1  
**用途：** 会议汇报 · [论文 PDF](2609.19969v1.pdf) · [完整图解版](SWA_Bounded_Replay_技术报告_图解版.md)

> **核心结论：** SWA Bounded Replay 只回放最近一个滑动窗口，近似重建局部 KV 状态。Encoder 用它降低缺失状态的恢复成本，Decoder 用它减少预填充计算。

正文按“问题—原理—两类用法—收益—质量边界”展开。图号沿用完整版，图中算例均为解释性示意；引文页码指论文 PDF。详细工程与部署资料见文末查阅入口。

## 1. 为什么要改变 SWA KV 的保存方式

模型同时使用**全局 KV** 和 **SWA KV**：前者支持访问全局上下文，后者用于滑动窗口内的局部注意力。V4.1-Flash 的窗口为 128，主干采用因果编码器—解码器（CED）架构，共 40 层。prefill 是处理提示词、建立状态的阶段，decode 是随后逐步生成输出的阶段。〔第 7、9、21–22 页〕

![CED 架构与两类 KV 的来源](assets/swa-bounded-replay/01-ced-architecture.png)

*图 1. Decoder 的全局 KV 可由 Encoder 末层输出获得，SWA KV 仍需逐层准备。* [编辑此图](assets/swa-bounded-replay/01-ced-architecture.excalidraw.md)

问题在于：**SWA KV 的复用主要集中在活跃会话的分钟级时间内，却占 V4 持久化 KV 容量的近一半。** 单个序列只需保留一个局部窗口，但大量历史会话长期保存窗口状态，仍会占用大量空间。完全不保存、缺失后精确重算，又会带来难以接受的恢复成本。〔第 19 页〕

V4.1 因此将两类缓存分开管理：全局 KV 长期保存，编码器 SWA KV 放入短期内存池，缺失时通过有界回放恢复。〔第 19–20 页〕

![V4 与 V4.1 的缓存管理对比](assets/swa-bounded-replay/02-cache-management.png)

*图 2. 低成本恢复支持缩短 SWA 的保存期限；短期池与运行时仍保留所需的 SWA 状态。* [编辑此图](assets/swa-bounded-replay/02-cache-management.excalidraw.md)

## 2. 一个窗口为什么只能近似恢复

**局部依赖会随层数累积。** 高层位置的隐藏状态依赖下层更早位置，因此“最终只需一个窗口的 KV”并不等于“重算一个窗口即可精确恢复”。〔第 9、20 页〕

![多层局部依赖如何向更早位置展开](assets/swa-bounded-replay/03-layer-dependency.png)

*图 3. W=4 的纯局部依赖算例。R(d) 是说明性推导，描述单个输出的依赖范围，不是论文的整窗 KV 恢复长度公式。* [编辑此图](assets/swa-bounded-replay/03-layer-dependency.excalidraw.md)

用 `D` 表示待执行层组的深度、`W` 表示窗口宽度：论文将精确恢复跨度概括为 `D×W`；有界回放只处理 `W` 个 token，仍执行相关的 `D` 层，并接受近似状态。其依据之一是论文引用的观察：SWA 的实际有效感受野远小于理论范围。〔第 9、20 页；D 用于区别后文的总层数 L〕

回放从位置 `s` 开始时，查询 `i` 只能读取以下范围的 SWA key：〔第 20 页〕

$$
\left[\max(s,\ i-W+1),\ i\right].
$$

![普通 SWA 与有界回放的可见范围对比](assets/swa-bounded-replay/03-bounded-replay-mask.png)

*图 4. 纵轴是 query 位置，横轴是 key/value 位置；圆点表示允许读取，红叉表示额外截断。行数不表示层数，圆点不表示注意力权重。* [编辑此图](assets/swa-bounded-replay/03-bounded-replay-mask.excalidraw.md)

图中最后一行虽然已覆盖完整窗口，但这些位置的隐藏状态可能在下层受到截断影响，高层 KV 因而仍是近似的。**截断针对 SWA 分支；全局注意力仍利用全局 KV，并遵守原有的因果与稀疏访问规则。**

## 3. Encoder 与 Decoder 分别如何使用

**Encoder：全局 KV 命中、SWA KV 缺失时，恢复缓存前缀末尾。** 设全局 KV 命中前缀长度为 `P`、整个提示词长度为 `N`，则从 `s=max(0,P−W)` 开始，将回放片段 `[s,P)` 与新后缀 `[P,N)` 一起处理。回放前缀只重新生成 SWA KV，**已缓存的全局 KV 不重算、不覆盖**；新后缀生成两类 KV。区间均为左闭右开。〔第 20 页〕

![Encoder SWA Bounded Replay 流程](assets/swa-bounded-replay/04-encoder-replay.png)

*图 5. 三行按相同位置边界对齐；图中假设 P≥W。* [编辑此图](assets/swa-bounded-replay/04-encoder-replay.excalidraw.md)

**Decoder：每次 prefill，都处理整个提示词末尾。** CED 已能从 Encoder 输出获得 Decoder 的全局 KV，剩下需要逐层准备的是 SWA KV。因此，只让提示词末尾窗口的 Encoder 输出经过 20 层 Decoder，并采用同样的 SWA 截断；生成的局部 KV **仅供随后 decode，不用于前缀缓存**。〔第 9、20 页〕

![Decoder SWA Bounded Replay 流程](assets/swa-bounded-replay/05-decoder-replay.png)

*图 6. Decoder 的末尾以整个提示词终点 N 为边界，Encoder 的末尾以前缀命中点 P 为边界。两者不能互换。* [编辑此图](assets/swa-bounded-replay/05-decoder-replay.excalidraw.md)

两项实现要点：Encoder 的“只生成 SWA KV”是缓存写入规则，仍需执行相关隐藏状态计算；Decoder 所需的尾窗 Encoder 输出必须可取得，不能由全局 KV 命中自动推定。这是根据论文流程整理的工程说明。

## 4. 能获得哪些收益，DDR 能省在哪里

**计算收益：长输入下，总体 prefill 计算量减少近一半。** CED 让 Encoder 处理序列，Decoder 只处理末尾窗口；按论文复杂度表达，工作量由 `O(NL)` 变为 `O(NL/2+WL/2)`。近半的条件是 `N≫W`，且依赖 CED 与 Decoder Replay 配合。〔第 9、20 页〕

![回放跨度与总体 prefill 计算量的区别](assets/swa-bounded-replay/07-replay-compute.png)

*图 7. 2560→128 是恢复跨度缩至 1/20，两种方式均经过 20 层；不能直接解读为端到端 20 倍加速。* [编辑此图](assets/swa-bounded-replay/07-replay-compute.excalidraw.md)

**存储收益：相同工作负载下，持久化 KV 约为 V4 的 1/8。** 这一结果由移除持久化 SWA KV 与全局 KV 压缩共同贡献；全局部分的约 1/4 来自 CSA2 跨层复用、FP4 等优化。SWA KV 自身仍保留 FP8。〔第 14、19 页〕

![持久化 KV 缓存降至约 1/8 的来源](assets/swa-bounded-replay/06-storage-reduction.png)

*图 8. 100、50、12.5 是说明性比例；1/8 比较的是持久化 KV，不能外推为整个服务全部内存的缩减比例。* [编辑此图](assets/swa-bounded-replay/06-storage-reduction.excalidraw.md)

**DDR 收益：通过减少长期保存的 SWA 快照，释放缓存容量。** 以下按 DDR 指服务器主机内存理解，属于根据论文机制整理的工程解释。预期是：允许更早淘汰 SWA，缺失时用 Encoder 有界回放恢复，使同样 DDR 能保存更多会话。容量收益来自**减少保存份数、缩短保存期限**，并不意味着单份 SWA KV 变小。

| 当前 DDR 中的 SWA 保存方式 | 可能获得的收益 |
| --- | --- |
| 长期保存大量历史会话的 SWA 快照 | 改为短期保存，可释放较多容量；具体取决于减少了多少快照。 |
| 保存当前正在推理的请求所需状态 | 运行时仍需这些状态，不能直接把这部分内存计为可节省量。 |
| 已经采用分钟级短期池 | 进一步收益取决于还能缩小多少池容量，以及额外回放成本是否可接受。 |

可按相同工作负载作粗略估算：

`DDR 净节省 ≈ 减少的 SWA 快照数 × 单份快照大小 − 新增目录与回放临时状态的 DDR 占用`

**论文没有直接给出目标平台的 DDR 节省比例。** 其 V4 长期缓存主要放在 SSD，V4.1 另用主机 DRAM 建立短期 SWA 池，因此不能将论文的“持久化 KV 约为 1/8”直接解释成“DDR 降到 1/8”。实际应比较改造前后的 DDR 稳态与峰值占用。〔论文部署方式见第 19 页；比较方法为工程建议〕

**其他系统收益：减少 SWA 持久化读写，并可能提高服务承载能力。** 缓存容量或计算压力降低后，同样资源可能承载更多会话或请求；DDR 读写流量、跨机传输、吞吐和实际时延是否改善，仍取决于原有瓶颈，需要分别测量。全局 KV 的加载成本仍然存在。

汇报时可将两类收益分开：**Encoder 主要支持减少长期缓存与降低恢复成本；Decoder 配合 CED 主要减少 prefill 计算。** 若目标是 DDR 容量，应重点核对 Encoder SWA 的现有保存量与期限，并同时记录淘汰后增加的恢复次数和时延。

## 5. 质量结论与适用边界

论文报告，**在已评估的设置中，近似恢复对回答质量的影响很小，但重建状态在数学上不等同于完整前向结果。** Encoder 回放会使新后缀的全局 KV 和 SWA KV 依赖缓存命中位置；Decoder 则在后训练中模拟相同回放进行适配。〔第 20 页〕

![缓存恢复边界与质量结论](assets/swa-bounded-replay/09-quality-boundary.png)

*图 9. 上半图说明 Encoder 的边界影响；下半图左侧是 Decoder 的后训练适配，右侧为评估建议。图中没有表达实测误差大小。* [编辑此图](assets/swa-bounded-replay/09-quality-boundary.excalidraw.md)

作者仍保留对未测试边界的限制说明，特别关注**缓存恢复边界处的 SWA 重建与长上下文稀疏检索**。论文没有给出 Replay 独立的逐项质量消融表、误差上界或恢复时延对比，因此汇报应保留“已评估设置下影响很小”的范围。〔第 20、37 页〕

## 补充查阅

技术追问可查[完整图解版](SWA_Bounded_Replay_技术报告_图解版.md)，以下内容保留在完整版中：

| 需要展开的问题 | 查阅位置 |
| --- | --- |
| 精确恢复的整段输入如何经过各层 | 附录 A；[精确恢复补充图](assets/swa-bounded-replay/A1-exact-recovery-span.png) |
| 常见误解与会议问答 | 附录 B |
| 请求分流、位置与缓存一致性、边界测试 | 附录 C（工程建议） |
| TTL 约 180 秒、命中率超过 98%；128/134/140 的区别；mask 与 compact；官方性能图 | 附录 D（后续部署资料，非 v1 论文）；[来源与固定版本](references/README.md) |
| 完整原文位置索引 | 附录 F；核心依据为论文第 9、19–20、37 页 |

本版与完整版共用 `assets/` 配图；分享 Markdown 时需一并保留图片目录。可编辑源文件的用法见[图解使用说明](SWA_Bounded_Replay_图解使用说明.md)。
