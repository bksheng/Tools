# 来源与移植说明

## 论文

[2609.19969v1.pdf](../2609.19969v1.pdf) 为报告主来源。正文页码及英文引文沿用已核对的原文，后续部署信息单列为附录 D。

## 本次移植来源

整合版原文件位于 `C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs\SWA_Bounded_Replay_技术汇报_整合版.md`。

移入正文：开场主线、三种保存策略、跨层依赖解释、query/key 坐标对照、前后缀区间、跨度与层数区别、近似传播路径。
移入附录：精确恢复图、会议问答、请求分流与验证要点、后续部署数值及官方性能图、汇报顺序。
为保持会议报告可读性，未照搬长伪代码、完整状态字段表、未经代码核验的其他推理框架入口。

## 图形来源与编辑

保留原图解版的 CED、缓存管理、Decoder 和持久化收益图；其余 6 张解释图移植自整合版的 `swa_diagrams/`，统一了回放术语、配色与编号，并补充质量图中的 Encoder/Decoder 范围。

新图 3、4、5、7、9、A1 的 SVG 来自原图适配，PNG 由该 SVG 导出；Excalidraw 场景由矢量形状转换生成，形状、线段和文字可分别编辑，字体及线条效果可能与 PNG 略有差异。保留图的场景由原绘图脚本生成。所有解释图均非论文原图。

## 后续部署资料

[DeepSeek 官方部署文章](https://zhuanlan.zhihu.com/p/2095560295930508953) · [离线 MHTML 快照](DeepSeek_V4.1_Flash_官方部署实践.mhtml) · [未修改的性能原图](zhihu_deepinfer_prefill_140.jpg)。TTL 约 180 秒、SWA 命中率超过 98% 来源于文章的 SWA KVCache 段；140-token 基准来自离线性能图。

DeepInfer 固定提交：`553741557a57df44a46fb3ab72b6aafeaf945337`。下列文件均已下载为离线副本并静态阅读；没有运行 GPU 模型或复现实测。

| 文件 | 核对内容 | 固定版本 | 离线副本 |
| --- | --- | --- | --- |
| `README.md` | compact / 140 推荐配置 | [源码](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/README.md#L25) | [本地](deepinfer/README.md) |
| `doc/inference_deployment_qa.md` | SWA 保存、134 容量与命中余量、128 回退 | [源码](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/doc/inference_deployment_qa.md#L159) | [本地](deepinfer/doc/inference_deployment_qa.md) |
| `deepinfer/environ.py` | off/mask/compact 默认值及保留长度约束 | [源码](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/environ.py#L194) | [本地](deepinfer/deepinfer/environ.py) |
| `deepinfer/worker/model_runner.py` | 保留长度与最大回退量校验 | [源码](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/worker/model_runner.py#L101) | [本地](deepinfer/deepinfer/worker/model_runner.py) |
| `csrc/engine/input_metadata/prepare_tensor_input_v4.cpp` | 有效状态下界、query 保留与占位行 | [源码](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/csrc/engine/input_metadata/prepare_tensor_input_v4.cpp#L129) | [本地](deepinfer/csrc/engine/input_metadata/prepare_tensor_input_v4.cpp) |

资料不支持的结论未移入：140=128+6+6 的原因、Replay 独立 20 倍加速、完全无损、全部内存压缩到 1/8。
