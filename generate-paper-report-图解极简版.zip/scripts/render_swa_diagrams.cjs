// Re-render the copied diagram set and a compact contact sheet.
const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/sheng/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const out = path.resolve(__dirname, '../swa_diagrams');
const files = fs.readdirSync(out).filter(name => name.endsWith('.svg')).sort();

(async () => {
  const tiles = [];
  for (const [i, file] of files.entries()) {
    const stem = file.slice(0, -4);
    const pngPath = path.join(out, stem + '.png');
    const {width, height} = await sharp(pngPath).metadata();
    const png = await sharp(path.join(out, file)).resize(width, height).png().toBuffer();
    fs.writeFileSync(pngPath, png);
    const info = await sharp(png).metadata();
    if (info.width !== width || info.height !== height) throw new Error('Changed output size: ' + file);
    const preview = await sharp(png).resize({width: 720, height: 540, fit: 'inside'}).png().toBuffer();
    const dimensions = await sharp(preview).metadata();
    const x = (i % 3) * 752;
    const y = Math.floor(i / 3) * 580;
    const label = stem.replace('_坐标澄清版', ' (axes clarified)');
    const caption = Buffer.from(`<svg width="720" height="32"><text x="4" y="24" font-family="sans-serif" font-size="19" fill="#34313d">${label}</text></svg>`);
    tiles.push({input: caption, left: x + 16, top: y + 4});
    tiles.push({input: preview, left: x + 16 + Math.floor((720 - dimensions.width) / 2), top: y + 36});
    console.log(`${stem}: ${width} x ${height}`);
  }
  await sharp({create: {width: 2256, height: Math.ceil(files.length / 3) * 580, channels: 3, background: '#f0eef1'}})
    .composite(tiles).png().toFile(path.join(out, '00-总览.png'));
})().catch(error => {console.error(error); process.exit(1);});
