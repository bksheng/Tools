const fs = require('fs');
const path = require('path');
const sharp = require('C:/Users/sheng/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root = path.resolve(__dirname,'..');
const dir = path.join(root,'assets','swa-bounded-replay');
async function main(){
  const manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
  for(const fig of manifest.filter(x=>x.source)){
    const svg=fs.readFileSync(path.join(dir,fig.name+'.svg'));
    await sharp(svg).resize({width:fig.figure==='A1'?3000:2400}).png().toFile(path.join(dir,fig.name+'.png'));
    await sharp(svg).resize({width:fig.figure==='A1'?1800:1600}).png().toFile(path.join(root,'tmp','diagrams',fig.name+'-preview.png'));
  }
  console.log('Rendered 6 adapted diagrams.');
}
main().catch(e=>{console.error(e);process.exit(1)});
