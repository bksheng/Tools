"""Adapt selected integrated-report SVGs and produce editable Excalidraw scenes."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re, json
from PIL import ImageFont

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r'C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs\swa_diagrams')
OUT = ROOT / 'assets/swa-bounded-replay'
NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('',NS)
PALETTE = {'#fcfbf7':'#fffefb','#293040':'#34313d','#6e7180':'#65616d',
           '#e2e0d9':'#dbd5e1','#f0f0ed':'#f0eef1','#326d9f':'#396e9b',
           '#e6f0f8':'#e4f0fa','#b6762c':'#a5682c','#fbefdb':'#fff0d7',
           '#8057ab':'#7954a3','#f0ebf9':'#eee5f5','#b85555':'#a65b61',
           '#faebeb':'#f7e5e7','#3b8065':'#427a60','#e5f2e9':'#e5f3e9'}

def convert_scene(root, name):
    elements=[]
    def base(kind,x,y,w,h,stroke='#34313d',fill='transparent',sw=1):
        i=len(elements)+1
        return dict(id=f'{name}-{i}',type=kind,x=x,y=y,width=w,height=h,angle=0,
                    strokeColor=stroke,backgroundColor=fill,fillStyle='solid',strokeWidth=sw,
                    strokeStyle='solid',roughness=0,opacity=100,groupIds=[],frameId=None,
                    roundness=None,seed=10000+i,version=1,versionNonce=20000+i,isDeleted=False,
                    boundElements=None,updated=1793696400000,link=None,locked=False)
    for node in root:
        tag=node.tag.split('}')[-1]; a=node.attrib
        get=lambda k,d=0: float(a.get(k,d))
        fill=a.get('fill','transparent'); stroke=a.get('stroke','transparent')
        if tag=='rect':
            # Background is represented by appState rather than a page-sized shape.
            if 'x' not in a: continue
            e=base('rectangle',get('x'),get('y'),get('width'),get('height'),stroke,fill,get('stroke-width',0.5))
        elif tag=='circle':
            r=get('r')
            if r<2: continue
            e=base('ellipse',get('cx')-r,get('cy')-r,2*r,2*r,stroke,fill,get('stroke-width',1))
        elif tag=='polyline':
            pts=[tuple(map(float,p.split(','))) for p in a['points'].split()]
            x=min(p[0] for p in pts); y=min(p[1] for p in pts)
            e=base('line',x,y,max(p[0] for p in pts)-x,max(p[1] for p in pts)-y,stroke,fill,get('stroke-width',2))
            e.update(points=[[p[0]-x,p[1]-y] for p in pts],lastCommittedPoint=None,startBinding=None,endBinding=None,startArrowhead=None,endArrowhead=None)
            if a.get('stroke-dasharray'): e['strokeStyle']='dashed'
        elif tag=='text':
            txt=''.join(node.itertext()); size=get('font-size',24)
            font=ImageFont.truetype(r'C:\Windows\Fonts\simkai.ttf',round(size))
            w=font.getlength(txt)+8; x=get('x'); y=get('y')-size*.9
            align=a.get('text-anchor','start')
            if align=='middle': x-=w/2
            elif align=='end': x-=w
            e=base('text',x,y,w,size*1.35,fill)
            e.update(text=txt,originalText=txt,fontSize=size,fontFamily=1,textAlign='left',verticalAlign='top',containerId=None,autoResize=False,lineHeight=1.35,baseline=size)
        else: continue
        if 'opacity' in a: e['opacity']=round(float(a['opacity'])*100)
        elements.append(e)
    scene=dict(type='excalidraw',version=2,source='https://excalidraw.com',elements=elements,
               appState=dict(viewBackgroundColor='#fffefb',gridSize=None),files={})
    js=json.dumps(scene,ensure_ascii=False,indent=2)
    (OUT/f'{name}.excalidraw').write_text(js,encoding='utf-8')
    texts='\n\n'.join(f"{e['text']} ^{e['id']}" for e in elements if e['type']=='text')
    (OUT/f'{name}.excalidraw.md').write_text('---\nexcalidraw-plugin: parsed\ntags:\n  - excalidraw\n---\n\n# Excalidraw Data\n\n## Text Elements\n\n'+texts+'\n\n%%\n## Drawing\n\n```json\n'+js+'\n```\n%%\n',encoding='utf-8')
    return len(elements)

def build(src,dst,num,local_orange=False,changes=None):
    xml=(SOURCE/f'{src}.svg').read_text(encoding='utf-8').replace('重放','回放').replace('教学','说明性')
    for a,b in PALETTE.items(): xml=xml.replace(a,b)
    if local_orange:
        xml=xml.replace('#7954a3','#a5682c').replace('#eee5f5','#fff0d7')
    root=ET.fromstring(xml)
    for t in root.findall(f'{{{NS}}}text'):
        txt=t.text or ''
        if '/  SWA BOUNDED REPLAY' in txt: t.text=f'{num}  /  SWA BOUNDED REPLAY'
        if changes and txt in changes:
            v=changes[txt]
            if isinstance(v,tuple):
                t.text=v[0]; t.attrib.update(v[1])
            else: t.text=v
    if num=='03':
        for t in root.findall(f'{{{NS}}}text'):
            if re.fullmatch(r'-[1-9]',t.text or ''):
                t.text='i'+t.text.replace('-','−')
                t.set('x',str(float(t.get('x'))-8))
                t.set('font-size','21')
    if num=='09':
        for e in root:
            tag=e.tag.split('}')[-1]
            if tag=='rect' and e.get('x')=='1090': e.set('fill','#e5f3e9')
            if tag=='text' and ('新后缀状态' in (e.text or '') or (e.text or '')=='Global + SWA'):
                e.set('fill','#427a60')
            if tag=='polyline':
                pts=[tuple(map(float,p.split(','))) for p in e.get('points').split()]
                if min(x for x,y in pts)>1080 and 210<min(y for x,y in pts)<580:
                    e.set('stroke','#427a60')
    if num=='A1':
        for e in root:
            for attr in ('fill','stroke'):
                if e.get(attr) in ('#396e9b','#326d9f'): e.set(attr,'#65616d')
                elif e.get(attr) in ('#e4f0fa','#e8f0fa','#e6f0f8'): e.set(attr,'#f0eef1')
    (OUT/f'{dst}.svg').write_text(ET.tostring(root,encoding='unicode'),encoding='utf-8')
    count=convert_scene(root,dst)
    return dict(name=dst,width=int(root.attrib['width']),height=int(root.attrib['height']),elements=count,figure=num,source=src)

manifest=[m for m in json.loads((OUT/'manifest.json').read_text(encoding='utf-8')) if not m.get('source')]
manifest += [
    build('02-layer-dependency','03-layer-dependency','03',True),
    build('03-bounded-mask_坐标澄清版','03-bounded-replay-mask','04',True,{
        '4 行 = 4 个 Query，不是 4 层；回放仍经过相关层组的全部层。':'4 行 = 4 个 Query 位置；回放仍经过相关层组的全部层。',
        'Global 历史访问继续遵守因果与稀疏规则；各层 SWA 使用右侧截断。':('全局历史访问遵守因果与稀疏规则；各层 SWA 使用右侧截断。',{'x':'380'}),
    }),
    build('04-encoder-replay','04-encoder-replay','05',True,{
        'Encoder：前缀命中了，局部状态却丢了':'Encoder：全局前缀命中，局部状态缺失',
        '触发：Global KV 命中 + Encoder SWA 缺失；旧 Global 严格只读':'触发：全局 KV 命中 + Encoder SWA 缺失；旧全局 KV 不重算、不覆盖',
        'Global':'全局 KV','生成新增 Global':('生成新全局 KV',{'x':'1180'}),
        '正常生成新 SWA':('生成新 SWA',{'x':'1220'}),
        '尾窗 + 新后缀一起做 Encoder 前向':'末尾窗口 + 新后缀一起做 Encoder 前向',
        '边界影响：新后缀的 Global 与 SWA 都可能随命中位置 P 改变。':'边界影响：新后缀的全局 KV 与 SWA KV 都可能随命中位置 P 改变。',
    }),
    build('08-replay-compute','07-replay-compute','07',False,{
        '128 token  →  跨度缩短 20 倍':'128 token  →  跨度为原来的 1/20',
        '计算收益：先分清跨度，再谈 Prefill':'计算收益：回放跨度与 prefill 计算量',
    }),
    build('09-quality-boundary','09-quality-boundary','09',False,{
        '同一输入，不同缓存命中点，后缀的状态可以不同':'Encoder：同一输入，从不同缓存命中边界恢复，后缀状态可能不同',
        '训练侧适配':('Decoder 后训练适配',{'x':'240','font-size':'32'}),
        '需要继续验证的边界':('工程建议：继续验证边界',{'x':'970','font-size':'32'}),
        '论文 §3.2.2、§6，pp.20、37；误差路径示意，无数值误差比例':'依据论文 pp.20、37；上半图为 Encoder；下半图左侧为 Decoder 适配、右侧为评估建议',
    }),
    build('03b-exact-recovery-span','A1-exact-recovery-span','A1',False,{
        '本图纵轴是层；图03 mask 的纵轴是 Query 位置。两张图展示不同维度。':'本图纵轴是层；正文图 4 的纵轴是 Query 位置。两张图展示不同维度。',
    }),
]
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False))
