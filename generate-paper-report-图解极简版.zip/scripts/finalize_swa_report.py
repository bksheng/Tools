from pathlib import Path
import json, re, hashlib, zipfile
from urllib.parse import unquote
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
usage = '''# 图解报告使用说明

打开 [手绘图解版报告](SWA_Bounded_Replay_技术报告_图解版.md) 阅读。正文第 1–8 节用于会议汇报；附录 A–D 供技术追问，附录 E 是 15 分钟汇报顺序，附录 F 是论文位置索引。原文字版报告保留不变。

## 在 Obsidian 中阅读与编辑

将报告与 `assets/`、`references/`、论文 PDF 一起放入笔记库，并保留目录结构。正文采用普通 Markdown 图片链接与数学公式；图片可直接显示，点击或缩放可查看细节。

10 张解释图均提供以下文件：

- `.png`：报告实际引用的图片，宽 2160–3000 像素，中文字形已固定。
- `.svg`：矢量源图，适合放大或放入其他文档。
- `.excalidraw.md`：可用 Obsidian Excalidraw 插件编辑的绘图笔记。
- `.excalidraw`：可导入 Excalidraw 的标准场景文件。

各图下方“编辑此图”指向对应绘图笔记。保留图的场景由原脚本生成，移植图的场景由 SVG 形状转换，文字、框与线段可分别编辑；转换图中的箭头由可编辑线段组成。编辑器字体和线条效果可能与导出 PNG 有少许差异。修改后重新导出同名 PNG，即可更新报告图片。

官方性能图 D1 保留原始 JPG，不提供人为重绘的 Excalidraw 版本。

## 配图位置

| 图号 | 内容 | 报告位置 | 文件名 |
| --- | --- | --- | --- |
| 1 | CED 架构与两类 KV 来源 | 2.1 | `01-ced-architecture` |
| 2 | 缓存管理与保存期限 | 3.3 | `02-cache-management` |
| 3 | 跨层局部依赖如何扩展 | 4.1 | `03-layer-dependency` |
| 4 | 普通 SWA 与回放可见范围 | 4.2 | `03-bounded-replay-mask` |
| 5 | Encoder 前缀、回放与新后缀对齐 | 5.2 | `04-encoder-replay` |
| 6 | Decoder 末尾窗口处理 | 6.3 | `05-decoder-replay` |
| 7 | 回放跨度与 prefill 计算量 | 6.4 | `07-replay-compute` |
| 8 | 持久化约 1/8 的来源 | 7.2 | `06-storage-reduction` |
| 9 | 近似传播与质量结论 | 8 | `09-quality-boundary` |
| A1 | 精确恢复范围与逐层计算 | 附录 A | `A1-exact-recovery-span` |
| D1 | 启用 140-token 回放的官方性能图 | 附录 D.4 | `references/zhihu_deepinfer_prefill_140.jpg` |

部分原文件名保留以兼容原有笔记链接；汇报图号以报告和图片内标题为准。解释图沿用蓝色全局 KV、橙色 SWA/回放、紫色架构/依赖、绿色新计算、红色边界提醒的配色；附录 A1 中的状态分组另有图内标签。各图都标注了说明性算例或证据范围。

## 备份与分享

移植前备份保存在工作目录 `backups/`：

- `SWA_Bounded_Replay_技术报告_图解版_移植前_20261103_171035.md`
- `SWA_Bounded_Replay_图解报告包_移植前_20261103_171035.zip`（含更新前完整图片与可编辑源文件）

使用更新后的 `SWA_Bounded_Replay_图解报告包.zip` 分享。包内含报告、10 张解释图的四种格式、官方性能原图、原文字版、移植前报告文本副本、论文 PDF、后续部署资料和使用说明。解压后保留相对路径即可使用；无需访问原整合版目录。旧的完整 ZIP 备份仅留在工作目录，不再嵌入新包。恢复更新前的完整图解版时应使用该旧 ZIP。

移植内容与来源见 [来源说明](references/README.md)。
'''
(ROOT/'SWA_Bounded_Replay_图解使用说明.md').write_text(usage,encoding='utf-8')

report_path = ROOT/'SWA_Bounded_Replay_技术报告_图解版.md'
report=report_path.read_text(encoding='utf-8')
manifest=json.loads((ROOT/'assets/swa-bounded-replay/manifest.json').read_text(encoding='utf-8'))
assert len(manifest)==10 and len({x['name'] for x in manifest})==10
assert report.count('\n$$')==10, 'Expected 5 paired display equations'
assert len(re.findall(r'^```',report,re.M))==4, 'Expected 2 paired code blocks'
figures=re.findall(r'^\*图 ([0-9]+|[A-Z][0-9]+)\.',report,re.M)
assert figures==[str(n) for n in range(1,10)]+['A1','D1'],figures
assert report.count('![')==11

links=[]
for file in [report_path,ROOT/'SWA_Bounded_Replay_图解使用说明.md',ROOT/'references/README.md']:
    text=file.read_text(encoding='utf-8')
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)',text):
        link=match.group(1).strip('<>')
        if re.match(r'https?://|#',link): continue
        target=(file.parent/unquote(link.split('#')[0])).resolve()
        assert target.is_file(),(file.name,link)
        links.append(str(target.relative_to(ROOT)))
    assert '\ufffd' not in text

for fig in manifest:
    stem=ROOT/'assets/swa-bounded-replay'/fig['name']
    for suffix in ['.png','.svg','.excalidraw','.excalidraw.md']:
        assert Path(str(stem)+suffix).is_file()
    with Image.open(str(stem)+'.png') as im: im.verify()
    scene=json.loads(Path(str(stem)+'.excalidraw').read_text(encoding='utf-8'))
    assert scene['type']=='excalidraw' and scene['elements']
    ids=[e['id'] for e in scene['elements']]
    assert len(ids)==len(set(ids))
    embedded=Path(str(stem)+'.excalidraw.md').read_text(encoding='utf-8').split('```json\n')[1].split('\n```')[0]
    assert json.loads(embedded)==scene

backup=ROOT/'backups/SWA_Bounded_Replay_技术报告_图解版_移植前_20261103_171035.md'
backupzip=ROOT/'backups/SWA_Bounded_Replay_图解报告包_移植前_20261103_171035.zip'
with zipfile.ZipFile(backupzip) as z:
    assert z.testzip() is None
    old_name=next(n for n in z.namelist() if n.endswith('SWA_Bounded_Replay_技术报告_图解版.md'))
    old=z.read(old_name).decode('utf-8-sig').replace('\r\n','\n')
    snap=backup.read_text(encoding='utf-8-sig').replace('C:/PyCode/Task/Codex/generate-paper-report/2609.19969v1.pdf','2609.19969v1.pdf')
    assert old.strip()==snap.strip(),'Backup text differs from original package'

files=[report_path,ROOT/'SWA_Bounded_Replay_技术报告.md',ROOT/'SWA_Bounded_Replay_图解使用说明.md',ROOT/'2609.19969v1.pdf',backup]
files += list((ROOT/'assets/swa-bounded-replay').glob('*'))
files += [p for p in (ROOT/'references').rglob('*') if p.is_file()]
files += list((ROOT/'backups').glob('SWA_Bounded_Replay_技术报告_20*.md'))
files=sorted(set(files))
assert not any(p.suffix=='.zip' for p in files)
zip_path=ROOT/'SWA_Bounded_Replay_图解报告包.zip'
tmp_zip=ROOT/'tmp/SWA_Bounded_Replay_图解报告包.new.zip'
with zipfile.ZipFile(tmp_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for file in files:
        name=file.relative_to(ROOT).as_posix()
        if file.name=='SWA_Bounded_Replay_技术报告.md':
            text=file.read_text(encoding='utf-8-sig').replace('C:/PyCode/Task/Codex/generate-paper-report/2609.19969v1.pdf','2609.19969v1.pdf')
            z.writestr(name,text)
        else: z.write(file,name)
with zipfile.ZipFile(tmp_zip) as z:
    assert z.testzip() is None
    names=set(z.namelist())
    assert all(p.replace('\\','/') in names for p in links)
    assert z.read(report_path.name)==report_path.read_bytes()
tmp_zip.replace(zip_path)

summary={'report_bytes':report_path.stat().st_size,'body_chinese_characters':len(re.findall(r'[\u4e00-\u9fff]',report.split('## 附录 A.')[0])),
         'explanatory_figures':len(manifest),'total_images':report.count('!['),'resolved_local_links':len(links),
         'package_files':len(files),'package_bytes':zip_path.stat().st_size,
         'backup_report_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),
         'report_sha256':hashlib.sha256(report_path.read_bytes()).hexdigest(),'zip_integrity':'passed'}
(ROOT/'tmp/migration_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
