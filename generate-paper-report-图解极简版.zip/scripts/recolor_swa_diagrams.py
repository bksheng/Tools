"""Copy the supplied diagram collection and apply this report's existing palette.

Run from any directory: python scripts/recolor_swa_diagrams.py
Then run: node scripts/render_swa_diagrams.cjs
The source collection is read-only. Re-running rebuilds the local copies.
"""

from pathlib import Path
import copy
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r"C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs\swa_diagrams")
OUT = ROOT / "swa_diagrams"
C = {
    "ink": "#34313d", "muted": "#65616d", "paper": "#fffefb",
    "purple": "#7954a3", "purpleFill": "#eee5f5",
    "blue": "#396e9b", "blueFill": "#e4f0fa",
    "orange": "#a5682c", "orangeFill": "#fff0d7",
    "green": "#427a60", "greenFill": "#e5f3e9",
    "red": "#a65b61", "redFill": "#f7e5e7",
    "gray": "#8a8790", "grayFill": "#f0eef1",
    "dots": "#dbd5e1", "divider": "#d4ccd9", "grid": "#d8d4dc",
}
BASE = {
    "#fcfbf7": C["paper"], "#293040": C["ink"],
    "#6e7180": C["muted"], "#697180": C["muted"],
    "#8057ab": C["purple"], "#f0ebf9": C["purpleFill"],
    "#326d9f": C["blue"], "#eaf1fa": C["blueFill"],
    "#b6762c": C["orange"], "#fbefdb": C["orangeFill"],
    "#4b805a": C["green"], "#eaf4ec": C["greenFill"],
    "#b85555": C["red"], "#faebeb": C["redFill"],
    "#f0f0ed": C["grayFill"], "#c5bfd0": C["grid"],
    "#e2e0d9": C["grid"],
}
SWA_PURPLE = {"01-global-local", "04-encoder-replay", "05-cache-lifetimes", "07-storage-savings"}
LEGEND_OLD = "橙线是一条依赖路径"
LEGEND_NEW = "紫线是一条依赖路径"


def palette(name):
    mapping = dict(BASE)
    if name in SWA_PURPLE:
        mapping.update({"#8057ab": C["orange"], "#f0ebf9": C["orangeFill"]})
    if name == "03b-exact-recovery-span":
        # Orange: the SWA target tail. Purple: dependency paths / full recovery.
        # Input representations are neutral; they do not denote Global KV here.
        mapping.update({
            "#8057ab": C["orange"], "#f0ebf9": C["orangeFill"],
            "#b6762c": C["purple"], "#fbefdb": C["purpleFill"],
            "#326d9f": C["gray"], "#eaf1fa": C["grayFill"],
        })
    return mapping


def structural_label(text):
    return (text.startswith("第 ") and text.endswith("层 KV")) or text.startswith((
        "纵轴：层深度", "两种方式均经过", "本图纵轴是层"))


def recolor_svg(source):
    tree = ET.parse(source)
    original = copy.deepcopy(tree.getroot())
    root = tree.getroot()
    name = source.stem
    mapping = palette(name)
    for e in root.iter():
        tag = e.tag.split("}")[-1]
        old = dict(e.attrib)
        text = "".join(e.itertext()) if tag == "text" else ""
        for key in ("fill", "stroke"):
            if e.get(key) in mapping:
                e.set(key, mapping[e.get(key)])
        if tag == "circle" and old.get("fill") == "#e2e0d9":
            e.set("fill", C["dots"])
            e.set("opacity", "0.6")
        if tag == "polyline" and old.get("stroke") == "#e2e0d9":
            e.set("stroke", C["divider"])
            points = [float(v) for p in old["points"].split() for v in p.split(",")]
            if min(points[1::2]) < 230 and max(points[0::2]) - min(points[0::2]) > 1000:
                e.set("stroke", C["purple"])
        if name.startswith("03-bounded-mask"):
            # The ordinary and replay masks both describe SWA; query axes and
            # explanatory labels retain the process purple.
            if tag != "text" or text in ("普通 SWA", "●"):
                if old.get("fill") == "#f0ebf9":
                    e.set("fill", C["orangeFill"])
                if old.get("fill") == "#8057ab":
                    e.set("fill", C["orange"])
                if old.get("stroke") == "#8057ab":
                    e.set("stroke", C["orange"])
            if text.startswith("列：Key / Value"):
                e.set("fill", C["muted"])
        if name == "03b-exact-recovery-span":
            if text == LEGEND_OLD:
                e.text = LEGEND_NEW
            if structural_label(text):
                e.set("fill", C["purple"])
            if tag == "polyline" and old.get("stroke") == "#8057ab":
                xs = [float(p.split(",")[0]) for p in old["points"].split()]
                if max(xs) < 100:
                    e.set("stroke", C["purple"])
    # Update self-contained process / new-computation boxes without moving them.
    boxes = {
        "06-decoder-ced": {(460, 260): "purple", (950, 691): "green"},
        "09-quality-boundary": {(1090, 230): "green", (1090, 437): "green"},
    }.get(name, {})
    children = list(root)
    for index, e in enumerate(children):
        if e.tag.endswith("rect") and "x" in e.attrib:
            role = boxes.get((float(e.get("x")), float(e.get("y"))))
            if role:
                e.set("fill", C[role + "Fill"])
                for border in children[index + 1:index + 3]:
                    assert border.tag.endswith("polyline")
                    border.set("stroke", C[role])
    # Verification: geometry, typography, ordering and technical text are kept.
    before, after = list(original.iter()), list(root.iter())
    assert len(before) == len(after)
    for a, b in zip(before, after):
        assert a.tag == b.tag
        ignore = {"fill", "stroke", "opacity"}
        assert {k: v for k, v in a.attrib.items() if k not in ignore} == {
            k: v for k, v in b.attrib.items() if k not in ignore}
        assert (a.text or "").replace(LEGEND_OLD, LEGEND_NEW) == (b.text or "")
    tree.write(OUT / source.name, encoding="utf-8", xml_declaration=False)


def recolor_scene(source):
    data = json.loads(source.read_text(encoding="utf-8"))
    original = copy.deepcopy(data)
    mapping = palette(source.stem)
    for e in data["elements"]:
        for key in ("strokeColor", "backgroundColor"):
            if e.get(key) in mapping:
                e[key] = mapping[e[key]]
        text = e.get("text", "")
        if structural_label(text) or (e["type"] in ("arrow", "line") and e["x"] < 100 and e.get("strokeColor") == C["orange"]):
            e["strokeColor"] = C["purple"]
        if e.get("strokeColor") == C["grid"] and e["type"] in ("arrow", "line"):
            e["strokeColor"] = C["purple"] if e["y"] < 230 and e["width"] > 1000 else C["divider"]
        for key in ("text", "originalText"):
            if key in e:
                e[key] = e[key].replace(LEGEND_OLD, LEGEND_NEW)
    data["appState"]["viewBackgroundColor"] = C["paper"]
    for a, b in zip(original["elements"], data["elements"]):
        ignored = {"strokeColor", "backgroundColor", "text", "originalText"}
        assert {k: v for k, v in a.items() if k not in ignored} == {k: v for k, v in b.items() if k not in ignored}
    (OUT / source.name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    assert SOURCE.resolve() != OUT.resolve()
    OUT.mkdir(exist_ok=True)
    files = sorted(SOURCE.iterdir())
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    for source in files:
        if source.suffix == ".svg":
            recolor_svg(source)
        elif source.suffix == ".excalidraw":
            recolor_scene(source)
        elif source.is_file():
            shutil.copy2(source, OUT / source.name)
    style = {"source": str(SOURCE), "reference": "../scripts/build_swa_diagrams.cjs", "palette": C,
             "notes": ["SWA / 回放使用橙色；架构、依赖路径及精确恢复跨度使用紫色。",
                       "03B 的颜色图例同步由“橙线”改为“紫线”；其余技术文字、布局、字体保持原样。",
                       "PNG 由修改后的 SVG 重新渲染，保留原 PNG 尺寸。"],
             "source_sha256": hashes}
    (OUT / "color_style.json").write_text(json.dumps(style, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
    print(f"Recolored {len(list(OUT.glob('*.svg')))} SVGs and 1 Excalidraw; source hashes unchanged.")


if __name__ == "__main__":
    main()
