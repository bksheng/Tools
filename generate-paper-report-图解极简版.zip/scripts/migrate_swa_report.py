"""Build the revised report from the immutable pre-migration backup."""
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r'C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs')
BASE = ROOT / 'backups/SWA_Bounded_Replay_技术报告_图解版_移植前_20261103_171035.md'
report = BASE.read_text(encoding='utf-8-sig')

def replace(old, new):
    global report
    assert old in report, old[:120]
    report = report.replace(old, new, 1)

replace('[本地 PDF](C:/PyCode/Task/Codex/generate-paper-report/2609.19969v1.pdf)', '[本地 PDF](2609.19969v1.pdf)')
replace('> **配图说明：** 新增 6 张 Excalidraw 风格的解释性示意图，均依据论文内容重绘。蓝色表示全局 KV，橙色表示 SWA 或回放片段，紫色表示架构与处理过程，绿色表示新计算或后续生成。配图与可编辑源文件位于同级 `assets/swa-bounded-replay/` 目录。', '''> **阅读方式：** 正文第 1–8 节用于会议汇报，附录 A–D 用于技术追问和部署讨论，附录 E 给出汇报顺序。正文事实依据论文；“说明性推导”“工程建议”和“后续官方部署资料”分别标注，不将后续资料写成论文结论。

> **配图说明：** 正文含 9 张手绘风格图，附录含 1 张精确恢复示意图和 1 张官方性能原图。解释图均非论文原图：蓝色表示全局 KV，橙色表示 SWA 或回放片段，紫色表示架构与依赖过程，绿色表示新计算或后续生成，红色用于截断或边界提醒。各图下方提供 Obsidian Excalidraw 编辑源文件。''')
replace('## 2. 理解这一方法所需的背景', '''汇报可沿着一条主线展开：**长期保存 SWA KV 的容量成本高，完全不保存又会带来昂贵的精确恢复；有界回放把恢复限制在一个窗口内，以近似状态换取更低恢复成本，从而支持短期保存。** 其中，Encoder 主要解决缓存保存与恢复，Decoder 主要减少 prefill 计算，两者应分别说明。

## 2. 理解这一方法所需的背景''')
replace('精确恢复需要对最近的 `L × n_win` 个 token 执行完整前向计算。', '精确恢复需要对最近的 `L × n_win` 个 token 执行完整前向计算（此处沿用原文记号；第 4 节用 `D` 区分待恢复层组的深度与 CED 总层数）。')
replace('## 4. 有界回放的共同原理', '''三种保存与恢复策略可以放在一起理解：

| 策略 | SWA KV 如何保存 | 缺失后如何恢复 | 主要代价 |
| --- | --- | --- | --- |
| V4 的持久化保存 | 在指定位置长期保存窗口状态 | 命中后直接复用 | SWA 约占持久化 KV 容量的一半 |
| V4 报告提出的 Zero SWA Caching | 不持久化保存 SWA 状态 | 回放较长序列，精确恢复 | 论文称生产中的重计算成本难以接受 |
| V4.1 的短期池与有界回放 | 编码器 SWA 分钟级保存；不进持久化缓存 | 短期池命中时复用，缺失时回放一窗 | 保留少量短期存储，并接受近似恢复 |

此表依据论文第 19–20 页整理；第三行描述 Encoder 缓存管理，Decoder 状态另按每次 prefill 准备。

## 4. 有界回放的共同原理''')
replace('论文第 3.2.2 节的一般性表述是：精确重建 `L` 层的 SWA KV，需要回放最近的 `L × n_win` 个 token；有界回放只处理最近的 `n_win` 个 token，并接受近似状态。', '''为避免混淆，本报告用 `D` 表示需要执行的层组深度，用 `L` 表示 CED 主干总层数。论文第 3.2.2 节以 `L × n_win` 概括精确恢复跨度；按这里的记号写为 `D × W`。有界回放只处理最近的 `W` 个 token，并接受近似状态，**两种方式都仍需执行相关的 `D` 层**。

![多层局部依赖如何向更早位置展开](assets/swa-bounded-replay/03-layer-dependency.png)

*图 3. W=4 的纯局部注意力说明性算例。从最高层一个位置向下追踪，涉及的位置数依次为 1、4、7、10。* [编辑此图](assets/swa-bounded-replay/03-layer-dependency.excalidraw.md)

图中的 `R(d) = 1 + d(W−1)` 只解释单个输出沿 `d` 层局部注意力路径可依赖的输入范围，**不是论文公式，也不是恢复各层整窗 KV 的最小长度公式**。它与论文的 `D × W` 恢复跨度描述不同对象。若需展开“整段输入如何经过各层”，见附录 A。''')
start = report.index('以下是依据原文公式给出的说明性算例，不是论文实验：')
end = report.index('### 4.3. 采用近似恢复的依据', start)
report = report[:start] + '''以下使用 `W=4、s=100` 的说明性算例。token 从 0 编号；表中可见范围为两端均包含的闭区间，后文的序列切片使用左闭右开的 `[a,b)`。

| 当前查询位置 i | 普通 SWA 可见的 key | 有界回放可见的 key |
| --- | --- | --- |
| 100 | 97–100 | 100 |
| 101 | 98–101 | 100–101 |
| 102 | 99–102 | 100–102 |
| 103 | 100–103 | 100–103 |

回放开头的查询缺少更早的局部状态，因而结果是近似的。到 `i=103` 时，当前层虽然已能看到完整的 4 个位置，但这些位置的隐藏状态可能已在下层受到截断影响，所以高层 KV 仍不能保证与完整前向计算相同。

![普通 SWA 与有界回放的可见范围对比](assets/swa-bounded-replay/03-bounded-replay-mask.png)

*图 4. 行是 query 的 token 位置，列是 key/value 的 token 位置；4 行不是 4 层。圆点表示允许读取，红叉表示额外截断，空格表示原本不可见；图中没有表达注意力权重大小。* [编辑此图](assets/swa-bounded-replay/03-bounded-replay-mask.excalidraw.md)

''' + report[end:]
replace('第 3.2.2 节描述的过程如下：〔第 20 页〕', '''先统一边界。令 `N` 为整个提示词长度，`P` 为全局 KV 命中的前缀长度，`W=128`，则：

```text
s = max(0, P - W)
已缓存前缀       tokens[0:P]
需要回放的片段   tokens[s:P]
未缓存后缀       tokens[P:N]
```

这些切片均为左闭右开区间。例如 `P=10000` 时，回放 `[9872,10000)` 的 128 个 token；新后缀从位置 10000 开始。前缀不足一窗时，只使用实际存在的前缀。这是用于说明论文过程的边界写法。

第 3.2.2 节描述的过程如下：〔第 20 页〕''')
replace('*图 4. 回放片段与未缓存后缀一起处理。已缓存前缀的全局 KV 保持不变，新后缀的两类 KV 会受近似前缀状态影响。*', '*图 5. 请求、全局 KV 与 SWA 三行按同一组位置边界对齐。图中假设 P≥W，回放 [P−W,P)，随后计算 [P,N)；旧全局 KV 不重算、不覆盖。*')
replace('### 5.3. 近似性会影响后续新计算', '''**“只重新生成 SWA KV”说明回放片段的缓存生成与写入规则，不表示只执行一次 KV 投影。** 为得到各层局部状态，仍需执行相关层的隐藏状态计算；不能据此省略应有的 attention、MoE 等前向步骤。这是对论文处理过程的解释，工程实现要点见附录 C。

### 5.3. 近似性会影响后续新计算''')
replace('*图 5. 每次 prefill 只将提示词末尾 128 个 token 的编码器输出送入解码器，准备随后 decode 所需的局部状态。*', '*图 6. 每次 prefill 将完整提示词末尾窗口的编码器输出送入解码器，准备随后 decode 所需的局部状态。这里的末尾以 N 为边界，区别于 Encoder 回放中的前缀边界 P。*')
replace('### 6.4. 为什么总体 prefill 计算可减少近一半', '''实现时还需取得 `tokens[max(0,N−W):N]` 对应的编码器末层输出。**全局 KV 命中，不自动代表这些隐藏状态也已保存或可直接取得。** 特别是新后缀短于一窗或整个提示词可命中时，要明确尾窗编码器输出的来源；论文没有要求长期保存所有层的输入隐藏状态。这是根据 Decoder 输入条件提出的工程说明。

### 6.4. 为什么总体 prefill 计算可减少近一半''')
replace('### 6.5. 质量与后训练适配', '''![回放跨度与总体 prefill 计算量的区别](assets/swa-bounded-replay/07-replay-compute.png)

*图 7. 上半部分比较恢复跨度，2560 与 128 两条路径均经过 20 层 Decoder；下半部分说明 CED 配合回放时的长输入计算量。跨度比例与端到端时延是不同指标。* [编辑此图](assets/swa-bounded-replay/07-replay-compute.excalidraw.md)

### 6.5. 质量与后训练适配''')
replace('*图 6. 两项存储收益相乘。', '*图 8. 两项存储收益相乘。')
replace('## 附录：原文位置索引', '''![缓存恢复边界与质量结论](assets/swa-bounded-replay/09-quality-boundary.png)

*图 9. 上半图解释 Encoder 在不同缓存命中边界恢复时，新后缀状态为何可能不同；比较的是共同后缀中的位置。下半图左侧是论文明确披露的 Decoder 后训练适配，右侧是进一步评估建议。该图不表示实测误差大小，也不暗示 Encoder 已采用同样适配。* [编辑此图](assets/swa-bounded-replay/09-quality-boundary.excalidraw.md)

## 附录 A. 精确恢复跨度与层数的补充图解

此图用于回答“重放整个 `D×W` 跨度，是否只计算其中某一层”。用 `D=3、W=4、P=104` 举例：按论文的恢复跨度描述，输入位置 92–103，共 12 个 token，经过 3 层；恢复目标是各层最后一窗，即位置 100–103 的 SWA KV。有界回放只处理位置 100–103，但仍经过 3 层。

![精确恢复的历史跨度与逐层计算](assets/swa-bounded-replay/A1-exact-recovery-span.png)

*图 A1. 纵轴是层深度，区别于图 4 的 query 位置。浅色格只表示重算的中间 KV，不表示每格均已恢复为完整前向的原值；D×W 沿用论文口径，不是逐 token 最小恢复长度的证明。* [编辑此图](assets/swa-bounded-replay/A1-exact-recovery-span.excalidraw.md)

## 附录 B. 会议常见问答

| 问题 | 建议回答 |
| --- | --- |
| 只回放 128 个 token，是否只保留 128 个 token 的上下文？ | 128 是局部回放窗口；全局注意力仍利用全局 KV，并遵守其因果与稀疏访问规则。 |
| SWA KV 是否全部取消？ | 取消的是长期持久化保存。短期池仍保存编码器 SWA，运行时及 decode 仍使用局部状态。 |
| 已经缓存命中，为什么还要计算？ | 全局 KV 命中和 SWA 状态可用是两件事；Encoder SWA 缺失时需恢复，Decoder 则每次 prefill 都准备自身 SWA。 |
| 约 8 倍持久化压缩都是 Replay 的贡献吗？ | 不是。移除持久化 SWA 约减半，再叠加全局 KV 压缩至对应部分的约 1/4。 |
| 2560→128 是否表示 20 倍加速？ | 这是回放跨度缩至 1/20，两种方式仍经过 20 层；实际时延还受加载、通信、访存和批处理影响。 |
| 是否完全无损？ | 论文明确为近似状态。已评估设置下质量影响很小，未测试边界仍需验证。 |
| 任意 Decoder-only 模型都可把 prefill 减半吗？ | 不能直接外推。这里依赖 CED 的全局 KV 来源设计，并要求输入长度远大于窗口。 |
| 论文的 128 与部署中的 134、140 是否冲突？ | 三者分别涉及模型窗口、含回退余量的状态容量、配置的尾部保留长度；见附录 D。 |

## 附录 C. 工程处理与验证要点

以下是根据论文机制整理的**工程建议**，不是论文披露的完整生产实现。

### C.1. 三种请求情况

| 请求情况 | Encoder 如何处理 | Decoder 仍需准备什么 |
| --- | --- | --- |
| 无可复用的全局前缀，P=0 | 正常处理提示词，建立状态 | 完整提示词末尾窗口的编码器输出与 Decoder SWA |
| 全局前缀命中，且该边界的 SWA 状态有效 | 从 P 继续计算未缓存后缀 | 每次 prefill 仍准备随后 decode 所需的 SWA |
| 全局前缀命中，但 SWA 缺失或不兼容 | 从 s=max(0,P−W) 回放，连同新后缀处理 | 取得完整提示词末尾窗口的编码器输出，再经过 Decoder |

有效的 SWA 快照应匹配前缀边界、模型版本、位置处理和缓存格式。回放时保留原始 token 位置；SWA 截断不能直接套到全局分支；全局读取仍需遵守因果性；旧前缀全局 KV 不写回，新后缀从 P 开始追加。实现中应分别记录“全局 KV 已复用到哪里”和“本次前向从哪里开始”，不能用一个进度数混同二者。

### C.2. 分开验证实现与近似质量

| 验证目标 | 建议检查 |
| --- | --- |
| 实现是否符合算法 | 位置编号、截断下界、有效缓存槽、旧全局 KV 不被改写、Decoder 尾窗输入可取得；比较相同截断语义下的实现结果。 |
| 近似是否可接受 | 固定模型与输入，对比完整状态、缺失后精确恢复、有界恢复；分别启用 Encoder、Decoder 和两者。不要把有界恢复与完整前向不完全一致自动判为实现错误。 |
| 边界是否稳定 | 同一输入改变命中位置；新后缀长度取 1、W−1、W、W+1；提示词短于 W；SWA 淘汰后多次恢复；长上下文稀疏检索。 |
| 收益如何测量 | 分别记录恢复触发比例、恢复耗时、端到端 TTFT 的 P50/P99、吞吐、持久化容量和短期池容量；质量变化与性能收益分别报告。 |

可按需要增加 2W、4W 的回放长度对照，以观察恢复成本与质量的关系；这些是评估建议，并非论文已有消融结果。旧全局 KV 即使不重算，也可能需要匹配、读取和换入，因此固定回放跨度不等于整条请求耗时与历史长度无关。

## 附录 D. 后续官方部署资料补充

**本附录不属于 v1 论文。** 来源包括 DeepSeek 的[《DeepSeek V4.1 Flash 大规模推理部署实践》](https://zhuanlan.zhihu.com/p/2095560295930508953)（本地快照标注更新于 2026-10-20），以及固定到提交 `553741557a57df44a46fb3ab72b6aafeaf945337` 的 DeepInfer 文档与源码。这里只核对了资料与静态代码，没有复现 GPU 性能。来源索引与离线副本见 [references/README.md](references/README.md)。

### D.1. 短期池的实际部署观察

部署文章披露：SWA KV 留在产生它的机器内存中，由分布在各 Entrypoint 上的内存目录记录位置，命中时可跨机取回；**TTL 约 180 秒，命中率超过 98%**。这补充了论文“分钟级保存可服务绝大多数活跃会话”的描述，但不是任意业务都能达到的保证。文章未完整披露该命中率的采样窗口与统计分母，不能据此直接认定全部请求的 Encoder Replay 触发率恰为 2%。

### D.2. 128、134 与 140 分别指什么

| 数值 | 对象与证据 | 含义 |
| --- | --- | --- |
| 128 | 论文模型窗口 W；部署 Q&A 也使用 128-token 保存粒度 | 局部注意力窗口与论文基本回放跨度；保存粒度是另一项配置含义。 |
| 134=128+6 | 官方 Q&A 的 SWA 状态环长度及命中余量 | 6 个位置用于投机回退等余量，不表示注意力窗口改为 134。 |
| 140 | 官方 README 推荐的 Decoder 尾部保留参数 R；性能图也标注 140 | 需覆盖窗口与最大回退量；不表示论文把 W 改成 140。 |

源码约束为 `R >= W + MAX_BACKTRACKING_TOKENS`。资料没有逐项解释 140 相对 134 多出的 6 个位置，因此不将它写成未经证实的“128+6+6”。

Q&A 给出的命中规则还为尾部计算保留空间：输入长 N 时，将最大命中限制在 `N−134` 以内，再取按 128 对齐的全局命中位置 H；若缺少所需 SWA，则从 `H−128` 开始回放。这里退回的是前向起点，`[H−128,H)` 原有全局 KV 仍可复用，未缓存后缀仍从 H 开始。短输入与不足一个块的情况需要按实际实现处理，不能机械使用负起点。

### D.3. 修改可见范围与真正减少计算行

README 推荐以下配置；源码默认模式为 `off`、保留数为 0，推荐值需要显式设置：

```text
DEEPINFER_YOCO_PREFILL_TRUNCATION_MODE=compact
DEEPINFER_YOCO_PREFILL_KEEP_TOKENS=140
```

| 模式 | SWA 的可见范围 | query 行与 Decoder 侧计算 |
| --- | --- | --- |
| off | 不启用这项尾部截断 | 未启用该优化 |
| mask | 原滑动窗口与尾部保留区间的交集 | 保留全部 query 行，只收窄可见范围 |
| compact | 采用同样的截断规则 | 移除无需保留的 query 行，并调整相关元数据，以减少计算 |

因此，**改变 attention mask 本身不能证明已省去对应 query 的前向计算**。源码还将状态有效起点纳入 SWA 下界；分块 prefill 中，更早的块可能保留一个占位行，不能将所有执行形态概括为“恰好只有 128 行”。

### D.4. 可引用的官方性能原图

![官方部署基准：启用 140-token Decoder Bounded Replay](references/zhihu_deepinfer_prefill_140.jpg)

*图 D1. 摘自官方部署文章“离线性能基准测试数据”，从用户提供的 MHTML 快照中取得，原图未修改。条件为 EP4/DP4、384+32 experts、上下文 131072、Decoder Bounded Replay 140 tokens。横轴为每个 prefill step 的延迟，纵轴为不含缓存命中的每 GPU 输入吞吐，点标签为每个 DP rank 的 batch token 数。*

这张图可以说明官方基准采用了 140-token 配置，以及该系统在不同批大小下的吞吐与时延关系。**图中没有关闭 Replay 或精确恢复的对照，不能从中单独分离 Replay 的加速贡献。**

## 附录 E. 约 15 分钟的汇报顺序

| 时间 | 内容 | 建议用图 |
| --- | --- | --- |
| 2 分钟 | 长期保存贵，精确恢复也贵；区分全局与局部 KV | 图 1–2 |
| 4 分钟 | 多层依赖为何变长；一窗回放如何截断、为何近似 | 图 3–4 |
| 4 分钟 | Encoder 恢复缓存前缀末尾，Decoder 处理完整提示词末尾 | 图 5–6 |
| 3 分钟 | 2560→128、prefill 近半、持久化约 1/8 分别指什么 | 图 7–8 |
| 2 分钟 | 质量结论与缓存恢复边界；按听众问题展开附录 | 图 9 |

## 附录 F. 原文位置索引''')
(ROOT / 'SWA_Bounded_Replay_技术报告_图解版.md').write_text(report, encoding='utf-8')

refs = ROOT / 'references'
refs.mkdir(exist_ok=True)
shutil.copy2(SOURCE / 'references/zhihu_deepinfer_prefill_140.jpg', refs)
shutil.copy2(SOURCE / 'DeepSeek V4.1 Flash 大规模推理部署实践 - 知乎.mhtml', refs / 'DeepSeek_V4.1_Flash_官方部署实践.mhtml')
commit='553741557a57df44a46fb3ab72b6aafeaf945337'
readme = '''# 来源与移植说明

## 论文

[2609.19969v1.pdf](../2609.19969v1.pdf) 为报告主来源。正文页码及英文引文沿用已核对的原文，后续部署信息单列为附录 D。

## 本次移植来源

整合版原文件位于 `C:\\Users\\sheng\\Documents\\Codex\\2026-11-02\\gen\\outputs\\SWA_Bounded_Replay_技术汇报_整合版.md`。

移入正文：开场主线、三种保存策略、跨层依赖解释、query/key 坐标对照、前后缀区间、跨度与层数区别、近似传播路径。
移入附录：精确恢复图、会议问答、请求分流与验证要点、后续部署数值及官方性能图、汇报顺序。
为保持会议报告可读性，未照搬长伪代码、完整状态字段表、未经代码核验的其他推理框架入口。

## 图形来源与编辑

保留原图解版的 CED、缓存管理、Decoder 和持久化收益图；其余 6 张解释图移植自整合版的 `swa_diagrams/`，统一了回放术语、配色与编号，并补充质量图中的 Encoder/Decoder 范围。

新图 3、4、5、7、9、A1 的 SVG 来自原图适配，PNG 由该 SVG 导出；Excalidraw 场景由矢量形状转换生成，形状、线段和文字可分别编辑，字体及线条效果可能与 PNG 略有差异。保留图的场景由原绘图脚本生成。所有解释图均非论文原图。

## 后续部署资料

[DeepSeek 官方部署文章](https://zhuanlan.zhihu.com/p/2095560295930508953) · [离线 MHTML 快照](DeepSeek_V4.1_Flash_官方部署实践.mhtml) · [未修改的性能原图](zhihu_deepinfer_prefill_140.jpg)。TTL 约 180 秒、SWA 命中率超过 98% 来源于文章的 SWA KVCache 段；140-token 基准来自离线性能图。

DeepInfer 固定提交：`COMMIT`。下列文件均已下载为离线副本并静态阅读；没有运行 GPU 模型或复现实测。

| 文件 | 核对内容 | 固定版本 | 离线副本 |
| --- | --- | --- | --- |
'''.replace('COMMIT', commit)
for file, purpose, line in [
    ('README.md','compact / 140 推荐配置',25),
    ('doc/inference_deployment_qa.md','SWA 保存、134 容量与命中余量、128 回退',159),
    ('deepinfer/environ.py','off/mask/compact 默认值及保留长度约束',194),
    ('deepinfer/worker/model_runner.py','保留长度与最大回退量校验',101),
    ('csrc/engine/input_metadata/prepare_tensor_input_v4.cpp','有效状态下界、query 保留与占位行',129),
]:
    readme += f'| `{file}` | {purpose} | [源码](https://github.com/deepseek-ai/DeepInfer/blob/{commit}/{file}#L{line}) | [本地](deepinfer/{file}) |\n'
readme += '\n资料不支持的结论未移入：140=128+6+6 的原因、Replay 独立 20 倍加速、完全无损、全部内存压缩到 1/8。\n'
(refs/'README.md').write_text(readme,encoding='utf-8')
print('Updated report and source references.')
