# SWA 图解素材（报告同色版）

本目录复制自 `C:\Users\sheng\Documents\Codex\2026-11-02\gen\outputs\swa_diagrams`，配色与本项目《SWA Bounded Replay 技术报告（手绘图解版）》一致，适合单独摘取、裁切或插入其他文档。

![全部配图总览](00-总览.png)

## 选取与使用

- **PNG**：直接插入文档、幻灯片或笔记，也可裁切局部；保留原图分辨率，普通图为 2400 × 1500 像素，03B 为 3000 × 2265 像素。
- **SVG**：矢量格式，适合放大和进一步编辑；文字仍为文本，换电脑打开时需要相应字体。PNG 的字形已固定。
- **Excalidraw**：原目录仅 03B 提供此格式，已同步改色；其形状、箭头和文字可分别编辑。
- **03 坐标澄清版**：标明了 Query 行、Key / Value 列，建议讲解 mask 时优先选用。

| 编号 | 图解内容 | PNG | SVG |
| --- | --- | --- | --- |
| 01 | 全局 KV 与局部 SWA KV | [图片](01-global-local.png) | [矢量](01-global-local.svg) |
| 02 | 多层局部窗口的依赖范围 | [图片](02-layer-dependency.png) | [矢量](02-layer-dependency.svg) |
| 03 | 普通 SWA 与有界回放的 mask | [图片](03-bounded-mask.png) | [矢量](03-bounded-mask.svg) |
| 03（坐标澄清） | Query 与 Key / Value 坐标说明 | [图片](03-bounded-mask_坐标澄清版.png) | [矢量](03-bounded-mask_坐标澄清版.svg) |
| 03B | 精确恢复的 D×W 历史跨度 | [图片](03b-exact-recovery-span.png) | [矢量](03b-exact-recovery-span.svg) |
| 04 | Encoder 前缀命中后的局部重建 | [图片](04-encoder-replay.png) | [矢量](04-encoder-replay.svg) |
| 05 | 缓存寿命与分层保存 | [图片](05-cache-lifetimes.png) | [矢量](05-cache-lifetimes.svg) |
| 06 | CED 与 Decoder 尾窗回放 | [图片](06-decoder-ced.png) | [矢量](06-decoder-ced.svg) |
| 07 | 持久化缓存约 1/8 的来源 | [图片](07-storage-savings.png) | [矢量](07-storage-savings.svg) |
| 08 | 回放跨度与 Prefill 计算收益 | [图片](08-replay-compute.png) | [矢量](08-replay-compute.svg) |
| 09 | 近似状态传播与质量边界 | [图片](09-quality-boundary.png) | [矢量](09-quality-boundary.svg) |

[03B 可编辑 Excalidraw 源文件](03b-exact-recovery-span.excalidraw)

## 色板

| 用途 | 线条 / 强调色 | 填充色 |
| --- | --- | --- |
| Global KV | `#396e9b` | `#e4f0fa` |
| SWA / 尾窗回放 | `#a5682c` | `#fff0d7` |
| 架构、流程、依赖路径 / 精确恢复跨度 | `#7954a3` | `#eee5f5` |
| 新计算 / 后续生成 | `#427a60` | `#e5f3e9` |
| 截断 / 质量边界 | `#a65b61` | `#f7e5e7` |
| 中性元素 | `#8a8790` | `#f0eef1` |

背景 `#fffefb`，正文 `#34313d`，次要文字 `#65616d`，点阵 `#dbd5e1`（60% 不透明度）。色板取自 [`build_swa_diagrams.cjs`](../scripts/build_swa_diagrams.cjs)。

保留了原图的技术内容、尺寸、布局与字体；03B 的依赖路径改为紫色，因此图例中的“橙线”同步改为“紫线”。PNG 全部由改色后的 SVG 重新导出，包括原目录中 PNG 与 SVG 内容不同步的“坐标澄清版”。

## 重新生成

在项目目录依次运行：

```powershell
python .\scripts\recolor_swa_diagrams.py
node .\scripts\render_swa_diagrams.cjs
```

这会从原始目录重新生成本目录的图文件，覆盖本地同名素材。原始目录不作修改。源文件校验值与完整色板见 [`color_style.json`](color_style.json)；原有 `diagram_manifest.json` 原样保留，仍记录原始 9 张主图。
