---
excalidraw-plugin: parsed
tags:
  - excalidraw
---

# Excalidraw Data

## Text Elements

04  /  SWA BOUNDED REPLAY ^03-bounded-replay-mask-1

有界回放：某一层的局部可见范围 ^03-bounded-replay-mask-2

W=4、s=100；圆点=允许读取，红叉=额外截断，空格=原本不可读 ^03-bounded-replay-mask-3

普通 SWA ^03-bounded-replay-mask-5

列：Key / Value 位置 j ^03-bounded-replay-mask-6

Query i ^03-bounded-replay-mask-7

行 ↓ ^03-bounded-replay-mask-8

97 ^03-bounded-replay-mask-9

98 ^03-bounded-replay-mask-10

99 ^03-bounded-replay-mask-11

100 ^03-bounded-replay-mask-12

101 ^03-bounded-replay-mask-13

102 ^03-bounded-replay-mask-14

103 ^03-bounded-replay-mask-15

100 ^03-bounded-replay-mask-16

● ^03-bounded-replay-mask-19

● ^03-bounded-replay-mask-22

● ^03-bounded-replay-mask-25

● ^03-bounded-replay-mask-28

101 ^03-bounded-replay-mask-35

● ^03-bounded-replay-mask-40

● ^03-bounded-replay-mask-43

● ^03-bounded-replay-mask-46

● ^03-bounded-replay-mask-49

102 ^03-bounded-replay-mask-54

● ^03-bounded-replay-mask-61

● ^03-bounded-replay-mask-64

● ^03-bounded-replay-mask-67

● ^03-bounded-replay-mask-70

103 ^03-bounded-replay-mask-73

● ^03-bounded-replay-mask-82

● ^03-bounded-replay-mask-85

● ^03-bounded-replay-mask-88

● ^03-bounded-replay-mask-91

[max(0, i-W+1), i] ^03-bounded-replay-mask-92

Bounded Replay ^03-bounded-replay-mask-93

列：Key / Value 位置 j ^03-bounded-replay-mask-94

Query i ^03-bounded-replay-mask-95

行 ↓ ^03-bounded-replay-mask-96

97 ^03-bounded-replay-mask-97

98 ^03-bounded-replay-mask-98

99 ^03-bounded-replay-mask-99

100 ^03-bounded-replay-mask-100

101 ^03-bounded-replay-mask-101

102 ^03-bounded-replay-mask-102

103 ^03-bounded-replay-mask-103

100 ^03-bounded-replay-mask-104

● ^03-bounded-replay-mask-119

101 ^03-bounded-replay-mask-126

● ^03-bounded-replay-mask-139

● ^03-bounded-replay-mask-142

102 ^03-bounded-replay-mask-147

● ^03-bounded-replay-mask-158

● ^03-bounded-replay-mask-161

● ^03-bounded-replay-mask-164

103 ^03-bounded-replay-mask-167

● ^03-bounded-replay-mask-176

● ^03-bounded-replay-mask-179

● ^03-bounded-replay-mask-182

● ^03-bounded-replay-mask-185

[max(s, i-W+1), i] ^03-bounded-replay-mask-186

s=100 ^03-bounded-replay-mask-188

只截断 ^03-bounded-replay-mask-191

局部分支 ^03-bounded-replay-mask-192

4 行 = 4 个 Query 位置；回放仍经过相关层组的全部层。 ^03-bounded-replay-mask-193

全局历史访问遵守因果与稀疏规则；各层 SWA 使用右侧截断。 ^03-bounded-replay-mask-197

记住：这是 mask 示意，不是层数图，也不是完整回放流程或实际注意力权重。 ^03-bounded-replay-mask-199

论文 §3.2.2，p.20；说明性例 W=4，模型实际 W=128；图中坐标均为 token 位置 ^03-bounded-replay-mask-200

%%
## Drawing

```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [
    {
      "id": "03-bounded-replay-mask-1",
      "type": "text",
      "x": 76.0,
      "y": 44.2,
      "width": 283.0,
      "height": 29.700000000000003,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10001,
      "version": 1,
      "versionNonce": 20001,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "04  /  SWA BOUNDED REPLAY",
      "originalText": "04  /  SWA BOUNDED REPLAY",
      "fontSize": 22.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 22.0
    },
    {
      "id": "03-bounded-replay-mask-2",
      "type": "text",
      "x": 76.0,
      "y": 90.1,
      "width": 773.0,
      "height": 68.85000000000001,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10002,
      "version": 1,
      "versionNonce": 20002,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "有界回放：某一层的局部可见范围",
      "originalText": "有界回放：某一层的局部可见范围",
      "fontSize": 51.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 51.0
    },
    {
      "id": "03-bounded-replay-mask-3",
      "type": "text",
      "x": 79.0,
      "y": 155.7,
      "width": 783.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10003,
      "version": 1,
      "versionNonce": 20003,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "W=4、s=100；圆点=允许读取，红叉=额外截断，空格=原本不可读",
      "originalText": "W=4、s=100；圆点=允许读取，红叉=额外截断，空格=原本不可读",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-4",
      "type": "line",
      "x": 77.78,
      "y": 204.57,
      "width": 1442.18,
      "height": 0.2400000000000091,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10004,
      "version": 1,
      "versionNonce": 20004,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          1442.18,
          0.2400000000000091
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-5",
      "type": "text",
      "x": 284.67,
      "y": 240.5,
      "width": 150.0,
      "height": 47.25,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10005,
      "version": 1,
      "versionNonce": 20005,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "普通 SWA",
      "originalText": "普通 SWA",
      "fontSize": 35.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 35.0
    },
    {
      "id": "03-bounded-replay-mask-6",
      "type": "text",
      "x": 229.33,
      "y": 292.3,
      "width": 268.0,
      "height": 31.05,
      "angle": 0,
      "strokeColor": "#396e9b",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10006,
      "version": 1,
      "versionNonce": 20006,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "列：Key / Value 位置 j",
      "originalText": "列：Key / Value 位置 j",
      "fontSize": 23.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 23.0
    },
    {
      "id": "03-bounded-replay-mask-7",
      "type": "text",
      "x": 50.67,
      "y": 326.9,
      "width": 78.0,
      "height": 25.650000000000002,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10007,
      "version": 1,
      "versionNonce": 20007,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "Query i",
      "originalText": "Query i",
      "fontSize": 19.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 19.0
    },
    {
      "id": "03-bounded-replay-mask-8",
      "type": "text",
      "x": 70.67,
      "y": 350.8,
      "width": 53.0,
      "height": 24.3,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10008,
      "version": 1,
      "versionNonce": 20008,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "行 ↓",
      "originalText": "行 ↓",
      "fontSize": 18.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 18.0
    },
    {
      "id": "03-bounded-replay-mask-9",
      "type": "text",
      "x": 184.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10009,
      "version": 1,
      "versionNonce": 20009,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "97",
      "originalText": "97",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-10",
      "type": "text",
      "x": 246.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10010,
      "version": 1,
      "versionNonce": 20010,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "98",
      "originalText": "98",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-11",
      "type": "text",
      "x": 308.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10011,
      "version": 1,
      "versionNonce": 20011,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "99",
      "originalText": "99",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-12",
      "type": "text",
      "x": 364.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10012,
      "version": 1,
      "versionNonce": 20012,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "100",
      "originalText": "100",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-13",
      "type": "text",
      "x": 426.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10013,
      "version": 1,
      "versionNonce": 20013,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "101",
      "originalText": "101",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-14",
      "type": "text",
      "x": 488.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10014,
      "version": 1,
      "versionNonce": 20014,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "102",
      "originalText": "102",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-15",
      "type": "text",
      "x": 550.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10015,
      "version": 1,
      "versionNonce": 20015,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "103",
      "originalText": "103",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-16",
      "type": "text",
      "x": 85.0,
      "y": 386.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10016,
      "version": 1,
      "versionNonce": 20016,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "100",
      "originalText": "100",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-17",
      "type": "rectangle",
      "x": 170.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10017,
      "version": 1,
      "versionNonce": 20017,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-18",
      "type": "line",
      "x": 169.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10018,
      "version": 1,
      "versionNonce": 20018,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-19",
      "type": "text",
      "x": 183.67,
      "y": 378.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10019,
      "version": 1,
      "versionNonce": 20019,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-20",
      "type": "rectangle",
      "x": 232.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10020,
      "version": 1,
      "versionNonce": 20020,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-21",
      "type": "line",
      "x": 231.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10021,
      "version": 1,
      "versionNonce": 20021,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-22",
      "type": "text",
      "x": 245.67,
      "y": 378.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10022,
      "version": 1,
      "versionNonce": 20022,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-23",
      "type": "rectangle",
      "x": 294.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10023,
      "version": 1,
      "versionNonce": 20023,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-24",
      "type": "line",
      "x": 293.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10024,
      "version": 1,
      "versionNonce": 20024,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-25",
      "type": "text",
      "x": 307.67,
      "y": 378.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10025,
      "version": 1,
      "versionNonce": 20025,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-26",
      "type": "rectangle",
      "x": 356.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10026,
      "version": 1,
      "versionNonce": 20026,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-27",
      "type": "line",
      "x": 355.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10027,
      "version": 1,
      "versionNonce": 20027,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-28",
      "type": "text",
      "x": 369.67,
      "y": 378.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10028,
      "version": 1,
      "versionNonce": 20028,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-29",
      "type": "rectangle",
      "x": 418.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10029,
      "version": 1,
      "versionNonce": 20029,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-30",
      "type": "line",
      "x": 417.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10030,
      "version": 1,
      "versionNonce": 20030,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-31",
      "type": "rectangle",
      "x": 480.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10031,
      "version": 1,
      "versionNonce": 20031,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-32",
      "type": "line",
      "x": 479.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10032,
      "version": 1,
      "versionNonce": 20032,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-33",
      "type": "rectangle",
      "x": 542.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10033,
      "version": 1,
      "versionNonce": 20033,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-34",
      "type": "line",
      "x": 541.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10034,
      "version": 1,
      "versionNonce": 20034,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-35",
      "type": "text",
      "x": 85.0,
      "y": 448.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10035,
      "version": 1,
      "versionNonce": 20035,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "101",
      "originalText": "101",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-36",
      "type": "rectangle",
      "x": 170.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10036,
      "version": 1,
      "versionNonce": 20036,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-37",
      "type": "line",
      "x": 169.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10037,
      "version": 1,
      "versionNonce": 20037,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-38",
      "type": "rectangle",
      "x": 232.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10038,
      "version": 1,
      "versionNonce": 20038,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-39",
      "type": "line",
      "x": 231.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10039,
      "version": 1,
      "versionNonce": 20039,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-40",
      "type": "text",
      "x": 245.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10040,
      "version": 1,
      "versionNonce": 20040,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-41",
      "type": "rectangle",
      "x": 294.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10041,
      "version": 1,
      "versionNonce": 20041,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-42",
      "type": "line",
      "x": 293.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10042,
      "version": 1,
      "versionNonce": 20042,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-43",
      "type": "text",
      "x": 307.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10043,
      "version": 1,
      "versionNonce": 20043,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-44",
      "type": "rectangle",
      "x": 356.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10044,
      "version": 1,
      "versionNonce": 20044,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-45",
      "type": "line",
      "x": 355.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10045,
      "version": 1,
      "versionNonce": 20045,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-46",
      "type": "text",
      "x": 369.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10046,
      "version": 1,
      "versionNonce": 20046,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-47",
      "type": "rectangle",
      "x": 418.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10047,
      "version": 1,
      "versionNonce": 20047,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-48",
      "type": "line",
      "x": 417.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10048,
      "version": 1,
      "versionNonce": 20048,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-49",
      "type": "text",
      "x": 431.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10049,
      "version": 1,
      "versionNonce": 20049,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-50",
      "type": "rectangle",
      "x": 480.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10050,
      "version": 1,
      "versionNonce": 20050,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-51",
      "type": "line",
      "x": 479.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10051,
      "version": 1,
      "versionNonce": 20051,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-52",
      "type": "rectangle",
      "x": 542.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10052,
      "version": 1,
      "versionNonce": 20052,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-53",
      "type": "line",
      "x": 541.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10053,
      "version": 1,
      "versionNonce": 20053,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-54",
      "type": "text",
      "x": 85.0,
      "y": 510.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10054,
      "version": 1,
      "versionNonce": 20054,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "102",
      "originalText": "102",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-55",
      "type": "rectangle",
      "x": 170.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10055,
      "version": 1,
      "versionNonce": 20055,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-56",
      "type": "line",
      "x": 169.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10056,
      "version": 1,
      "versionNonce": 20056,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-57",
      "type": "rectangle",
      "x": 232.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10057,
      "version": 1,
      "versionNonce": 20057,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-58",
      "type": "line",
      "x": 231.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10058,
      "version": 1,
      "versionNonce": 20058,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-59",
      "type": "rectangle",
      "x": 294.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10059,
      "version": 1,
      "versionNonce": 20059,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-60",
      "type": "line",
      "x": 293.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10060,
      "version": 1,
      "versionNonce": 20060,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-61",
      "type": "text",
      "x": 307.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10061,
      "version": 1,
      "versionNonce": 20061,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-62",
      "type": "rectangle",
      "x": 356.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10062,
      "version": 1,
      "versionNonce": 20062,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-63",
      "type": "line",
      "x": 355.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10063,
      "version": 1,
      "versionNonce": 20063,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-64",
      "type": "text",
      "x": 369.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10064,
      "version": 1,
      "versionNonce": 20064,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-65",
      "type": "rectangle",
      "x": 418.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10065,
      "version": 1,
      "versionNonce": 20065,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-66",
      "type": "line",
      "x": 417.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10066,
      "version": 1,
      "versionNonce": 20066,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-67",
      "type": "text",
      "x": 431.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10067,
      "version": 1,
      "versionNonce": 20067,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-68",
      "type": "rectangle",
      "x": 480.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10068,
      "version": 1,
      "versionNonce": 20068,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-69",
      "type": "line",
      "x": 479.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10069,
      "version": 1,
      "versionNonce": 20069,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-70",
      "type": "text",
      "x": 493.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10070,
      "version": 1,
      "versionNonce": 20070,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-71",
      "type": "rectangle",
      "x": 542.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10071,
      "version": 1,
      "versionNonce": 20071,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-72",
      "type": "line",
      "x": 541.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10072,
      "version": 1,
      "versionNonce": 20072,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-73",
      "type": "text",
      "x": 85.0,
      "y": 572.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10073,
      "version": 1,
      "versionNonce": 20073,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "103",
      "originalText": "103",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-74",
      "type": "rectangle",
      "x": 170.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10074,
      "version": 1,
      "versionNonce": 20074,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-75",
      "type": "line",
      "x": 169.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10075,
      "version": 1,
      "versionNonce": 20075,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-76",
      "type": "rectangle",
      "x": 232.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10076,
      "version": 1,
      "versionNonce": 20076,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-77",
      "type": "line",
      "x": 231.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10077,
      "version": 1,
      "versionNonce": 20077,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-78",
      "type": "rectangle",
      "x": 294.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10078,
      "version": 1,
      "versionNonce": 20078,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-79",
      "type": "line",
      "x": 293.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10079,
      "version": 1,
      "versionNonce": 20079,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-80",
      "type": "rectangle",
      "x": 356.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10080,
      "version": 1,
      "versionNonce": 20080,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-81",
      "type": "line",
      "x": 355.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10081,
      "version": 1,
      "versionNonce": 20081,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-82",
      "type": "text",
      "x": 369.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10082,
      "version": 1,
      "versionNonce": 20082,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-83",
      "type": "rectangle",
      "x": 418.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10083,
      "version": 1,
      "versionNonce": 20083,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-84",
      "type": "line",
      "x": 417.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10084,
      "version": 1,
      "versionNonce": 20084,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-85",
      "type": "text",
      "x": 431.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10085,
      "version": 1,
      "versionNonce": 20085,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-86",
      "type": "rectangle",
      "x": 480.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10086,
      "version": 1,
      "versionNonce": 20086,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-87",
      "type": "line",
      "x": 479.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10087,
      "version": 1,
      "versionNonce": 20087,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-88",
      "type": "text",
      "x": 493.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10088,
      "version": 1,
      "versionNonce": 20088,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-89",
      "type": "rectangle",
      "x": 542.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10089,
      "version": 1,
      "versionNonce": 20089,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-90",
      "type": "line",
      "x": 541.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10090,
      "version": 1,
      "versionNonce": 20090,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-91",
      "type": "text",
      "x": 555.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10091,
      "version": 1,
      "versionNonce": 20091,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-92",
      "type": "text",
      "x": 236.0,
      "y": 642.9,
      "width": 278.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10092,
      "version": 1,
      "versionNonce": 20092,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "[max(0, i-W+1), i]",
      "originalText": "[max(0, i-W+1), i]",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-bounded-replay-mask-93",
      "type": "text",
      "x": 982.67,
      "y": 240.5,
      "width": 260.0,
      "height": 47.25,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10093,
      "version": 1,
      "versionNonce": 20093,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "Bounded Replay",
      "originalText": "Bounded Replay",
      "fontSize": 35.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 35.0
    },
    {
      "id": "03-bounded-replay-mask-94",
      "type": "text",
      "x": 979.33,
      "y": 292.3,
      "width": 268.0,
      "height": 31.05,
      "angle": 0,
      "strokeColor": "#396e9b",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10094,
      "version": 1,
      "versionNonce": 20094,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "列：Key / Value 位置 j",
      "originalText": "列：Key / Value 位置 j",
      "fontSize": 23.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 23.0
    },
    {
      "id": "03-bounded-replay-mask-95",
      "type": "text",
      "x": 800.67,
      "y": 326.9,
      "width": 78.0,
      "height": 25.650000000000002,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10095,
      "version": 1,
      "versionNonce": 20095,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "Query i",
      "originalText": "Query i",
      "fontSize": 19.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 19.0
    },
    {
      "id": "03-bounded-replay-mask-96",
      "type": "text",
      "x": 820.67,
      "y": 350.8,
      "width": 53.0,
      "height": 24.3,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10096,
      "version": 1,
      "versionNonce": 20096,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "行 ↓",
      "originalText": "行 ↓",
      "fontSize": 18.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 18.0
    },
    {
      "id": "03-bounded-replay-mask-97",
      "type": "text",
      "x": 934.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10097,
      "version": 1,
      "versionNonce": 20097,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "97",
      "originalText": "97",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-98",
      "type": "text",
      "x": 996.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10098,
      "version": 1,
      "versionNonce": 20098,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "98",
      "originalText": "98",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-99",
      "type": "text",
      "x": 1058.33,
      "y": 331.5,
      "width": 34.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10099,
      "version": 1,
      "versionNonce": 20099,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "99",
      "originalText": "99",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-100",
      "type": "text",
      "x": 1114.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10100,
      "version": 1,
      "versionNonce": 20100,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "100",
      "originalText": "100",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-101",
      "type": "text",
      "x": 1176.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10101,
      "version": 1,
      "versionNonce": 20101,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "101",
      "originalText": "101",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-102",
      "type": "text",
      "x": 1238.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10102,
      "version": 1,
      "versionNonce": 20102,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "102",
      "originalText": "102",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-103",
      "type": "text",
      "x": 1300.0,
      "y": 331.5,
      "width": 47.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10103,
      "version": 1,
      "versionNonce": 20103,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "103",
      "originalText": "103",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-104",
      "type": "text",
      "x": 835.0,
      "y": 386.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10104,
      "version": 1,
      "versionNonce": 20104,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "100",
      "originalText": "100",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-105",
      "type": "rectangle",
      "x": 920.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10105,
      "version": 1,
      "versionNonce": 20105,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-106",
      "type": "line",
      "x": 919.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10106,
      "version": 1,
      "versionNonce": 20106,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-107",
      "type": "line",
      "x": 936.13,
      "y": 385.85,
      "width": 20.75,
      "height": 18.879999999999995,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10107,
      "version": 1,
      "versionNonce": 20107,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          20.75,
          18.879999999999995
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-108",
      "type": "line",
      "x": 937.04,
      "y": 385.36,
      "width": 20.31000000000006,
      "height": 18.71999999999997,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10108,
      "version": 1,
      "versionNonce": 20108,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          20.31000000000006,
          0.0
        ],
        [
          0.0,
          18.71999999999997
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-109",
      "type": "rectangle",
      "x": 982.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10109,
      "version": 1,
      "versionNonce": 20109,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-110",
      "type": "line",
      "x": 981.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10110,
      "version": 1,
      "versionNonce": 20110,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-111",
      "type": "line",
      "x": 999.54,
      "y": 385.97,
      "width": 18.83000000000004,
      "height": 18.089999999999975,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10111,
      "version": 1,
      "versionNonce": 20111,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          18.83000000000004,
          18.089999999999975
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-112",
      "type": "line",
      "x": 999.08,
      "y": 385.05,
      "width": 19.309999999999945,
      "height": 19.029999999999973,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10112,
      "version": 1,
      "versionNonce": 20112,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          19.309999999999945,
          0.0
        ],
        [
          0.0,
          19.029999999999973
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-113",
      "type": "rectangle",
      "x": 1044.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10113,
      "version": 1,
      "versionNonce": 20113,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-114",
      "type": "line",
      "x": 1043.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10114,
      "version": 1,
      "versionNonce": 20114,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-115",
      "type": "line",
      "x": 1060.66,
      "y": 384.81,
      "width": 21.220000000000027,
      "height": 19.379999999999995,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10115,
      "version": 1,
      "versionNonce": 20115,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          21.220000000000027,
          19.379999999999995
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-116",
      "type": "line",
      "x": 1060.89,
      "y": 385.33,
      "width": 19.279999999999973,
      "height": 18.819999999999993,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10116,
      "version": 1,
      "versionNonce": 20116,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          19.279999999999973,
          0.0
        ],
        [
          0.0,
          18.819999999999993
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-117",
      "type": "rectangle",
      "x": 1106.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10117,
      "version": 1,
      "versionNonce": 20117,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-118",
      "type": "line",
      "x": 1105.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10118,
      "version": 1,
      "versionNonce": 20118,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-119",
      "type": "text",
      "x": 1119.67,
      "y": 378.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10119,
      "version": 1,
      "versionNonce": 20119,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-120",
      "type": "rectangle",
      "x": 1168.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10120,
      "version": 1,
      "versionNonce": 20120,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-121",
      "type": "line",
      "x": 1167.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10121,
      "version": 1,
      "versionNonce": 20121,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-122",
      "type": "rectangle",
      "x": 1230.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10122,
      "version": 1,
      "versionNonce": 20122,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-123",
      "type": "line",
      "x": 1229.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10123,
      "version": 1,
      "versionNonce": 20123,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-124",
      "type": "rectangle",
      "x": 1292.0,
      "y": 370.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10124,
      "version": 1,
      "versionNonce": 20124,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-125",
      "type": "line",
      "x": 1291.0,
      "y": 368.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10125,
      "version": 1,
      "versionNonce": 20125,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-126",
      "type": "text",
      "x": 835.0,
      "y": 448.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10126,
      "version": 1,
      "versionNonce": 20126,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "101",
      "originalText": "101",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-127",
      "type": "rectangle",
      "x": 920.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10127,
      "version": 1,
      "versionNonce": 20127,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-128",
      "type": "line",
      "x": 919.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10128,
      "version": 1,
      "versionNonce": 20128,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-129",
      "type": "rectangle",
      "x": 982.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10129,
      "version": 1,
      "versionNonce": 20129,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-130",
      "type": "line",
      "x": 981.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10130,
      "version": 1,
      "versionNonce": 20130,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-131",
      "type": "line",
      "x": 998.41,
      "y": 446.71,
      "width": 21.340000000000032,
      "height": 20.03000000000003,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10131,
      "version": 1,
      "versionNonce": 20131,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          21.340000000000032,
          20.03000000000003
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-132",
      "type": "line",
      "x": 999.31,
      "y": 447.11,
      "width": 20.160000000000082,
      "height": 19.00999999999999,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10132,
      "version": 1,
      "versionNonce": 20132,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          20.160000000000082,
          0.0
        ],
        [
          0.0,
          19.00999999999999
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-133",
      "type": "rectangle",
      "x": 1044.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10133,
      "version": 1,
      "versionNonce": 20133,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-134",
      "type": "line",
      "x": 1043.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10134,
      "version": 1,
      "versionNonce": 20134,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-135",
      "type": "line",
      "x": 1060.17,
      "y": 446.3,
      "width": 20.649999999999864,
      "height": 19.80000000000001,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10135,
      "version": 1,
      "versionNonce": 20135,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          20.649999999999864,
          19.80000000000001
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-136",
      "type": "line",
      "x": 1060.33,
      "y": 447.35,
      "width": 20.420000000000073,
      "height": 19.039999999999964,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10136,
      "version": 1,
      "versionNonce": 20136,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          20.420000000000073,
          0.0
        ],
        [
          0.0,
          19.039999999999964
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-137",
      "type": "rectangle",
      "x": 1106.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10137,
      "version": 1,
      "versionNonce": 20137,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-138",
      "type": "line",
      "x": 1105.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10138,
      "version": 1,
      "versionNonce": 20138,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-139",
      "type": "text",
      "x": 1119.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10139,
      "version": 1,
      "versionNonce": 20139,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-140",
      "type": "rectangle",
      "x": 1168.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10140,
      "version": 1,
      "versionNonce": 20140,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-141",
      "type": "line",
      "x": 1167.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10141,
      "version": 1,
      "versionNonce": 20141,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-142",
      "type": "text",
      "x": 1181.67,
      "y": 440.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10142,
      "version": 1,
      "versionNonce": 20142,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-143",
      "type": "rectangle",
      "x": 1230.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10143,
      "version": 1,
      "versionNonce": 20143,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-144",
      "type": "line",
      "x": 1229.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10144,
      "version": 1,
      "versionNonce": 20144,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-145",
      "type": "rectangle",
      "x": 1292.0,
      "y": 432.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10145,
      "version": 1,
      "versionNonce": 20145,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-146",
      "type": "line",
      "x": 1291.0,
      "y": 430.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10146,
      "version": 1,
      "versionNonce": 20146,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-147",
      "type": "text",
      "x": 835.0,
      "y": 510.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10147,
      "version": 1,
      "versionNonce": 20147,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "102",
      "originalText": "102",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-148",
      "type": "rectangle",
      "x": 920.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10148,
      "version": 1,
      "versionNonce": 20148,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-149",
      "type": "line",
      "x": 919.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10149,
      "version": 1,
      "versionNonce": 20149,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-150",
      "type": "rectangle",
      "x": 982.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10150,
      "version": 1,
      "versionNonce": 20150,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-151",
      "type": "line",
      "x": 981.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10151,
      "version": 1,
      "versionNonce": 20151,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-152",
      "type": "rectangle",
      "x": 1044.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10152,
      "version": 1,
      "versionNonce": 20152,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-153",
      "type": "line",
      "x": 1043.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10153,
      "version": 1,
      "versionNonce": 20153,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-154",
      "type": "line",
      "x": 1061.94,
      "y": 509.4,
      "width": 19.269999999999982,
      "height": 20.430000000000064,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10154,
      "version": 1,
      "versionNonce": 20154,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          19.269999999999982,
          20.430000000000064
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-155",
      "type": "line",
      "x": 1061.59,
      "y": 508.66,
      "width": 19.420000000000073,
      "height": 19.46999999999997,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10155,
      "version": 1,
      "versionNonce": 20155,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          19.420000000000073,
          0.0
        ],
        [
          0.0,
          19.46999999999997
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-156",
      "type": "rectangle",
      "x": 1106.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10156,
      "version": 1,
      "versionNonce": 20156,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-157",
      "type": "line",
      "x": 1105.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10157,
      "version": 1,
      "versionNonce": 20157,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-158",
      "type": "text",
      "x": 1119.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10158,
      "version": 1,
      "versionNonce": 20158,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-159",
      "type": "rectangle",
      "x": 1168.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10159,
      "version": 1,
      "versionNonce": 20159,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-160",
      "type": "line",
      "x": 1167.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10160,
      "version": 1,
      "versionNonce": 20160,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-161",
      "type": "text",
      "x": 1181.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10161,
      "version": 1,
      "versionNonce": 20161,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-162",
      "type": "rectangle",
      "x": 1230.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10162,
      "version": 1,
      "versionNonce": 20162,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-163",
      "type": "line",
      "x": 1229.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10163,
      "version": 1,
      "versionNonce": 20163,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-164",
      "type": "text",
      "x": 1243.67,
      "y": 502.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10164,
      "version": 1,
      "versionNonce": 20164,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-165",
      "type": "rectangle",
      "x": 1292.0,
      "y": 494.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10165,
      "version": 1,
      "versionNonce": 20165,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-166",
      "type": "line",
      "x": 1291.0,
      "y": 492.8,
      "width": 56.0,
      "height": 52.19999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10166,
      "version": 1,
      "versionNonce": 20166,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.1999999999999886
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.1999999999999886
        ],
        [
          56.0,
          26.19999999999999
        ],
        [
          55.0,
          51.19999999999999
        ],
        [
          28.0,
          52.19999999999999
        ],
        [
          1.0,
          51.19999999999999
        ],
        [
          0.0,
          26.19999999999999
        ],
        [
          1.0,
          1.1999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-167",
      "type": "text",
      "x": 835.0,
      "y": 572.6,
      "width": 47.0,
      "height": 35.1,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10167,
      "version": 1,
      "versionNonce": 20167,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "103",
      "originalText": "103",
      "fontSize": 26.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 26.0
    },
    {
      "id": "03-bounded-replay-mask-168",
      "type": "rectangle",
      "x": 920.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10168,
      "version": 1,
      "versionNonce": 20168,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-169",
      "type": "line",
      "x": 919.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10169,
      "version": 1,
      "versionNonce": 20169,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-170",
      "type": "rectangle",
      "x": 982.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10170,
      "version": 1,
      "versionNonce": 20170,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-171",
      "type": "line",
      "x": 981.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10171,
      "version": 1,
      "versionNonce": 20171,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-172",
      "type": "rectangle",
      "x": 1044.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#f0eef1",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10172,
      "version": 1,
      "versionNonce": 20172,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-173",
      "type": "line",
      "x": 1043.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10173,
      "version": 1,
      "versionNonce": 20173,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-174",
      "type": "rectangle",
      "x": 1106.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10174,
      "version": 1,
      "versionNonce": 20174,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-175",
      "type": "line",
      "x": 1105.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10175,
      "version": 1,
      "versionNonce": 20175,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-176",
      "type": "text",
      "x": 1119.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10176,
      "version": 1,
      "versionNonce": 20176,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-177",
      "type": "rectangle",
      "x": 1168.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10177,
      "version": 1,
      "versionNonce": 20177,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-178",
      "type": "line",
      "x": 1167.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10178,
      "version": 1,
      "versionNonce": 20178,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-179",
      "type": "text",
      "x": 1181.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10179,
      "version": 1,
      "versionNonce": 20179,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-180",
      "type": "rectangle",
      "x": 1230.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10180,
      "version": 1,
      "versionNonce": 20180,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-181",
      "type": "line",
      "x": 1229.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10181,
      "version": 1,
      "versionNonce": 20181,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-182",
      "type": "text",
      "x": 1243.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10182,
      "version": 1,
      "versionNonce": 20182,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-183",
      "type": "rectangle",
      "x": 1292.0,
      "y": 556.0,
      "width": 54.0,
      "height": 50.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10183,
      "version": 1,
      "versionNonce": 20183,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-184",
      "type": "line",
      "x": 1291.0,
      "y": 554.8,
      "width": 56.0,
      "height": 52.200000000000045,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10184,
      "version": 1,
      "versionNonce": 20184,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0,
          1.2000000000000455
        ],
        [
          28.0,
          0.0
        ],
        [
          55.0,
          1.2000000000000455
        ],
        [
          56.0,
          26.200000000000045
        ],
        [
          55.0,
          51.200000000000045
        ],
        [
          28.0,
          52.200000000000045
        ],
        [
          1.0,
          51.200000000000045
        ],
        [
          0.0,
          26.200000000000045
        ],
        [
          1.0,
          1.2000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-185",
      "type": "text",
      "x": 1305.67,
      "y": 564.7,
      "width": 35.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10185,
      "version": 1,
      "versionNonce": 20185,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "●",
      "originalText": "●",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-bounded-replay-mask-186",
      "type": "text",
      "x": 986.0,
      "y": 642.9,
      "width": 278.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10186,
      "version": 1,
      "versionNonce": 20186,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "[max(s, i-W+1), i]",
      "originalText": "[max(s, i-W+1), i]",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-bounded-replay-mask-187",
      "type": "line",
      "x": 1100.8,
      "y": 361.39,
      "width": 0.5800000000001546,
      "height": 257.43000000000006,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.0,
      "strokeStyle": "dashed",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10187,
      "version": 1,
      "versionNonce": 20187,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.5800000000001546,
          0.0
        ],
        [
          0.0,
          257.43000000000006
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-188",
      "type": "text",
      "x": 1105.0,
      "y": 687.3,
      "width": 68.0,
      "height": 31.05,
      "angle": 0,
      "strokeColor": "#a65b61",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10188,
      "version": 1,
      "versionNonce": 20188,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "s=100",
      "originalText": "s=100",
      "fontSize": 23.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 23.0
    },
    {
      "id": "03-bounded-replay-mask-189",
      "type": "line",
      "x": 694.87,
      "y": 476.8,
      "width": 110.58000000000004,
      "height": 0.6299999999999955,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 4.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10189,
      "version": 1,
      "versionNonce": 20189,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.6299999999999955
        ],
        [
          110.58000000000004,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-190",
      "type": "line",
      "x": 792.69,
      "y": 471.03,
      "width": 12.43999999999994,
      "height": 11.840000000000032,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 4.0,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10190,
      "version": 1,
      "versionNonce": 20190,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.509999999999991,
          11.840000000000032
        ],
        [
          12.43999999999994,
          6.7900000000000205
        ],
        [
          0.0,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-191",
      "type": "text",
      "x": 711.0,
      "y": 408.4,
      "width": 80.0,
      "height": 32.400000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10191,
      "version": 1,
      "versionNonce": 20191,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "只截断",
      "originalText": "只截断",
      "fontSize": 24.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 24.0
    },
    {
      "id": "03-bounded-replay-mask-192",
      "type": "text",
      "x": 699.0,
      "y": 441.4,
      "width": 104.0,
      "height": 32.400000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10192,
      "version": 1,
      "versionNonce": 20192,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "局部分支",
      "originalText": "局部分支",
      "fontSize": 24.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 24.0
    },
    {
      "id": "03-bounded-replay-mask-193",
      "type": "text",
      "x": 384.0,
      "y": 740.8,
      "width": 736.0,
      "height": 37.800000000000004,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10193,
      "version": 1,
      "versionNonce": 20193,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "4 行 = 4 个 Query 位置；回放仍经过相关层组的全部层。",
      "originalText": "4 行 = 4 个 Query 位置；回放仍经过相关层组的全部层。",
      "fontSize": 28.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 28.0
    },
    {
      "id": "03-bounded-replay-mask-194",
      "type": "rectangle",
      "x": 180.0,
      "y": 800.0,
      "width": 1240.0,
      "height": 59.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#eaf1fa",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10194,
      "version": 1,
      "versionNonce": 20194,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-bounded-replay-mask-195",
      "type": "line",
      "x": 178.69,
      "y": 798.33,
      "width": 1242.27,
      "height": 61.08999999999992,
      "angle": 0,
      "strokeColor": "#396e9b",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10195,
      "version": 1,
      "versionNonce": 20195,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.6299999999999955,
          0.8899999999999864
        ],
        [
          620.53,
          0.0
        ],
        [
          1242.27,
          2.3099999999999454
        ],
        [
          1241.7,
          31.399999999999977
        ],
        [
          1240.6499999999999,
          60.95999999999992
        ],
        [
          620.55,
          61.08999999999992
        ],
        [
          0.9200000000000159,
          61.049999999999955
        ],
        [
          0.0,
          31.25999999999999
        ],
        [
          1.1899999999999977,
          1.8099999999999454
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-196",
      "type": "line",
      "x": 181.85,
      "y": 798.56,
      "width": 1237.93,
      "height": 59.5,
      "angle": 0,
      "strokeColor": "#396e9b",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10196,
      "version": 1,
      "versionNonce": 20196,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          1237.5900000000001,
          2.82000000000005
        ],
        [
          1237.93,
          59.5
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-197",
      "type": "text",
      "x": 380.0,
      "y": 820.5,
      "width": 698.0,
      "height": 33.75,
      "angle": 0,
      "strokeColor": "#396e9b",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10197,
      "version": 1,
      "versionNonce": 20197,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "全局历史访问遵守因果与稀疏规则；各层 SWA 使用右侧截断。",
      "originalText": "全局历史访问遵守因果与稀疏规则；各层 SWA 使用右侧截断。",
      "fontSize": 25.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 25.0
    },
    {
      "id": "03-bounded-replay-mask-198",
      "type": "line",
      "x": 77.69,
      "y": 869.1,
      "width": 1441.74,
      "height": 1.5499999999999545,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10198,
      "version": 1,
      "versionNonce": 20198,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          1441.74,
          1.5499999999999545
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-bounded-replay-mask-199",
      "type": "text",
      "x": 80.0,
      "y": 894.9,
      "width": 1026.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10199,
      "version": 1,
      "versionNonce": 20199,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "记住：这是 mask 示意，不是层数图，也不是完整回放流程或实际注意力权重。",
      "originalText": "记住：这是 mask 示意，不是层数图，也不是完整回放流程或实际注意力权重。",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-bounded-replay-mask-200",
      "type": "text",
      "x": 80.0,
      "y": 958.1,
      "width": 788.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10200,
      "version": 1,
      "versionNonce": 20200,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "论文 §3.2.2，p.20；说明性例 W=4，模型实际 W=128；图中坐标均为 token 位置",
      "originalText": "论文 §3.2.2，p.20；说明性例 W=4，模型实际 W=128；图中坐标均为 token 位置",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    }
  ],
  "appState": {
    "viewBackgroundColor": "#fffefb",
    "gridSize": null
  },
  "files": {}
}
```
%%
