---
excalidraw-plugin: parsed
tags:
  - excalidraw
---

# Excalidraw Data

## Text Elements

03  /  SWA BOUNDED REPLAY ^03-layer-dependency-1

一个小窗口，为什么会依赖很远？ ^03-layer-dependency-2

每层看一个局部窗；多层叠加后，依赖路径向过去展开 ^03-layer-dependency-3

第 3 层 ^03-layer-dependency-53

第 2 层 ^03-layer-dependency-75

第 1 层 ^03-layer-dependency-100

输入 ^03-layer-dependency-128

i−9 ^03-layer-dependency-132

i−8 ^03-layer-dependency-136

i−7 ^03-layer-dependency-140

i−6 ^03-layer-dependency-144

i−5 ^03-layer-dependency-148

i−4 ^03-layer-dependency-152

i−3 ^03-layer-dependency-156

i−2 ^03-layer-dependency-160

i−1 ^03-layer-dependency-164

i ^03-layer-dependency-168

1 个位置 ^03-layer-dependency-169

4 个位置 ^03-layer-dependency-170

7 个位置 ^03-layer-dependency-171

10 个位置 ^03-layer-dependency-172

说明性推导：R(d) = 1 + d × (W-1)；此处 W=4，d=3。 ^03-layer-dependency-173

记住：理论可达范围随深度增长；恢复高层 KV 不能只看最后一层的窗口。 ^03-layer-dependency-175

论文 §2.2、§3.2.2，pp.9、20；W=4 的纯局部路径说明性示例 ^03-layer-dependency-176

%%
## Drawing

```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [
    {
      "id": "03-layer-dependency-1",
      "type": "text",
      "x": 76.0,
      "y": 44.2,
      "width": 283.0,
      "height": 29.700000000000003,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10001,
      "version": 1,
      "versionNonce": 20001,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "03  /  SWA BOUNDED REPLAY",
      "originalText": "03  /  SWA BOUNDED REPLAY",
      "fontSize": 22.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 22.0
    },
    {
      "id": "03-layer-dependency-2",
      "type": "text",
      "x": 76.0,
      "y": 90.1,
      "width": 773.0,
      "height": 68.85000000000001,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10002,
      "version": 1,
      "versionNonce": 20002,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "一个小窗口，为什么会依赖很远？",
      "originalText": "一个小窗口，为什么会依赖很远？",
      "fontSize": 51.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 51.0
    },
    {
      "id": "03-layer-dependency-3",
      "type": "text",
      "x": 79.0,
      "y": 155.7,
      "width": 656.0,
      "height": 36.45,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10003,
      "version": 1,
      "versionNonce": 20003,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "每层看一个局部窗；多层叠加后，依赖路径向过去展开",
      "originalText": "每层看一个局部窗；多层叠加后，依赖路径向过去展开",
      "fontSize": 27.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 27.0
    },
    {
      "id": "03-layer-dependency-4",
      "type": "line",
      "x": 77.58,
      "y": 204.85,
      "width": 1441.5900000000001,
      "height": 0.15000000000000568,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10004,
      "version": 1,
      "versionNonce": 20004,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.15000000000000568
        ],
        [
          1441.5900000000001,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-5",
      "type": "line",
      "x": 883.0,
      "y": 326.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10005,
      "version": 1,
      "versionNonce": 20005,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-6",
      "type": "line",
      "x": 984.0,
      "y": 326.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10006,
      "version": 1,
      "versionNonce": 20006,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-7",
      "type": "line",
      "x": 1085.0,
      "y": 326.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10007,
      "version": 1,
      "versionNonce": 20007,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-8",
      "type": "line",
      "x": 1186.0,
      "y": 326.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10008,
      "version": 1,
      "versionNonce": 20008,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-9",
      "type": "line",
      "x": 580.0,
      "y": 456.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10009,
      "version": 1,
      "versionNonce": 20009,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-10",
      "type": "line",
      "x": 681.0,
      "y": 456.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10010,
      "version": 1,
      "versionNonce": 20010,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-11",
      "type": "line",
      "x": 782.0,
      "y": 456.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10011,
      "version": 1,
      "versionNonce": 20011,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-12",
      "type": "line",
      "x": 883.0,
      "y": 456.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10012,
      "version": 1,
      "versionNonce": 20012,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-13",
      "type": "line",
      "x": 681.0,
      "y": 456.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10013,
      "version": 1,
      "versionNonce": 20013,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-14",
      "type": "line",
      "x": 782.0,
      "y": 456.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10014,
      "version": 1,
      "versionNonce": 20014,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-15",
      "type": "line",
      "x": 883.0,
      "y": 456.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10015,
      "version": 1,
      "versionNonce": 20015,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-16",
      "type": "line",
      "x": 984.0,
      "y": 456.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10016,
      "version": 1,
      "versionNonce": 20016,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-17",
      "type": "line",
      "x": 782.0,
      "y": 456.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10017,
      "version": 1,
      "versionNonce": 20017,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-18",
      "type": "line",
      "x": 883.0,
      "y": 456.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10018,
      "version": 1,
      "versionNonce": 20018,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-19",
      "type": "line",
      "x": 984.0,
      "y": 456.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10019,
      "version": 1,
      "versionNonce": 20019,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-20",
      "type": "line",
      "x": 1085.0,
      "y": 456.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10020,
      "version": 1,
      "versionNonce": 20020,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-21",
      "type": "line",
      "x": 883.0,
      "y": 456.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10021,
      "version": 1,
      "versionNonce": 20021,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-22",
      "type": "line",
      "x": 984.0,
      "y": 456.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10022,
      "version": 1,
      "versionNonce": 20022,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-23",
      "type": "line",
      "x": 1085.0,
      "y": 456.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10023,
      "version": 1,
      "versionNonce": 20023,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-24",
      "type": "line",
      "x": 1186.0,
      "y": 456.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10024,
      "version": 1,
      "versionNonce": 20024,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-25",
      "type": "line",
      "x": 277.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10025,
      "version": 1,
      "versionNonce": 20025,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-26",
      "type": "line",
      "x": 378.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10026,
      "version": 1,
      "versionNonce": 20026,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-27",
      "type": "line",
      "x": 479.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10027,
      "version": 1,
      "versionNonce": 20027,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-28",
      "type": "line",
      "x": 580.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10028,
      "version": 1,
      "versionNonce": 20028,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-29",
      "type": "line",
      "x": 378.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10029,
      "version": 1,
      "versionNonce": 20029,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-30",
      "type": "line",
      "x": 479.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10030,
      "version": 1,
      "versionNonce": 20030,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-31",
      "type": "line",
      "x": 580.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10031,
      "version": 1,
      "versionNonce": 20031,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-32",
      "type": "line",
      "x": 681.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10032,
      "version": 1,
      "versionNonce": 20032,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-33",
      "type": "line",
      "x": 479.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10033,
      "version": 1,
      "versionNonce": 20033,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-34",
      "type": "line",
      "x": 580.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10034,
      "version": 1,
      "versionNonce": 20034,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-35",
      "type": "line",
      "x": 681.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10035,
      "version": 1,
      "versionNonce": 20035,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-36",
      "type": "line",
      "x": 782.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10036,
      "version": 1,
      "versionNonce": 20036,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-37",
      "type": "line",
      "x": 580.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10037,
      "version": 1,
      "versionNonce": 20037,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-38",
      "type": "line",
      "x": 681.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10038,
      "version": 1,
      "versionNonce": 20038,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-39",
      "type": "line",
      "x": 782.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10039,
      "version": 1,
      "versionNonce": 20039,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-40",
      "type": "line",
      "x": 883.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10040,
      "version": 1,
      "versionNonce": 20040,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-41",
      "type": "line",
      "x": 681.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10041,
      "version": 1,
      "versionNonce": 20041,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-42",
      "type": "line",
      "x": 782.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10042,
      "version": 1,
      "versionNonce": 20042,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-43",
      "type": "line",
      "x": 883.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10043,
      "version": 1,
      "versionNonce": 20043,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-44",
      "type": "line",
      "x": 984.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10044,
      "version": 1,
      "versionNonce": 20044,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-45",
      "type": "line",
      "x": 782.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10045,
      "version": 1,
      "versionNonce": 20045,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-46",
      "type": "line",
      "x": 883.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10046,
      "version": 1,
      "versionNonce": 20046,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-47",
      "type": "line",
      "x": 984.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10047,
      "version": 1,
      "versionNonce": 20047,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-48",
      "type": "line",
      "x": 1085.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10048,
      "version": 1,
      "versionNonce": 20048,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-49",
      "type": "line",
      "x": 883.0,
      "y": 586.0,
      "width": 303.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10049,
      "version": 1,
      "versionNonce": 20049,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          303.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-50",
      "type": "line",
      "x": 984.0,
      "y": 586.0,
      "width": 202.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10050,
      "version": 1,
      "versionNonce": 20050,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          202.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-51",
      "type": "line",
      "x": 1085.0,
      "y": 586.0,
      "width": 101.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10051,
      "version": 1,
      "versionNonce": 20051,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          101.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-52",
      "type": "line",
      "x": 1186.0,
      "y": 586.0,
      "width": 0.0,
      "height": 92.0,
      "angle": 0,
      "strokeColor": "#c5bfd0",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.8,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10052,
      "version": 1,
      "versionNonce": 20052,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          0.0,
          92.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-53",
      "type": "text",
      "x": 90.0,
      "y": 298.0,
      "width": 113.0,
      "height": 40.5,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10053,
      "version": 1,
      "versionNonce": 20053,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "第 3 层",
      "originalText": "第 3 层",
      "fontSize": 30.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 30.0
    },
    {
      "id": "03-layer-dependency-54",
      "type": "line",
      "x": 248.47,
      "y": 282.34,
      "width": 56.29999999999998,
      "height": 50.39000000000004,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10054,
      "version": 1,
      "versionNonce": 20054,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.6400000000000148,
          1.25
        ],
        [
          28.92999999999998,
          0.0
        ],
        [
          54.92999999999998,
          2.0500000000000114
        ],
        [
          55.54999999999998,
          25.380000000000052
        ],
        [
          56.29999999999998,
          48.72000000000003
        ],
        [
          29.210000000000008,
          50.39000000000004
        ],
        [
          1.5,
          49.900000000000034
        ],
        [
          0.0,
          24.689999999999998
        ],
        [
          0.6899999999999977,
          1.0900000000000318
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-55",
      "type": "line",
      "x": 252.53,
      "y": 282.16,
      "width": 51.91999999999999,
      "height": 49.64999999999998,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10055,
      "version": 1,
      "versionNonce": 20055,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.91999999999999,
          2.8699999999999477
        ],
        [
          49.900000000000006,
          49.64999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-56",
      "type": "line",
      "x": 350.46,
      "y": 281.82,
      "width": 56.31999999999999,
      "height": 50.900000000000034,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10056,
      "version": 1,
      "versionNonce": 20056,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.28000000000002956,
          2.8500000000000227
        ],
        [
          28.230000000000018,
          0.0
        ],
        [
          55.450000000000045,
          2.0500000000000114
        ],
        [
          56.31999999999999,
          26.840000000000032
        ],
        [
          54.97000000000003,
          49.920000000000016
        ],
        [
          26.99000000000001,
          50.69999999999999
        ],
        [
          0.5200000000000387,
          50.900000000000034
        ],
        [
          0.0,
          25.720000000000027
        ],
        [
          1.1899999999999977,
          1.509999999999991
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-57",
      "type": "line",
      "x": 352.01,
      "y": 282.4,
      "width": 52.49000000000001,
      "height": 49.58000000000004,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10057,
      "version": 1,
      "versionNonce": 20057,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.23000000000002,
          3.07000000000005
        ],
        [
          52.49000000000001,
          49.58000000000004
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-58",
      "type": "line",
      "x": 450.86,
      "y": 282.15,
      "width": 56.69999999999999,
      "height": 51.210000000000036,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10058,
      "version": 1,
      "versionNonce": 20058,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.7699999999999818,
          2.32000000000005
        ],
        [
          27.680000000000007,
          0.0
        ],
        [
          56.06999999999999,
          0.8900000000000432
        ],
        [
          56.69999999999999,
          25.54000000000002
        ],
        [
          54.94,
          50.72000000000003
        ],
        [
          28.039999999999964,
          51.210000000000036
        ],
        [
          0.5,
          50.59000000000003
        ],
        [
          0.0,
          25.260000000000048
        ],
        [
          1.169999999999959,
          2.080000000000041
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-59",
      "type": "line",
      "x": 455.0,
      "y": 283.37,
      "width": 51.589999999999975,
      "height": 48.5,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10059,
      "version": 1,
      "versionNonce": 20059,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.589999999999975,
          2.6100000000000136
        ],
        [
          50.860000000000014,
          48.5
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-60",
      "type": "line",
      "x": 551.67,
      "y": 282.72,
      "width": 55.48000000000002,
      "height": 50.139999999999986,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10060,
      "version": 1,
      "versionNonce": 20060,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.8700000000000045,
          1.4899999999999523
        ],
        [
          29.32000000000005,
          0.0
        ],
        [
          55.48000000000002,
          1.6399999999999864
        ],
        [
          55.379999999999995,
          24.519999999999982
        ],
        [
          55.29000000000008,
          48.96999999999997
        ],
        [
          28.25,
          50.06999999999999
        ],
        [
          1.5500000000000682,
          50.139999999999986
        ],
        [
          0.0,
          24.75
        ],
        [
          1.2300000000000182,
          1.2399999999999523
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-61",
      "type": "line",
      "x": 554.82,
      "y": 282.02,
      "width": 52.3599999999999,
      "height": 48.620000000000005,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10061,
      "version": 1,
      "versionNonce": 20061,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.3599999999999,
          4.740000000000009
        ],
        [
          51.00999999999999,
          48.620000000000005
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-62",
      "type": "line",
      "x": 653.19,
      "y": 282.73,
      "width": 55.65999999999997,
      "height": 50.24000000000001,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10062,
      "version": 1,
      "versionNonce": 20062,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.6899999999999409,
          0.5699999999999932
        ],
        [
          26.839999999999918,
          0.0
        ],
        [
          54.39999999999998,
          1.6200000000000045
        ],
        [
          55.65999999999997,
          25.049999999999955
        ],
        [
          54.539999999999964,
          49.45999999999998
        ],
        [
          28.59999999999991,
          50.14999999999998
        ],
        [
          0.9399999999999409,
          50.24000000000001
        ],
        [
          0.0,
          24.909999999999968
        ],
        [
          0.17999999999994998,
          1.009999999999991
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-63",
      "type": "line",
      "x": 655.12,
      "y": 283.07,
      "width": 52.710000000000036,
      "height": 48.25999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10063,
      "version": 1,
      "versionNonce": 20063,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.710000000000036,
          2.3100000000000023
        ],
        [
          52.23000000000002,
          48.25999999999999
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-64",
      "type": "line",
      "x": 754.19,
      "y": 282.97,
      "width": 55.729999999999905,
      "height": 50.40999999999997,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10064,
      "version": 1,
      "versionNonce": 20064,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.8399999999999181,
          0.5199999999999818
        ],
        [
          27.8599999999999,
          0.0
        ],
        [
          55.729999999999905,
          1.8999999999999773
        ],
        [
          55.67999999999995,
          24.66999999999996
        ],
        [
          55.14999999999998,
          49.349999999999966
        ],
        [
          28.269999999999982,
          50.40999999999997
        ],
        [
          0.7699999999999818,
          48.889999999999986
        ],
        [
          0.0,
          25.399999999999977
        ],
        [
          1.4499999999999318,
          1.6199999999999477
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-65",
      "type": "line",
      "x": 756.05,
      "y": 283.71,
      "width": 53.91000000000008,
      "height": 47.660000000000025,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10065,
      "version": 1,
      "versionNonce": 20065,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          53.91000000000008,
          2.2900000000000205
        ],
        [
          51.460000000000036,
          47.660000000000025
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-66",
      "type": "line",
      "x": 854.14,
      "y": 283.29,
      "width": 57.24000000000001,
      "height": 49.379999999999995,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10066,
      "version": 1,
      "versionNonce": 20066,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.8400000000000318,
          0.5499999999999545
        ],
        [
          29.019999999999982,
          0.0
        ],
        [
          55.200000000000045,
          1.5199999999999818
        ],
        [
          57.24000000000001,
          24.120000000000005
        ],
        [
          56.26999999999998,
          48.48999999999995
        ],
        [
          29.769999999999982,
          49.379999999999995
        ],
        [
          1.75,
          47.94999999999999
        ],
        [
          0.0,
          25.149999999999977
        ],
        [
          2.560000000000059,
          1.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-67",
      "type": "line",
      "x": 857.36,
      "y": 283.42,
      "width": 52.35000000000002,
      "height": 47.31999999999999,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10067,
      "version": 1,
      "versionNonce": 20067,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.35000000000002,
          2.6200000000000045
        ],
        [
          51.92999999999995,
          47.31999999999999
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-68",
      "type": "line",
      "x": 955.43,
      "y": 282.79,
      "width": 56.81000000000006,
      "height": 50.139999999999986,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10068,
      "version": 1,
      "versionNonce": 20068,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          2.2700000000000955,
          0.7899999999999636
        ],
        [
          29.220000000000027,
          0.0
        ],
        [
          55.680000000000064,
          0.4199999999999591
        ],
        [
          56.81000000000006,
          25.41999999999996
        ],
        [
          55.75,
          50.139999999999986
        ],
        [
          28.81000000000006,
          49.98999999999995
        ],
        [
          2.57000000000005,
          48.639999999999986
        ],
        [
          0.0,
          25.060000000000002
        ],
        [
          2.340000000000032,
          0.37000000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-69",
      "type": "line",
      "x": 958.57,
      "y": 283.37,
      "width": 52.42999999999995,
      "height": 47.079999999999984,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10069,
      "version": 1,
      "versionNonce": 20069,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.42999999999995,
          1.9399999999999977
        ],
        [
          50.58999999999992,
          47.079999999999984
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-70",
      "type": "line",
      "x": 1056.73,
      "y": 282.83,
      "width": 55.960000000000036,
      "height": 49.39000000000004,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10070,
      "version": 1,
      "versionNonce": 20070,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.740000000000009,
          0.6500000000000341
        ],
        [
          27.62999999999988,
          0.0
        ],
        [
          55.960000000000036,
          0.5099999999999909
        ],
        [
          55.75999999999999,
          25.03000000000003
        ],
        [
          55.01999999999998,
          49.170000000000016
        ],
        [
          28.190000000000055,
          49.35000000000002
        ],
        [
          0.5699999999999363,
          49.39000000000004
        ],
        [
          0.0,
          25.83000000000004
        ],
        [
          1.0799999999999272,
          1.6999999999999886
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-71",
      "type": "line",
      "x": 1059.63,
      "y": 282.75,
      "width": 52.319999999999936,
      "height": 47.45999999999998,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10071,
      "version": 1,
      "versionNonce": 20071,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.319999999999936,
          2.25
        ],
        [
          50.549999999999955,
          47.45999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-72",
      "type": "rectangle",
      "x": 1159.0,
      "y": 284.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10072,
      "version": 1,
      "versionNonce": 20072,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-73",
      "type": "line",
      "x": 1158.2,
      "y": 283.07,
      "width": 54.98000000000002,
      "height": 50.56,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10073,
      "version": 1,
      "versionNonce": 20073,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.5599999999999454,
          0.0
        ],
        [
          26.940000000000055,
          0.5400000000000205
        ],
        [
          54.00999999999999,
          0.1500000000000341
        ],
        [
          54.919999999999845,
          24.920000000000016
        ],
        [
          54.98000000000002,
          48.920000000000016
        ],
        [
          27.089999999999918,
          50.56
        ],
        [
          0.11999999999989086,
          49.04000000000002
        ],
        [
          0.0,
          25.75
        ],
        [
          0.2899999999999636,
          1.7800000000000296
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-74",
      "type": "line",
      "x": 1161.62,
      "y": 282.47,
      "width": 50.680000000000064,
      "height": 48.31999999999999,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10074,
      "version": 1,
      "versionNonce": 20074,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          50.680000000000064,
          3.2899999999999636
        ],
        [
          50.41000000000008,
          48.31999999999999
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-75",
      "type": "text",
      "x": 90.0,
      "y": 428.0,
      "width": 113.0,
      "height": 40.5,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10075,
      "version": 1,
      "versionNonce": 20075,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "第 2 层",
      "originalText": "第 2 层",
      "fontSize": 30.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 30.0
    },
    {
      "id": "03-layer-dependency-76",
      "type": "line",
      "x": 249.77,
      "y": 412.79,
      "width": 54.53,
      "height": 50.64999999999998,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10076,
      "version": 1,
      "versionNonce": 20076,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.4899999999999807,
          1.3199999999999932
        ],
        [
          27.330000000000013,
          0.0
        ],
        [
          53.53999999999999,
          2.2099999999999795
        ],
        [
          54.53,
          24.789999999999964
        ],
        [
          54.09,
          49.71999999999997
        ],
        [
          26.460000000000008,
          50.64999999999998
        ],
        [
          0.14999999999997726,
          49.289999999999964
        ],
        [
          0.0,
          25.099999999999966
        ],
        [
          1.079999999999984,
          0.6599999999999682
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-77",
      "type": "line",
      "x": 251.99,
      "y": 412.9,
      "width": 51.839999999999975,
      "height": 48.06,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10077,
      "version": 1,
      "versionNonce": 20077,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.839999999999975,
          2.4500000000000455
        ],
        [
          50.94999999999999,
          48.06
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-78",
      "type": "line",
      "x": 349.16,
      "y": 411.84,
      "width": 57.26999999999998,
      "height": 52.14000000000004,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10078,
      "version": 1,
      "versionNonce": 20078,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.7099999999999795,
          1.3500000000000227
        ],
        [
          28.21999999999997,
          0.0
        ],
        [
          55.549999999999955,
          1.330000000000041
        ],
        [
          57.26999999999998,
          26.27000000000004
        ],
        [
          55.00999999999999,
          50.14000000000004
        ],
        [
          28.539999999999964,
          52.14000000000004
        ],
        [
          2.6499999999999773,
          49.30000000000001
        ],
        [
          0.0,
          25.689999999999998
        ],
        [
          2.759999999999991,
          2.5200000000000387
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-79",
      "type": "line",
      "x": 353.98,
      "y": 412.28,
      "width": 51.799999999999955,
      "height": 48.190000000000055,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10079,
      "version": 1,
      "versionNonce": 20079,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.799999999999955,
          2.740000000000009
        ],
        [
          49.66999999999996,
          48.190000000000055
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-80",
      "type": "line",
      "x": 451.22,
      "y": 412.98,
      "width": 56.46999999999997,
      "height": 50.129999999999995,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10080,
      "version": 1,
      "versionNonce": 20080,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          1.349999999999966
        ],
        [
          28.44999999999999,
          0.0
        ],
        [
          54.879999999999995,
          1.6599999999999682
        ],
        [
          56.46999999999997,
          24.439999999999998
        ],
        [
          54.299999999999955,
          49.85999999999996
        ],
        [
          27.42999999999995,
          50.129999999999995
        ],
        [
          0.8299999999999841,
          49.19999999999999
        ],
        [
          0.5099999999999909,
          24.879999999999995
        ],
        [
          0.1099999999999568,
          1.490000000000009
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-81",
      "type": "line",
      "x": 454.83,
      "y": 413.66,
      "width": 52.00999999999999,
      "height": 48.01999999999998,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10081,
      "version": 1,
      "versionNonce": 20081,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.00999999999999,
          1.5199999999999818
        ],
        [
          50.73000000000002,
          48.01999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-82",
      "type": "line",
      "x": 551.05,
      "y": 412.05,
      "width": 56.610000000000014,
      "height": 50.97999999999996,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10082,
      "version": 1,
      "versionNonce": 20082,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          2.7700000000000955,
          2.659999999999968
        ],
        [
          28.0,
          0.0
        ],
        [
          55.91000000000008,
          2.8100000000000023
        ],
        [
          56.610000000000014,
          25.670000000000016
        ],
        [
          55.960000000000036,
          50.39999999999998
        ],
        [
          29.430000000000064,
          50.97999999999996
        ],
        [
          2.8700000000000045,
          49.379999999999995
        ],
        [
          0.0,
          25.829999999999984
        ],
        [
          2.830000000000041,
          2.819999999999993
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-83",
      "type": "line",
      "x": 555.81,
      "y": 413.0,
      "width": 51.05000000000007,
      "height": 47.639999999999986,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10083,
      "version": 1,
      "versionNonce": 20083,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.05000000000007,
          3.910000000000025
        ],
        [
          50.75,
          47.639999999999986
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-84",
      "type": "line",
      "x": 652.74,
      "y": 411.95,
      "width": 57.110000000000014,
      "height": 51.78000000000003,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10084,
      "version": 1,
      "versionNonce": 20084,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.7699999999999818,
          3.0200000000000387
        ],
        [
          28.139999999999986,
          0.0
        ],
        [
          56.139999999999986,
          2.5500000000000114
        ],
        [
          57.110000000000014,
          25.78000000000003
        ],
        [
          54.700000000000045,
          50.170000000000016
        ],
        [
          28.059999999999945,
          51.78000000000003
        ],
        [
          0.7200000000000273,
          49.94999999999999
        ],
        [
          0.0,
          25.75
        ],
        [
          0.3300000000000409,
          2.430000000000007
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-85",
      "type": "line",
      "x": 656.52,
      "y": 412.05,
      "width": 51.23000000000002,
      "height": 48.039999999999964,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10085,
      "version": 1,
      "versionNonce": 20085,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.23000000000002,
          3.819999999999993
        ],
        [
          49.50999999999999,
          48.039999999999964
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-86",
      "type": "line",
      "x": 754.6,
      "y": 413.35,
      "width": 55.57999999999993,
      "height": 49.46999999999997,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10086,
      "version": 1,
      "versionNonce": 20086,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.06999999999999318
        ],
        [
          27.909999999999968,
          0.0
        ],
        [
          54.85000000000002,
          0.8799999999999955
        ],
        [
          55.57999999999993,
          24.75999999999999
        ],
        [
          53.84000000000003,
          48.85999999999996
        ],
        [
          27.360000000000014,
          49.19999999999999
        ],
        [
          0.01999999999998181,
          49.46999999999997
        ],
        [
          0.11000000000001364,
          24.189999999999998
        ],
        [
          1.0599999999999454,
          0.17999999999994998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-87",
      "type": "line",
      "x": 757.94,
      "y": 412.43,
      "width": 50.549999999999955,
      "height": 47.860000000000014,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10087,
      "version": 1,
      "versionNonce": 20087,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          50.43999999999994,
          3.589999999999975
        ],
        [
          50.549999999999955,
          47.860000000000014
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-88",
      "type": "rectangle",
      "x": 856.0,
      "y": 414.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10088,
      "version": 1,
      "versionNonce": 20088,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-89",
      "type": "line",
      "x": 855.17,
      "y": 412.53,
      "width": 55.520000000000095,
      "height": 51.440000000000055,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10089,
      "version": 1,
      "versionNonce": 20089,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.3100000000000591,
          1.1200000000000045
        ],
        [
          26.860000000000014,
          0.0
        ],
        [
          54.31000000000006,
          1.0600000000000023
        ],
        [
          54.83000000000004,
          24.700000000000045
        ],
        [
          55.520000000000095,
          49.33000000000004
        ],
        [
          27.620000000000005,
          51.440000000000055
        ],
        [
          0.05000000000006821,
          49.700000000000045
        ],
        [
          0.0,
          24.950000000000045
        ],
        [
          0.5,
          1.1300000000000523
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-90",
      "type": "line",
      "x": 858.1,
      "y": 412.72,
      "width": 52.57999999999993,
      "height": 49.02999999999997,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10090,
      "version": 1,
      "versionNonce": 20090,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.57999999999993,
          2.319999999999993
        ],
        [
          51.539999999999964,
          49.02999999999997
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-91",
      "type": "rectangle",
      "x": 957.0,
      "y": 414.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10091,
      "version": 1,
      "versionNonce": 20091,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-92",
      "type": "line",
      "x": 955.57,
      "y": 412.04,
      "width": 56.25,
      "height": 51.31999999999999,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10092,
      "version": 1,
      "versionNonce": 20092,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.4799999999999045,
          2.3899999999999864
        ],
        [
          27.449999999999932,
          0.0
        ],
        [
          54.66999999999996,
          1.1399999999999864
        ],
        [
          56.25,
          26.789999999999964
        ],
        [
          55.76999999999998,
          49.68000000000001
        ],
        [
          27.559999999999945,
          51.31999999999999
        ],
        [
          1.259999999999991,
          50.16999999999996
        ],
        [
          0.0,
          25.47999999999996
        ],
        [
          1.3399999999999181,
          1.759999999999991
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-93",
      "type": "line",
      "x": 958.83,
      "y": 412.96,
      "width": 52.77999999999997,
      "height": 47.93000000000001,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10093,
      "version": 1,
      "versionNonce": 20093,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.77999999999997,
          2.590000000000032
        ],
        [
          51.389999999999986,
          47.93000000000001
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-94",
      "type": "rectangle",
      "x": 1058.0,
      "y": 414.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10094,
      "version": 1,
      "versionNonce": 20094,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-95",
      "type": "line",
      "x": 1057.12,
      "y": 412.7,
      "width": 56.830000000000155,
      "height": 50.389999999999986,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10095,
      "version": 1,
      "versionNonce": 20095,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.3300000000001546,
          1.910000000000025
        ],
        [
          27.74000000000001,
          0.0
        ],
        [
          55.61000000000013,
          0.38999999999998636
        ],
        [
          56.830000000000155,
          25.25999999999999
        ],
        [
          55.47000000000003,
          49.04000000000002
        ],
        [
          27.670000000000073,
          50.389999999999986
        ],
        [
          0.9100000000000819,
          49.120000000000005
        ],
        [
          0.010000000000218279,
          24.80000000000001
        ],
        [
          0.0,
          1.7300000000000182
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-96",
      "type": "line",
      "x": 1060.14,
      "y": 412.23,
      "width": 51.909999999999854,
      "height": 48.18000000000001,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10096,
      "version": 1,
      "versionNonce": 20096,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.909999999999854,
          3.259999999999991
        ],
        [
          51.309999999999945,
          48.18000000000001
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-97",
      "type": "rectangle",
      "x": 1159.0,
      "y": 414.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10097,
      "version": 1,
      "versionNonce": 20097,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-98",
      "type": "line",
      "x": 1158.01,
      "y": 412.38,
      "width": 56.77999999999997,
      "height": 50.139999999999986,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10098,
      "version": 1,
      "versionNonce": 20098,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.34999999999990905,
          1.9700000000000273
        ],
        [
          27.50999999999999,
          0.0
        ],
        [
          54.059999999999945,
          1.9300000000000068
        ],
        [
          56.77999999999997,
          26.25
        ],
        [
          55.190000000000055,
          50.139999999999986
        ],
        [
          27.289999999999964,
          49.879999999999995
        ],
        [
          1.240000000000009,
          49.30000000000001
        ],
        [
          0.009999999999990905,
          25.05000000000001
        ],
        [
          0.0,
          1.2699999999999818
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-99",
      "type": "line",
      "x": 1160.52,
      "y": 413.22,
      "width": 53.09999999999991,
      "height": 48.02999999999997,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10099,
      "version": 1,
      "versionNonce": 20099,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          53.09999999999991,
          2.0399999999999636
        ],
        [
          52.25,
          48.02999999999997
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-100",
      "type": "text",
      "x": 90.0,
      "y": 558.0,
      "width": 113.0,
      "height": 40.5,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10100,
      "version": 1,
      "versionNonce": 20100,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "第 1 层",
      "originalText": "第 1 层",
      "fontSize": 30.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 30.0
    },
    {
      "id": "03-layer-dependency-101",
      "type": "line",
      "x": 249.39,
      "y": 541.83,
      "width": 54.74000000000001,
      "height": 51.74000000000001,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10101,
      "version": 1,
      "versionNonce": 20101,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.75,
          2.740000000000009
        ],
        [
          26.83000000000004,
          0.0
        ],
        [
          54.54000000000002,
          2.2999999999999545
        ],
        [
          54.74000000000001,
          26.329999999999927
        ],
        [
          54.410000000000025,
          49.27999999999997
        ],
        [
          28.420000000000016,
          51.74000000000001
        ],
        [
          1.5900000000000034,
          50.539999999999964
        ],
        [
          0.0,
          26.279999999999973
        ],
        [
          0.8300000000000125,
          2.25
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-102",
      "type": "line",
      "x": 252.85,
      "y": 542.95,
      "width": 51.70000000000002,
      "height": 48.14999999999998,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10102,
      "version": 1,
      "versionNonce": 20102,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.70000000000002,
          2.5699999999999363
        ],
        [
          50.37000000000003,
          48.14999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-103",
      "type": "line",
      "x": 349.34,
      "y": 543.07,
      "width": 57.110000000000014,
      "height": 49.489999999999895,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10103,
      "version": 1,
      "versionNonce": 20103,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.4700000000000273,
          0.7099999999999227
        ],
        [
          29.480000000000018,
          0.6200000000000045
        ],
        [
          56.30000000000001,
          0.2999999999999545
        ],
        [
          57.110000000000014,
          25.579999999999927
        ],
        [
          55.26000000000005,
          49.16999999999996
        ],
        [
          27.680000000000007,
          49.489999999999895
        ],
        [
          0.7700000000000387,
          48.95999999999992
        ],
        [
          0.0,
          24.449999999999932
        ],
        [
          0.8400000000000318,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-104",
      "type": "line",
      "x": 352.02,
      "y": 543.49,
      "width": 52.33000000000004,
      "height": 47.02999999999997,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10104,
      "version": 1,
      "versionNonce": 20104,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.33000000000004,
          2.2899999999999636
        ],
        [
          52.29000000000002,
          47.02999999999997
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-105",
      "type": "line",
      "x": 450.58,
      "y": 542.14,
      "width": 56.53000000000003,
      "height": 51.74000000000001,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10105,
      "version": 1,
      "versionNonce": 20105,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.5200000000000387,
          1.1499999999999773
        ],
        [
          27.99000000000001,
          0.0
        ],
        [
          55.22000000000003,
          1.1900000000000546
        ],
        [
          56.53000000000003,
          25.83000000000004
        ],
        [
          55.0,
          50.25999999999999
        ],
        [
          27.430000000000007,
          51.74000000000001
        ],
        [
          1.7800000000000296,
          49.41999999999996
        ],
        [
          0.0,
          26.610000000000014
        ],
        [
          1.1999999999999886,
          2.1299999999999955
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-106",
      "type": "line",
      "x": 454.11,
      "y": 543.85,
      "width": 51.68000000000001,
      "height": 47.549999999999955,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10106,
      "version": 1,
      "versionNonce": 20106,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.68000000000001,
          2.659999999999968
        ],
        [
          51.379999999999995,
          47.549999999999955
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-107",
      "type": "rectangle",
      "x": 553.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10107,
      "version": 1,
      "versionNonce": 20107,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-108",
      "type": "line",
      "x": 551.12,
      "y": 543.34,
      "width": 56.42999999999995,
      "height": 50.07999999999993,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10108,
      "version": 1,
      "versionNonce": 20108,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          2.830000000000041,
          0.7099999999999227
        ],
        [
          28.460000000000036,
          0.0
        ],
        [
          55.90999999999997,
          0.5
        ],
        [
          56.42999999999995,
          24.899999999999977
        ],
        [
          55.60000000000002,
          48.25999999999999
        ],
        [
          27.950000000000045,
          50.07999999999993
        ],
        [
          2.7100000000000364,
          47.69999999999993
        ],
        [
          0.0,
          24.529999999999973
        ],
        [
          2.6399999999999864,
          0.7599999999999909
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-109",
      "type": "line",
      "x": 555.84,
      "y": 542.85,
      "width": 51.799999999999955,
      "height": 48.319999999999936,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10109,
      "version": 1,
      "versionNonce": 20109,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.799999999999955,
          3.0399999999999636
        ],
        [
          50.32999999999993,
          48.319999999999936
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-110",
      "type": "rectangle",
      "x": 654.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10110,
      "version": 1,
      "versionNonce": 20110,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-111",
      "type": "line",
      "x": 653.48,
      "y": 542.18,
      "width": 54.960000000000036,
      "height": 50.950000000000045,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10111,
      "version": 1,
      "versionNonce": 20111,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.3600000000000136,
          1.8799999999999955
        ],
        [
          27.539999999999964,
          0.0
        ],
        [
          53.75999999999999,
          2.550000000000068
        ],
        [
          54.77999999999997,
          25.08000000000004
        ],
        [
          54.960000000000036,
          49.930000000000064
        ],
        [
          27.149999999999977,
          50.950000000000045
        ],
        [
          1.3500000000000227,
          50.81000000000006
        ],
        [
          0.0,
          25.350000000000023
        ],
        [
          0.8400000000000318,
          1.0600000000000591
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-112",
      "type": "line",
      "x": 655.99,
      "y": 543.82,
      "width": 52.389999999999986,
      "height": 48.039999999999964,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10112,
      "version": 1,
      "versionNonce": 20112,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.389999999999986,
          2.2799999999999727
        ],
        [
          52.0,
          48.039999999999964
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-113",
      "type": "rectangle",
      "x": 755.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10113,
      "version": 1,
      "versionNonce": 20113,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-114",
      "type": "line",
      "x": 754.88,
      "y": 543.71,
      "width": 55.16999999999996,
      "height": 49.26999999999998,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10114,
      "version": 1,
      "versionNonce": 20114,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.9600000000000364,
          0.7599999999999909
        ],
        [
          27.07000000000005,
          0.0
        ],
        [
          55.08000000000004,
          1.1499999999999773
        ],
        [
          55.16999999999996,
          25.049999999999955
        ],
        [
          53.85000000000002,
          49.26999999999998
        ],
        [
          26.220000000000027,
          49.039999999999964
        ],
        [
          1.1000000000000227,
          47.789999999999964
        ],
        [
          0.0,
          23.639999999999986
        ],
        [
          0.38999999999998636,
          0.2699999999999818
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-115",
      "type": "line",
      "x": 757.66,
      "y": 542.46,
      "width": 51.59000000000003,
      "height": 49.19999999999993,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10115,
      "version": 1,
      "versionNonce": 20115,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.59000000000003,
          3.449999999999932
        ],
        [
          49.60000000000002,
          49.19999999999993
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-116",
      "type": "rectangle",
      "x": 856.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10116,
      "version": 1,
      "versionNonce": 20116,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-117",
      "type": "line",
      "x": 855.15,
      "y": 541.83,
      "width": 55.5,
      "height": 50.95999999999992,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10117,
      "version": 1,
      "versionNonce": 20117,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.2000000000000455,
          2.839999999999918
        ],
        [
          27.129999999999995,
          0.0
        ],
        [
          54.02999999999997,
          1.990000000000009
        ],
        [
          55.25999999999999,
          25.610000000000014
        ],
        [
          55.5,
          50.860000000000014
        ],
        [
          27.860000000000014,
          50.95999999999992
        ],
        [
          1.6100000000000136,
          49.27999999999997
        ],
        [
          0.0,
          26.379999999999995
        ],
        [
          1.7000000000000455,
          3.159999999999968
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-118",
      "type": "line",
      "x": 857.09,
      "y": 542.13,
      "width": 53.289999999999964,
      "height": 49.370000000000005,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10118,
      "version": 1,
      "versionNonce": 20118,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          53.289999999999964,
          3.2799999999999727
        ],
        [
          52.77999999999997,
          49.370000000000005
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-119",
      "type": "rectangle",
      "x": 957.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10119,
      "version": 1,
      "versionNonce": 20119,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-120",
      "type": "line",
      "x": 955.17,
      "y": 542.91,
      "width": 55.879999999999995,
      "height": 49.75,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10120,
      "version": 1,
      "versionNonce": 20120,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          2.2000000000000455,
          1.3899999999999864
        ],
        [
          28.120000000000005,
          0.0
        ],
        [
          54.950000000000045,
          1.6700000000000728
        ],
        [
          55.879999999999995,
          25.720000000000027
        ],
        [
          55.620000000000005,
          48.48000000000002
        ],
        [
          29.370000000000005,
          49.75
        ],
        [
          1.4200000000000728,
          48.389999999999986
        ],
        [
          0.0,
          24.160000000000082
        ],
        [
          1.9600000000000364,
          0.8000000000000682
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-121",
      "type": "line",
      "x": 959.59,
      "y": 543.44,
      "width": 51.65999999999997,
      "height": 47.59999999999991,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10121,
      "version": 1,
      "versionNonce": 20121,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.65999999999997,
          3.5499999999999545
        ],
        [
          50.02999999999997,
          47.59999999999991
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-122",
      "type": "rectangle",
      "x": 1058.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10122,
      "version": 1,
      "versionNonce": 20122,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-123",
      "type": "line",
      "x": 1056.7,
      "y": 542.12,
      "width": 57.09999999999991,
      "height": 51.23000000000002,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10123,
      "version": 1,
      "versionNonce": 20123,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.9600000000000364,
          1.67999999999995
        ],
        [
          28.029999999999973,
          0.0
        ],
        [
          56.25,
          1.2699999999999818
        ],
        [
          57.09999999999991,
          25.980000000000018
        ],
        [
          55.09999999999991,
          49.07000000000005
        ],
        [
          28.99000000000001,
          51.23000000000002
        ],
        [
          1.7200000000000273,
          49.65999999999997
        ],
        [
          0.0,
          25.08000000000004
        ],
        [
          0.8399999999999181,
          2.2799999999999727
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-124",
      "type": "line",
      "x": 1060.09,
      "y": 543.32,
      "width": 51.29000000000019,
      "height": 47.91999999999996,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10124,
      "version": 1,
      "versionNonce": 20124,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.29000000000019,
          3.0799999999999272
        ],
        [
          51.06000000000017,
          47.91999999999996
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-125",
      "type": "rectangle",
      "x": 1159.0,
      "y": 544.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10125,
      "version": 1,
      "versionNonce": 20125,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-126",
      "type": "line",
      "x": 1157.88,
      "y": 543.09,
      "width": 56.75,
      "height": 49.319999999999936,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10126,
      "version": 1,
      "versionNonce": 20126,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.2199999999998,
          1.6000000000000227
        ],
        [
          27.25999999999999,
          0.08999999999991815
        ],
        [
          54.299999999999955,
          0.0
        ],
        [
          56.75,
          24.850000000000023
        ],
        [
          54.38999999999987,
          49.049999999999955
        ],
        [
          28.809999999999945,
          49.319999999999936
        ],
        [
          1.5599999999999454,
          48.57999999999993
        ],
        [
          0.0,
          24.49000000000001
        ],
        [
          1.0299999999999727,
          1.4699999999999136
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-127",
      "type": "line",
      "x": 1161.2,
      "y": 542.87,
      "width": 50.8599999999999,
      "height": 47.14999999999998,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10127,
      "version": 1,
      "versionNonce": 20127,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          50.8599999999999,
          3.0599999999999454
        ],
        [
          50.809999999999945,
          47.14999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-128",
      "type": "text",
      "x": 90.0,
      "y": 688.0,
      "width": 68.0,
      "height": 40.5,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10128,
      "version": 1,
      "versionNonce": 20128,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "输入",
      "originalText": "输入",
      "fontSize": 30.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 30.0
    },
    {
      "id": "03-layer-dependency-129",
      "type": "rectangle",
      "x": 250.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10129,
      "version": 1,
      "versionNonce": 20129,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-130",
      "type": "line",
      "x": 248.76,
      "y": 673.03,
      "width": 55.81999999999999,
      "height": 50.450000000000045,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10130,
      "version": 1,
      "versionNonce": 20130,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.7199999999999989,
          0.9400000000000546
        ],
        [
          28.269999999999982,
          0.07000000000005002
        ],
        [
          55.81999999999999,
          1.4100000000000819
        ],
        [
          55.43000000000001,
          24.790000000000077
        ],
        [
          55.420000000000016,
          49.48000000000002
        ],
        [
          28.28000000000003,
          50.450000000000045
        ],
        [
          0.5200000000000102,
          49.27999999999997
        ],
        [
          0.0,
          24.0
        ],
        [
          0.9399999999999977,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-131",
      "type": "line",
      "x": 251.62,
      "y": 672.43,
      "width": 52.329999999999984,
      "height": 49.08000000000004,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10131,
      "version": 1,
      "versionNonce": 20131,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.329999999999984,
          3.910000000000082
        ],
        [
          51.21999999999997,
          49.08000000000004
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-132",
      "type": "text",
      "x": 257.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10132,
      "version": 1,
      "versionNonce": 20132,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−9",
      "originalText": "i−9",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-133",
      "type": "rectangle",
      "x": 351.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10133,
      "version": 1,
      "versionNonce": 20133,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-134",
      "type": "line",
      "x": 349.18,
      "y": 673.15,
      "width": 57.370000000000005,
      "height": 50.450000000000045,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10134,
      "version": 1,
      "versionNonce": 20134,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.0699999999999932,
          1.75
        ],
        [
          29.55000000000001,
          0.0
        ],
        [
          56.73000000000002,
          1.080000000000041
        ],
        [
          57.370000000000005,
          24.129999999999995
        ],
        [
          55.81999999999999,
          48.30000000000007
        ],
        [
          28.589999999999975,
          50.450000000000045
        ],
        [
          1.7799999999999727,
          49.680000000000064
        ],
        [
          0.0,
          25.610000000000014
        ],
        [
          1.6200000000000045,
          1.0900000000000318
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-135",
      "type": "line",
      "x": 353.02,
      "y": 673.94,
      "width": 52.75,
      "height": 47.559999999999945,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10135,
      "version": 1,
      "versionNonce": 20135,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.75,
          1.919999999999959
        ],
        [
          50.450000000000045,
          47.559999999999945
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-136",
      "type": "text",
      "x": 358.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10136,
      "version": 1,
      "versionNonce": 20136,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−8",
      "originalText": "i−8",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-137",
      "type": "rectangle",
      "x": 452.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10137,
      "version": 1,
      "versionNonce": 20137,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-138",
      "type": "line",
      "x": 450.7,
      "y": 671.93,
      "width": 57.09000000000003,
      "height": 51.56000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10138,
      "version": 1,
      "versionNonce": 20138,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.7700000000000387,
          2.800000000000068
        ],
        [
          27.78000000000003,
          0.0
        ],
        [
          55.210000000000036,
          2.0100000000001046
        ],
        [
          57.09000000000003,
          25.700000000000045
        ],
        [
          54.43000000000001,
          49.530000000000086
        ],
        [
          27.900000000000034,
          51.56000000000006
        ],
        [
          0.75,
          51.020000000000095
        ],
        [
          0.0,
          25.379999999999995
        ],
        [
          1.0200000000000387,
          2.5100000000001046
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-139",
      "type": "line",
      "x": 453.33,
      "y": 672.46,
      "width": 52.10000000000002,
      "height": 48.48000000000002,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10139,
      "version": 1,
      "versionNonce": 20139,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.10000000000002,
          2.5599999999999454
        ],
        [
          50.72000000000003,
          48.48000000000002
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-140",
      "type": "text",
      "x": 459.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10140,
      "version": 1,
      "versionNonce": 20140,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−7",
      "originalText": "i−7",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-141",
      "type": "rectangle",
      "x": 553.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10141,
      "version": 1,
      "versionNonce": 20141,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-142",
      "type": "line",
      "x": 552.05,
      "y": 671.93,
      "width": 55.75,
      "height": 51.520000000000095,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10142,
      "version": 1,
      "versionNonce": 20142,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.1700000000000728,
          2.9400000000000546
        ],
        [
          27.75999999999999,
          0.0
        ],
        [
          55.10000000000002,
          1.490000000000009
        ],
        [
          55.57000000000005,
          26.680000000000064
        ],
        [
          55.75,
          49.690000000000055
        ],
        [
          27.1400000000001,
          51.520000000000095
        ],
        [
          1.2900000000000773,
          50.30000000000007
        ],
        [
          0.0,
          25.770000000000095
        ],
        [
          0.37000000000000455,
          2.6800000000000637
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-143",
      "type": "line",
      "x": 554.98,
      "y": 672.76,
      "width": 52.91999999999996,
      "height": 47.889999999999986,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10143,
      "version": 1,
      "versionNonce": 20143,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.91999999999996,
          3.9700000000000273
        ],
        [
          51.67999999999995,
          47.889999999999986
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-144",
      "type": "text",
      "x": 560.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10144,
      "version": 1,
      "versionNonce": 20144,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−6",
      "originalText": "i−6",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-145",
      "type": "rectangle",
      "x": 654.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10145,
      "version": 1,
      "versionNonce": 20145,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-146",
      "type": "line",
      "x": 653.04,
      "y": 672.71,
      "width": 55.639999999999986,
      "height": 49.629999999999995,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10146,
      "version": 1,
      "versionNonce": 20146,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          1.8099999999999454
        ],
        [
          27.710000000000036,
          0.0
        ],
        [
          55.639999999999986,
          0.2999999999999545
        ],
        [
          55.5,
          25.74000000000001
        ],
        [
          55.23000000000002,
          48.40999999999997
        ],
        [
          27.910000000000082,
          49.629999999999995
        ],
        [
          1.5600000000000591,
          49.469999999999914
        ],
        [
          0.9500000000000455,
          24.50999999999999
        ],
        [
          0.8500000000000227,
          0.6299999999999955
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-147",
      "type": "line",
      "x": 656.85,
      "y": 672.03,
      "width": 52.120000000000005,
      "height": 48.80000000000007,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10147,
      "version": 1,
      "versionNonce": 20147,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.120000000000005,
          3.75
        ],
        [
          49.14999999999998,
          48.80000000000007
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-148",
      "type": "text",
      "x": 661.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10148,
      "version": 1,
      "versionNonce": 20148,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−5",
      "originalText": "i−5",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-149",
      "type": "rectangle",
      "x": 755.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10149,
      "version": 1,
      "versionNonce": 20149,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-150",
      "type": "line",
      "x": 753.6,
      "y": 672.55,
      "width": 56.47000000000003,
      "height": 50.15000000000009,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10150,
      "version": 1,
      "versionNonce": 20150,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.2799999999999727,
          1.259999999999991
        ],
        [
          28.079999999999927,
          0.0
        ],
        [
          55.25,
          0.4800000000000182
        ],
        [
          56.47000000000003,
          26.190000000000055
        ],
        [
          55.889999999999986,
          48.83000000000004
        ],
        [
          29.25999999999999,
          50.15000000000009
        ],
        [
          1.240000000000009,
          50.0
        ],
        [
          0.0,
          24.660000000000082
        ],
        [
          2.0,
          1.9500000000000455
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-151",
      "type": "line",
      "x": 756.39,
      "y": 672.75,
      "width": 52.700000000000045,
      "height": 47.289999999999964,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10151,
      "version": 1,
      "versionNonce": 20151,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.700000000000045,
          3.669999999999959
        ],
        [
          50.75999999999999,
          47.289999999999964
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-152",
      "type": "text",
      "x": 762.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10152,
      "version": 1,
      "versionNonce": 20152,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−4",
      "originalText": "i−4",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-153",
      "type": "rectangle",
      "x": 856.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10153,
      "version": 1,
      "versionNonce": 20153,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-154",
      "type": "line",
      "x": 855.03,
      "y": 671.87,
      "width": 55.09000000000003,
      "height": 50.889999999999986,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10154,
      "version": 1,
      "versionNonce": 20154,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          1.9700000000000273
        ],
        [
          27.620000000000005,
          0.0
        ],
        [
          54.39999999999998,
          1.67999999999995
        ],
        [
          55.09000000000003,
          26.659999999999968
        ],
        [
          54.620000000000005,
          50.889999999999986
        ],
        [
          27.269999999999982,
          50.40999999999997
        ],
        [
          0.7400000000000091,
          50.559999999999945
        ],
        [
          0.7400000000000091,
          25.649999999999977
        ],
        [
          0.7799999999999727,
          1.57000000000005
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-155",
      "type": "line",
      "x": 858.02,
      "y": 672.23,
      "width": 52.210000000000036,
      "height": 47.889999999999986,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10155,
      "version": 1,
      "versionNonce": 20155,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.210000000000036,
          4.439999999999941
        ],
        [
          51.5,
          47.889999999999986
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-156",
      "type": "text",
      "x": 863.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10156,
      "version": 1,
      "versionNonce": 20156,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−3",
      "originalText": "i−3",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-157",
      "type": "rectangle",
      "x": 957.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10157,
      "version": 1,
      "versionNonce": 20157,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-158",
      "type": "line",
      "x": 955.04,
      "y": 672.61,
      "width": 57.40000000000009,
      "height": 50.24000000000001,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10158,
      "version": 1,
      "versionNonce": 20158,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          1.4300000000000637,
          2.1399999999999864
        ],
        [
          28.730000000000018,
          0.0
        ],
        [
          56.780000000000086,
          1.5699999999999363
        ],
        [
          57.40000000000009,
          26.269999999999982
        ],
        [
          56.190000000000055,
          48.710000000000036
        ],
        [
          28.460000000000036,
          50.24000000000001
        ],
        [
          1.5,
          48.48000000000002
        ],
        [
          0.0,
          25.149999999999977
        ],
        [
          1.7000000000000455,
          1.9399999999999409
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-159",
      "type": "line",
      "x": 958.32,
      "y": 672.88,
      "width": 52.08999999999992,
      "height": 47.76999999999998,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10159,
      "version": 1,
      "versionNonce": 20159,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          52.08999999999992,
          2.840000000000032
        ],
        [
          52.00999999999999,
          47.76999999999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-160",
      "type": "text",
      "x": 964.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10160,
      "version": 1,
      "versionNonce": 20160,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−2",
      "originalText": "i−2",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-161",
      "type": "rectangle",
      "x": 1058.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10161,
      "version": 1,
      "versionNonce": 20161,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-162",
      "type": "line",
      "x": 1057.48,
      "y": 672.4,
      "width": 56.3599999999999,
      "height": 49.620000000000005,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10162,
      "version": 1,
      "versionNonce": 20162,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.19000000000005457,
          1.7300000000000182
        ],
        [
          27.529999999999973,
          0.0
        ],
        [
          54.5,
          2.480000000000018
        ],
        [
          56.3599999999999,
          26.360000000000014
        ],
        [
          55.38999999999987,
          48.889999999999986
        ],
        [
          26.529999999999973,
          49.620000000000005
        ],
        [
          1.099999999999909,
          49.440000000000055
        ],
        [
          0.32999999999992724,
          26.300000000000068
        ],
        [
          0.0,
          1.5500000000000682
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-163",
      "type": "line",
      "x": 1060.46,
      "y": 672.72,
      "width": 50.909999999999854,
      "height": 47.91999999999996,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10163,
      "version": 1,
      "versionNonce": 20163,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          50.909999999999854,
          3.5
        ],
        [
          50.37999999999988,
          47.91999999999996
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-164",
      "type": "text",
      "x": 1065.67,
      "y": 742.1,
      "width": 51.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10164,
      "version": 1,
      "versionNonce": 20164,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i−1",
      "originalText": "i−1",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    },
    {
      "id": "03-layer-dependency-165",
      "type": "rectangle",
      "x": 1159.0,
      "y": 674.0,
      "width": 54.0,
      "height": 48.0,
      "angle": 0,
      "strokeColor": "transparent",
      "backgroundColor": "#fff0d7",
      "fillStyle": "solid",
      "strokeWidth": 0.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10165,
      "version": 1,
      "versionNonce": 20165,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false
    },
    {
      "id": "03-layer-dependency-166",
      "type": "line",
      "x": 1158.17,
      "y": 672.06,
      "width": 55.98000000000002,
      "height": 50.020000000000095,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 2.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10166,
      "version": 1,
      "versionNonce": 20166,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          2.4700000000000273
        ],
        [
          27.519999999999982,
          0.0
        ],
        [
          54.51999999999998,
          2.8600000000000136
        ],
        [
          55.98000000000002,
          26.75
        ],
        [
          54.569999999999936,
          49.0
        ],
        [
          27.669999999999845,
          50.020000000000095
        ],
        [
          0.6799999999998363,
          49.97000000000003
        ],
        [
          0.7400000000000091,
          25.56000000000006
        ],
        [
          0.14999999999986358,
          1.0900000000000318
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-167",
      "type": "line",
      "x": 1161.73,
      "y": 672.02,
      "width": 51.15000000000009,
      "height": 49.930000000000064,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 0.75,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10167,
      "version": 1,
      "versionNonce": 20167,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          0.0
        ],
        [
          51.15000000000009,
          4.7000000000000455
        ],
        [
          49.62999999999988,
          49.930000000000064
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-168",
      "type": "text",
      "x": 1180.33,
      "y": 740.3,
      "width": 20.0,
      "height": 31.05,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10168,
      "version": 1,
      "versionNonce": 20168,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "i",
      "originalText": "i",
      "fontSize": 23.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 23.0
    },
    {
      "id": "03-layer-dependency-169",
      "type": "text",
      "x": 1349.33,
      "y": 342.9,
      "width": 125.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10169,
      "version": 1,
      "versionNonce": 20169,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "1 个位置",
      "originalText": "1 个位置",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-170",
      "type": "text",
      "x": 1349.33,
      "y": 472.9,
      "width": 125.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10170,
      "version": 1,
      "versionNonce": 20170,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "4 个位置",
      "originalText": "4 个位置",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-171",
      "type": "text",
      "x": 1349.33,
      "y": 602.9,
      "width": 125.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10171,
      "version": 1,
      "versionNonce": 20171,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "7 个位置",
      "originalText": "7 个位置",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-172",
      "type": "text",
      "x": 1342.0,
      "y": 732.9,
      "width": 140.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#a5682c",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10172,
      "version": 1,
      "versionNonce": 20172,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "10 个位置",
      "originalText": "10 个位置",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-173",
      "type": "text",
      "x": 260.0,
      "y": 794.9,
      "width": 746.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10173,
      "version": 1,
      "versionNonce": 20173,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "说明性推导：R(d) = 1 + d × (W-1)；此处 W=4，d=3。",
      "originalText": "说明性推导：R(d) = 1 + d × (W-1)；此处 W=4，d=3。",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-174",
      "type": "line",
      "x": 78.27,
      "y": 869.33,
      "width": 1441.42,
      "height": 1.669999999999959,
      "angle": 0,
      "strokeColor": "#dbd5e1",
      "backgroundColor": "none",
      "fillStyle": "solid",
      "strokeWidth": 1.5,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10174,
      "version": 1,
      "versionNonce": 20174,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "points": [
        [
          0.0,
          1.669999999999959
        ],
        [
          1441.42,
          0.0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": null
    },
    {
      "id": "03-layer-dependency-175",
      "type": "text",
      "x": 80.0,
      "y": 894.9,
      "width": 967.0,
      "height": 39.150000000000006,
      "angle": 0,
      "strokeColor": "#34313d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10175,
      "version": 1,
      "versionNonce": 20175,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "记住：理论可达范围随深度增长；恢复高层 KV 不能只看最后一层的窗口。",
      "originalText": "记住：理论可达范围随深度增长；恢复高层 KV 不能只看最后一层的窗口。",
      "fontSize": 29.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 29.0
    },
    {
      "id": "03-layer-dependency-176",
      "type": "text",
      "x": 80.0,
      "y": 958.1,
      "width": 616.0,
      "height": 28.35,
      "angle": 0,
      "strokeColor": "#65616d",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 1,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "roundness": null,
      "seed": 10176,
      "version": 1,
      "versionNonce": 20176,
      "isDeleted": false,
      "boundElements": null,
      "updated": 1793696400000,
      "link": null,
      "locked": false,
      "text": "论文 §2.2、§3.2.2，pp.9、20；W=4 的纯局部路径说明性示例",
      "originalText": "论文 §2.2、§3.2.2，pp.9、20；W=4 的纯局部路径说明性示例",
      "fontSize": 21.0,
      "fontFamily": 1,
      "textAlign": "left",
      "verticalAlign": "top",
      "containerId": null,
      "autoResize": false,
      "lineHeight": 1.35,
      "baseline": 21.0
    }
  ],
  "appState": {
    "viewBackgroundColor": "#fffefb",
    "gridSize": null
  },
  "files": {}
}
```
%%
